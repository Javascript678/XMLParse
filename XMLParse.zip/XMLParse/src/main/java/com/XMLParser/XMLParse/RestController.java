package com.XMLParser.XMLParse;


import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPathExpressionException;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.multipart.MultipartFile;
import org.xml.sax.SAXException;



@Controller
public class RestController {
	 APIService apiservice;
	 
		/*
		 * @GetMapping("/") public String mainPage() { return "upload"; }
		 */
	//private TestFlow tests;
@PostMapping("/triggerAPIforXML")

public ResponseEntity<?>  triggerAPIforXML(@RequestPart(value="file") MultipartFile file) throws FileNotFoundException, ClassNotFoundException, IOException, InterruptedException, XPathExpressionException, ParserConfigurationException, SAXException {
	apiservice= new APIService();
	HashMap<String,Object> response= new HashMap<String,Object>();
	response=apiservice.callserviceTotriggerAPI(file);
	return new ResponseEntity<>(response, HttpStatus.OK);
}
	
	
	


}
