package com.XMLParser.XMLParse;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class XmlParseApplication {

	public static void main(String[] args) {
		SpringApplication.run(XmlParseApplication.class, args);
	}

}
