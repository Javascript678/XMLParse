package com.XMLParser.XMLParse;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPathExpressionException;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.xml.sax.SAXException;

@Service
public class APIService {
public 	HashMap<String,Object>  callserviceTotriggerAPI(MultipartFile file) throws IOException, ClassNotFoundException, InterruptedException, XPathExpressionException, ParserConfigurationException, SAXException {

	//HashMap<String,List<HashMap<String, String>>> final_data= new HashMap<String,List<HashMap<String, String>>>();
	HashMap<String,Object> final_data= new HashMap<String,Object>();
	byte[] data= file.getBytes();
	XMLParser xmlparse= new XMLParser();
	//String username=parse.getvaluewithkey("Username");
	//String uploadpath="C:\\Users\\"+username+"\\Documents\\JSONdata\\";
	String uploadpath="C:\\Users\\Public\\JSONdata\\";
	if(new File(uploadpath).exists()) {
		System.out.println("exists");
	}
	else {
		new File(uploadpath).mkdir();
		System.out.println("created");
	}
	System.out.println(file.getResource().getFilename());
	 String filename=file.getOriginalFilename();
Path path=	 Paths.get(uploadpath+filename);
Files.write(path, data);
System.out.println(path);
	 System.out.println(file.getResource().isReadable());
	 xmlparse.file=path.toFile();
	 final_data= xmlparse.getparse_Data();
	System.out.println("deleted"+xmlparse.file.delete());	
	return final_data;
}



}
