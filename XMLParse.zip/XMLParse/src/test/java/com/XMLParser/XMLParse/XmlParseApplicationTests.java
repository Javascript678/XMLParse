package com.XMLParser.XMLParse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class XmlParseApplicationTests {

	@Test
	void contextLoads() {
	}

}
