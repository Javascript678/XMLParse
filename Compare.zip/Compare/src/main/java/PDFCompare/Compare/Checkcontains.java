package PDFCompare.Compare;

import java.util.regex.Pattern;

public class Checkcontains {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="000002  2022-04-13-19.55.46.190367";
		String s2="000002  2021-02-13-19.50.41.190362";
		String s1="                        ";
		String regex="[0-9]{4}-[0-9]{2}-[0-9]{2}-[0-9]{2}.[0-9]{2}.[0-9]{2}.[0-9]{6}";
		System.out.println(s.split("[0]{5}[0-9]{1}")[1].trim().matches(regex));
		System.out.println(s2.split("[0]{5}[0-9]{1}")[1].trim().matches(regex));
		System.out.println(s1.matches(regex));

	}

}
