package PDFCompare.Compare;

import java.util.Collections;
import java.util.PriorityQueue;

public class KthElement {
	public void Heap(int[] ar, int k) {
		PriorityQueue<Integer> heap= new PriorityQueue<Integer>(Collections.reverseOrder());
		for(int i=0;i<k;i++) {
			heap.add(ar[i]);
		}
		for(int i=k;i<ar.length;i++) {//40,35,30,25,20,15,10- 45<40; 30,29,25,24,20,15,10;
			if(ar[i]<heap.peek()) {
				heap.poll();
				heap.add(ar[i]);
			}
		}
		
		System.out.println(heap.peek());
	}

	
	public void Heap1(int[] ar, int k) {
		PriorityQueue<Integer> heap= new PriorityQueue<Integer>();
		for(int i=0;i<ar.length;i++) {
			heap.add(ar[i]);
		}
		for(int i=0;i<k-1;i++) {
				heap.poll();
	
		}
		
		System.out.println(heap.peek());
	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub
       int [] ar= {10, 20, 30, 40,
    		   15, 25, 35, 45,
    		   24, 29, 37, 48,
    		   32, 33, 39, 50};
       new KthElement().Heap(ar, 6);
       new KthElement().Heap1(ar, 4);
	}

}
