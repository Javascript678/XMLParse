package PDFCompare.Compare;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class XMLParser {

	public static void main(String[] args) throws ParserConfigurationException, SAXException, IOException, XPathExpressionException {
		// TODO Auto-generated method stub
		String file_name="C:\\Users\\nanda_kishore_reddy\\OneDrive - Dell Technologies\\Desktop\\plans.xml";
		List<HashMap<String,String>>lst_data = new ArrayList<HashMap<String,String>>();
		HashMap<String,List<HashMap<String, String>>> final_data= new HashMap<String,List<HashMap<String, String>>>();
		List<HashMap<String,String>>lst_data2 = new ArrayList<HashMap<String,String>>();
			List<HashMap<String,String>>lst_data3 = new ArrayList<HashMap<String,String>>();
			File file= new File("C:\\Users\\nanda_kishore_reddy\\OneDrive - Dell Technologies\\Desktop\\plans.xml");
		DocumentBuilderFactory fact= DocumentBuilderFactory.newInstance();
		DocumentBuilder build= fact.newDocumentBuilder();
	      Document doc=build.parse(file);
	      Element root=doc.getDocumentElement();
	     int count= doc.getElementsByTagName("BenefitEnrollmentMaintenance").getLength();
	    // for(int i=1;i<=count;i++) {["+i+"]
	      String TransactionTag="BenefitEnrollmentRequest/BenefitEnrollmentMaintenance/TransactionInformation";
			String MemberTag="BenefitEnrollmentRequest/BenefitEnrollmentMaintenance/Member";
			String IssuerTag="BenefitEnrollmentRequest/BenefitEnrollmentMaintenance/Issuer";
	     
	      doc.getDocumentElement().normalize();
	      XPathFactory xpathfactory = XPathFactory.newInstance();
	      XPath xpath=xpathfactory.newXPath();
	      XPathExpression expression=xpath.compile(TransactionTag);
	     NodeList node_list= (NodeList) expression.evaluate(doc, XPathConstants.NODESET);
	     XPathExpression expression2=xpath.compile(MemberTag);
	     NodeList node_list2= (NodeList) expression2.evaluate(doc, XPathConstants.NODESET);
	     XPathExpression expression3=xpath.compile(IssuerTag);
	     NodeList node_list3= (NodeList) expression3.evaluate(doc, XPathConstants.NODESET);
	     lst_data= parseNode(lst_data,node_list);
	     lst_data2= parseNode(lst_data2,node_list2);
	     lst_data3= parseNode(lst_data3,node_list3);
	     final_data.put("Transactions", lst_data);
	     final_data.put("MemberDetails", lst_data2);
	     final_data.put("IssuerDetails", lst_data3);
	     System.out.println(final_data);
		
	}

	private static List<HashMap<String, String>> parseNode(List<HashMap<String, String>> lst_data, NodeList node_list) {
		HashMap<String,String> hp= new HashMap<String,String>();
		for(int i=0;i<node_list.getLength();i++) {
			if(node_list.item(i).getNodeType()==Node.ELEMENT_NODE) {
				
			if(node_list.item(i).getChildNodes().getLength()>1) {
				parseNode(lst_data, node_list.item(i).getChildNodes());
			}
			else {
				hp.put(node_list.item(i).getNodeName(), node_list.item(i).getTextContent());
				lst_data.add(hp);
					
				}
			hp= new HashMap<String,String>();
			
				}
			}
		
		return lst_data;
			
			
		}
		
	}

