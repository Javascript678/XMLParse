package PDFCompare.Compare;

import java.util.Arrays;
import java.util.Optional;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        int [] data= {2, 4, 5, 1, 2, 3};
         int[] leftsum= new int[6];
         int[] rightsum= new int[6];
         leftsum[0]=data[0];
         
        System.out.println(data.length);
        for(int i=1;i<data.length;i++) {
        	leftsum[i]=data[i]+leftsum[i-1];
        }
        rightsum[0]=leftsum[(leftsum.length)-1];
        for(int i=1;i<data.length;i++) {
        	rightsum[i]=rightsum[i-1]-data[i-1];
        }
        
        System.out.println(Arrays.toString(leftsum));
        System.out.println(Arrays.toString(rightsum));
        for(int i=0;i<data.length;i++) {
        	if(leftsum[i]==rightsum[i]) {
        		System.out.println(i+" :" +data[i]);
        	}
        }
         }
}
