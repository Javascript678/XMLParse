package PDFCompare.Compare;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import com.groupdocs.comparison.internal.c.a.e.system.Array;

public class Flightcode {
HashMap<String,Object> hp= new HashMap<String,Object>();
List<String> lst= new ArrayList<String>(Arrays.asList("123","234","456","231"));
List<String> lst1= new ArrayList<String>(Arrays.asList("143","243","465","2112","124"));

public HashMap<String,Object> getdetails(String...argu){
	for(String ar:argu) {
		if(ar.equalsIgnoreCase("Flight A")) {
			hp.put("Flight A", lst);	
		}
		else {
			hp.put("Flight B",lst1);
		}
	}
	
	return hp;
	
}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(new Flightcode().getdetails(new String[]{"Flight A","Flight B"}));

	}

}
