package PDFCompare.Compare;

import java.util.ArrayList;
import java.util.List;

public class StringCompare {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String ch[]= {"hello","act","cheap","peach","cat","probe","robep"};
		List<String> lst= new ArrayList<String>();
		for(int i=0;i<ch.length;i++) {
			for(int j=1;j<ch.length;j++) {
				if(ch[i].length()==ch[j].length()) {
					for(int k=0;k<ch[i].length();k++) {
						if(ch[i].contains(ch[j])) {
							if((!lst.contains(ch[i]))) {
							lst.add(ch[i]);
							}
						}
					}
				}
			}
			
	}
		System.out.println(lst);	
	}
}


