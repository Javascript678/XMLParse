package PDFCompare.Compare;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;

public class Date {
	public void sorted_from_most_recent_to_oldest()throws Throwable{
		
		String date = "5/11/2022";
		String date1 = "3/16/2022";
		String date2 = "3/10/2022";
		String date3 = "1/31/2022";
		DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("M/dd/yyyy");
		
		LocalDate dat = LocalDate.parse(date, dateFormat);
		LocalDate dat1 = LocalDate.parse(date1, dateFormat);
		LocalDate dat2 = LocalDate.parse(date2, dateFormat);
		LocalDate dat3 = LocalDate.parse(date3, dateFormat);
		dat.format(dateFormat);
		ArrayList<String> list = new ArrayList<String>();
		list.add(dat.format(dateFormat).replaceAll("-", "/"));
		list.add(dat1.toString().replaceAll("-", "/"));
		list.add(dat2.toString().replaceAll("-", "/"));
		list.add(dat3.toString().replaceAll("-", "/"));
		System.out.println("The unsorted date " + list);
		Collections.sort(list);
		System.out.println("The sorted date is " + list);
 
		/*
		 * String date = "05/11/2022"; String date1 = "03/16/2022"; String date2=
		 * "03/10/2022"; String date3="01/31/2022"; SimpleDateFormat dateFormat = new
		 * SimpleDateFormat("MM/dd/yyyy"); java.util.Date utilDate1 =
		 * dateFormat.parse(date); java.util.Date utilDate2 = dateFormat.parse(date1);
		 * java.util.Date utilDate3=dateFormat.parse(date2); java.util.Date utilDate4=
		 * dateFormat.parse(date3); ArrayList list = new ArrayList();
		 * list.add(utilDate1); list.add(utilDate2); list.add(utilDate3);
		 * list.add(utilDate4); System.out.println("The unsorted date "+list);
		 * Collections.sort(list); System.out.println("The sorted date is "+list);
		 */
		}
		

	public static void main(String[] args) throws Throwable {
		// TODO Auto-generated method stub
     new Date().sorted_from_most_recent_to_oldest();
	}

}
