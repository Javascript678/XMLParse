package PDFCompare.Compare;

import java.util.HashMap;

public class Charcount {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s[]= {"cat","kranthi","kumar","peach","act","cheap","krazy"};
		HashMap<String,HashMap<Character,Integer>> hp= new HashMap<String,HashMap<Character,Integer>>();
		HashMap<Character,Integer> innermap= new HashMap<Character,Integer>();
		for(String sd:s) {
			for(int i=0;i<sd.length();i++) {
				if(innermap.containsKey(sd.charAt(i))) {
					innermap.put(sd.charAt(i), innermap.get(sd.charAt(i)+1));
				}
				else {
					innermap.put(sd.charAt(i), 1);
				}
				
			}
			
			hp.put(sd, innermap);
			innermap= new HashMap<Character,Integer>();
			//hp= new HashMap<String,HashMap<Character,Integer>>();	
		}
		System.out.println(hp);

	}

}
