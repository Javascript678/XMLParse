package PDFCompare.Compare;

import java.nio.file.PathMatcher;
import java.util.regex.Pattern;

public class Regex {
	public int getminvalue(String s, int [] co) {
		char previous='*';
		int sum=0;
		int costp=0;
		for(int i=0;i<s.length();i++) {
			if(s.charAt(i)==previous) {
				if(costp<co[i]) {
					sum+=costp;
					costp=co[i];
				}
				else {
					sum+=co[i];
				}
				
			}
			else {
				previous=s.charAt(i);
				costp=co[i];
			}
		}
		return sum;
			}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		  String [] s2=
		  {"NPABVCFX","NPBCDAG1","NPCV2121","NPA1231C","NPGH12CB","QV123HN","1234567N"}
		  ; String s1="^[0-9a-zA-Z]*[0-9a-zA-Z]*"; for(int i=0;i<s2.length;i++) {
		  System.out.println(s2[i]+"matched status:"+s2[i].matches(s1)); 
		  Pattern pat= Pattern.compile(s1);
		 System.out.println(pat.matcher(s2[i]).groupCount());
		  
		  }
		 
		
		String s= "abaac";
				//"aabaa";
	int [] cost= {1,2,3,4,5};
			 //{1,2,3,4,1};
	System.out.println(new Regex().getminvalue(s, cost));
	
	
	
	
	}

}
