package PDFCompare.Compare;

import java.util.HashMap;
import java.util.Map;

public class Datatest {
	public void getdata() {
		String s="123aabb45cc6!@#$%";
		 HashMap<Character,Integer> hp = new HashMap<Character,Integer>();
		 StringBuffer buf= new StringBuffer();
		 for (int i=0;i<s.toCharArray().length;i++) {
			 if(!Character.isDigit(s.charAt(i))) {
				 if(Character.isLetter(s.charAt(i))) {
					 buf.append(s.charAt(i));
				 }
			 }
		 }
		 System.out.println(buf);
		for(int j=0;j<buf.length();j++) {
			if(hp.containsKey(buf.charAt(j))){
				hp.put(buf.charAt(j), hp.get(buf.charAt(j))+1);
			}
			else {
				hp.put(buf.charAt(j), 1);
				
			}
				
		}
		System.out.println(hp);
		for(Map.Entry<Character, Integer> mp: hp.entrySet()) {
			System.out.println(String.format("%s - %s", mp.getKey(), mp.getValue()));
		}

			}

	
	


	public static void main(String[] args) {
		// TODO Auto-generated method stub
 new Datatest().getdata();
}
}
