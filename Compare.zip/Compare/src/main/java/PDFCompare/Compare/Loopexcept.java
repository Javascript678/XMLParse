package PDFCompare.Compare;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Loopexcept {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String [] s= {"Pen","pot","pig","pol","toll"};
		List<String> ls= new ArrayList<String>(Arrays.asList(s));
	outer:	for(int i=0;i<10;i++) {
			try {
			System.out.println(ls.get(i));
		}
		
		
			catch(IndexOutOfBoundsException e1) {
				//System.out.println(i);
				System.out.println(e1.getClass().getName());
				continue outer;
				
			}
			catch(Exception e) {
				System.out.println(i);
				continue outer;
				
				}
	}
	}
}
