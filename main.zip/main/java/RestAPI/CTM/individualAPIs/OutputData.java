package RestAPI.CTM.individualAPIs;

import java.util.HashMap;

import org.testng.Reporter;
import org.testng.log4testng.Logger;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class OutputData {
	private Logger logg= Logger.getLogger(OutputData.class);
	private  static HashMap<String,String> obj= new HashMap<String, String>();
	private  static HashMap<String,String> header= new HashMap<String, String>();
	public static String outputdata=null;
	
	public void getOutputData(String Token, String Jobid) throws ClassNotFoundException {
		SessionCreation.BaseURL();
		RequestSpecification req= RestAssured.given();
		req.trustStore("src\\main\\resources\\dellcas2018.jks", "dell2018");
		req.trustStore("src\\main\\resources\\CTMcert.jks", "controlm");
		 req.auth().preemptive().oauth2(Token);
		 header.put("Content-Type", "application/json");
			header.put("Accept", "application/json");
			header.put("Annotation-Subject", null);
			header.put("Annotation-description", null);
			req.headers(header);
			 Response  response=req.get("/run/job/"+Jobid+"/output");
			 logg.info( "OutPut Data  response after job completion  :"+response.getBody().asPrettyString());
			 Reporter.log("<p><b>OutputData</b></p>"+"</br>");
		Reporter.log("Output of job after completion : "+response.getBody().asPrettyString()+"</br>");
		outputdata=response.getBody().asPrettyString();

}

}
