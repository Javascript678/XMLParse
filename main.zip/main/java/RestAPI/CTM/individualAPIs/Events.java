package RestAPI.CTM.individualAPIs;

import java.util.HashMap;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class Events extends SessionCreation {
	private  static HashMap<String,String> obj= new HashMap<String, String>();
	private  static HashMap<String,String> header= new HashMap<String, String>();
		
	public static void getEvents(String Token) {
		SessionCreation.BaseURL();
		RestAssured.useRelaxedHTTPSValidation();
		 RequestSpecification request=RestAssured.given();
		 request.auth().preemptive().oauth2(Token);
		 header.put("Content-Type", "application/json");
			header.put("Accept", "application/json");
		 request.headers(header);
		 Response response=request.get("/run/events");
		 System.out.println(response.getBody().asPrettyString());
		 
	}
	
	

}
