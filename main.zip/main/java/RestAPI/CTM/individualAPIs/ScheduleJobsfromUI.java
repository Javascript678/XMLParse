package RestAPI.CTM.individualAPIs;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;

import ControlMAPI.API.ParseJsondata;
import io.github.bonigarcia.wdm.WebDriverManager;

public class ScheduleJobsfromUI {
	private WebDriver driver;
	private By insertitemlink=By.xpath("//a[text()='Insert item']");
	private static Logger log= LogManager.getLogger(ScheduleJobsfromUI.class);
	private static ParseJsondata jsonparse;
	
	public void postJobs() throws InterruptedException, FileNotFoundException, IOException {
	WebDriverManager.chromedriver().setup();
	ChromeOptions options = new ChromeOptions();
	options.addArguments("--headless");
     driver = new ChromeDriver(options);
driver.manage().window().maximize();    
jsonparse = new ParseJsondata();
// Navigate to Google       
driver.get("https://it.onecloud.dell.com/sites/EBPA/Pages/Control-M-Ordering.aspx");   
driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
//Thread.sleep(5000);
driver.findElement(By.xpath("//input[@name='loginfmt']")).sendKeys("nanda_kishore_reddy@DellTeam.com");
driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
driver.findElement(By.xpath("//input[@type='submit']")).click();
driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
System.out.println("Page title is: " + driver.getTitle());


Actions act = new Actions(driver);
act.moveToElement(driver.findElement(By.xpath(
"//select[@scriptclass='DropDownList']"))).build().perform();
driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView();", driver.findElement(By.xpath("//tbody[1]//td[2]//input[@type='text']")));

Select select = new Select( driver.findElement(By.xpath("//select[@scriptclass='DropDownList']")));
//select.selectByValue("Quality_Assurance");
select.selectByValue(jsonparse.getvaluewithkey("ctmserver"));
//select.selectByValue(readfile.readdata("ctmserver"));
driver.findElement(By.xpath("//tbody[1]//td[2]//input[@type='text']")).sendKeys(jsonparse.getdatafromfile().get(0));
//driver.findElement(By.xpath("//tbody[1]//td[2]//input[@type='text']")).sendKeys(readfile.readdata("FolderName"));
driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
driver.findElement(By.xpath("//tbody[1]//td[3]//input[@scriptclass='TextBox']")).sendKeys(jsonparse.getjobsfromfile().get(0));
//driver.findElement(By.xpath("//tbody[1]//td[3]//input[@scriptclass='TextBox']")).sendKeys(readfile.readdata("JobName"));
driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
driver.findElement(By.xpath("//tbody[1]//td[6]//input[@type='text']")).sendKeys("e2e execution");
driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
driver.findElement(By.xpath("//tbody[1]//td[7]//input[@type='text']")).sendKeys("e2e execution");
driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
//driver.findElement(By.xpath("//input[@scriptclass='Button']")).click();
driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(50));
WebDriverWait wait= new WebDriverWait(driver,50);
//WebDriverWait wait=new WebDriverWait(driver, Duration.ofSeconds(50));
wait.until(ExpectedConditions.alertIsPresent());
Alert al=  driver.switchTo().alert();
al.accept();
	}
	
public void postmultiplejobsIncludingSingle(String folderls, String jobls) throws FileNotFoundException, IOException {

	
		try {
		WebDriverManager.chromedriver().setup();
		
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--headless");
	     driver = new ChromeDriver(options);
		}
		catch(Exception e) {
			System.setProperty("webdriver.chrome.driver",
					"C:\\ControlMAPI\\chromedriver.exe");
			ChromeOptions options = new ChromeOptions();
			options.addArguments("--headless");
		     driver = new ChromeDriver(options);
		}
	     jsonparse = new ParseJsondata();
	driver.manage().window().maximize();    
	// Navigate to Google       
	driver.get("https://it.onecloud.dell.com/sites/EBPA/Pages/Control-M-Ordering.aspx");   
	driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	//Thread.sleep(5000);
	//driver.findElement(By.xpath("//input[@name='loginfmt']")).sendKeys(readfile.readdata("Username")+"@DellTeam.com");
	driver.findElement(By.xpath("//input[@name='loginfmt']")).sendKeys("nanda_kishore_reddy@DellTeam.com");
	driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	driver.findElement(By.xpath("//input[@type='submit']")).click();
	driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	System.out.println("Page title is: " + driver.getTitle());

	Actions act = new Actions(driver);
	act.moveToElement(driver.findElement(By.xpath("(//select[@scriptclass='DropDownList'])"))).build().perform();
	driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

	//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView();",
			driver.findElement(By.xpath("(//tbody[1]//td[2]//input[@type='text'])")));

	Select select = new Select( driver.findElement(By.xpath("(//select[@scriptclass='DropDownList'])")));
	//select.selectByValue("Quality_Assurance");
	select.selectByValue(jsonparse.getvaluewithkey("ctmserver"));
	driver.findElement(By.xpath("(//tbody[1]//td[2]//input[@type='text'])")).sendKeys(folderls);
	driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	driver.findElement(By.xpath("(//tbody[1]//td[3]//input[@scriptclass='TextBox'])")).sendKeys(jobls);
	driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	driver.findElement(By.xpath("(//tbody[1]//td[6]//input[@type='text'])")).sendKeys("e2e execution");
	driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	driver.findElement(By.xpath("(//tbody[1]//td[7]//input[@type='text'])")).sendKeys("e2e execution");
	driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	//driver.findElement(By.xpath("//input[@scriptclass='Button']")).click();
	driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(50));
	/*if(jobls.size()>1) {
	driver.findElement(insertitemlink).click();
	}*/
			
	
	driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(50));
	driver.findElement(By.xpath("//input[@scriptclass='Button']")).click();
	
	driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(50));
	WebDriverWait wait=new WebDriverWait(driver,50);
	//WebDriverWait wait=new WebDriverWait(driver, Duration.ofSeconds(50));
	wait.until(ExpectedConditions.alertIsPresent());
	Alert al=  driver.switchTo().alert();
	al.accept();
	log.info(jobls+ " : "+"Jobs Ordered successfully");
	Reporter.log("Jobs Ordered successfully"+"</br>");
		
	
		
		
		
	}

	
	
public void postmultiplejobswithinsertIncludingSingle(List<String> folderls, List<String> jobls) throws FileNotFoundException, IOException {

	
	try {
	WebDriverManager.chromedriver().setup();
	
	ChromeOptions options = new ChromeOptions();
	options.addArguments("--headless");
     driver = new ChromeDriver(options);
	}
	catch(Exception e) {
		System.setProperty("webdriver.chrome.driver",
				"\\src\\main\\java\\Resources\\chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--headless");
	     driver = new ChromeDriver(options);
	}
     jsonparse = new ParseJsondata();
driver.manage().window().maximize();    
// Navigate to Google       
driver.get("https://it.onecloud.dell.com/sites/EBPA/Pages/Control-M-Ordering.aspx");   
driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
//Thread.sleep(5000);
//driver.findElement(By.xpath("//input[@name='loginfmt']")).sendKeys(readfile.readdata("Username")+"@DellTeam.com");
driver.findElement(By.xpath("//input[@name='loginfmt']")).sendKeys("nanda_kishore_reddy@DellTeam.com");
driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
driver.findElement(By.xpath("//input[@type='submit']")).click();
driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
System.out.println("Page title is: " + driver.getTitle());

for(int i=1;i<=jobls.size();i++) {
Actions act = new Actions(driver);
act.moveToElement(driver.findElement(By.xpath("(//select[@scriptclass='DropDownList'])["+i+"]"))).build().perform();
driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView();",
		driver.findElement(By.xpath("(//tbody[1]//td[2]//input[@type='text'])["+i+"]")));

Select select = new Select( driver.findElement(By.xpath("(//select[@scriptclass='DropDownList'])["+i+"]")));
//select.selectByValue("Quality_Assurance");
select.selectByValue(jsonparse.getvaluewithkey("ctmserver"));
driver.findElement(By.xpath("(//tbody[1]//td[2]//input[@type='text'])["+i+"]")).sendKeys(folderls.get(i-1));
driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
driver.findElement(By.xpath("(//tbody[1]//td[3]//input[@scriptclass='TextBox'])["+i+"]")).sendKeys(jobls.get(i-1));
driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
driver.findElement(By.xpath("(//tbody[1]//td[6]//input[@type='text'])["+i+"]")).sendKeys("e2e execution");
driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
driver.findElement(By.xpath("(//tbody[1]//td[7]//input[@type='text'])["+i+"]")).sendKeys("e2e execution");
driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
//driver.findElement(By.xpath("//input[@scriptclass='Button']")).click();
driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(50));
/*if(jobls.size()>1) {
driver.findElement(insertitemlink).click();
}*/
		

driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(50));
driver.findElement(By.xpath("//input[@scriptclass='Button']")).click();

driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(50));
WebDriverWait wait=new WebDriverWait(driver,50);
//WebDriverWait wait=new WebDriverWait(driver, Duration.ofSeconds(50));
wait.until(ExpectedConditions.alertIsPresent());
Alert al=  driver.switchTo().alert();
al.accept();
log.info(jobls+ " : "+"Jobs Ordered successfully");
Reporter.log("Jobs Ordered successfully"+"</br>");
	
}
	
	
	
}
}


	

