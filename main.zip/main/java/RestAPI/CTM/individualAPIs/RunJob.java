package RestAPI.CTM.individualAPIs;

import java.util.HashMap;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Reporter;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class RunJob {
	private Logger logg= LogManager.getLogger(RunJob.class);
	private  static HashMap<String,String> obj= new HashMap<String, String>();
	private  static HashMap<String,String> header= new HashMap<String, String>();
	
	public void postjobtoRun(String Token, String Jobid) throws ClassNotFoundException {
		SessionCreation.BaseURL();
		RequestSpecification req= RestAssured.given();
		req.trustStore("src\\main\\resources\\dellcas2018.jks", "dell2018");
		req.trustStore("src\\main\\resources\\CTMcert.jks", "controlm");
		 req.auth().preemptive().oauth2(Token);
		 header.put("Content-Type", "application/json");
			header.put("Accept", "application/json");
			header.put("Annotation-Subject", null);
			header.put("Annotation-description", null);
			req.headers(header);
			 Response  response=req.post("/run/job/"+Jobid+"/runNow");
			 logg.info( "Response returned by API after running the job :"+response.getBody().jsonPath().getString("message").toString());
		Reporter.log("Runnning the job : " +response.getBody().jsonPath().getString("message").toString()+"</br>");

}
}
