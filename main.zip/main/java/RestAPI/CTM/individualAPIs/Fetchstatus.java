package RestAPI.CTM.individualAPIs;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Reporter;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.util.JSONPObject;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class Fetchstatus {
	private Logger logg= LogManager.getLogger(Fetchstatus.class);
	private  static HashMap<String,String> header= new HashMap<String, String>();
	private  static HashMap<String,String> queryMap= new HashMap<String, String>();
	
	public String getstatus(String Jobname,String Token) {
		SessionCreation.BaseURL();
		RequestSpecification req=  RestAssured.given();
		req.trustStore("src\\main\\resources\\dellcas2018.jks", "dell2018");
		req.trustStore("src\\main\\resources\\CTMcert.jks", "controlm");
		req.auth().preemptive().oauth2(Token);
		 header.put("Content-Type", "application/json");
			header.put("Accept", "application/json");
			queryMap.put("jobname", Jobname);
			req.queryParams(queryMap);
			//System.out.println(queryMap);
			logg.info("Jobname considered as Query Parameter "+ queryMap);
			 Response response=req.get("/run/jobs/status");
			  String returnvalue=getcountofData(Jobname, Token);
			 if(Integer.parseInt(returnvalue)>0) {
			System.out.println(((HashMap) response.getBody().jsonPath().getList("statuses").get(0)).get("jobId"));
			logg.info("JobId is "+ ((HashMap) response.getBody().jsonPath().getList("statuses").get(0)).get("jobId") );
			Reporter.log("Job Id of job is "+((HashMap) response.getBody().jsonPath().getList("statuses").get(0)).get("jobId")+"</br>");
			return ((HashMap) response.getBody().jsonPath().getList("statuses").get(0)).get("jobId").toString();
			 }
			 else {
				  return returnvalue;
			 }
		}
		
	
	public String getcountofData(String Jobname,String Token) {
		SessionCreation.BaseURL();
		RequestSpecification req=  RestAssured.given();
		req.trustStore("src\\main\\resources\\CTMcert.jks", "controlm");
		req.auth().preemptive().oauth2(Token);
		 header.put("Content-Type", "application/json");
			header.put("Accept", "application/json");
			queryMap.put("jobname", Jobname);
			req.queryParams(queryMap);
			//System.out.println(queryMap);
			 Response response=req.get("/run/jobs/status");
			//System.out.println("Returned value: "+ response.getBody().jsonPath().get("returned").toString());
			logg.info("Returned value: "+ response.getBody().jsonPath().get("returned").toString());
			//System.out.println("Total Value: "+response.getBody().jsonPath().get("total").toString());
			logg.info("Total Value: "+response.getBody().jsonPath().get("total").toString());
			return response.getBody().jsonPath().get("returned").toString();
	}

	public String getendtime(String Jobname,String Token) {
		SessionCreation.BaseURL();
		RequestSpecification req=  RestAssured.given();
		req.trustStore("src\\main\\resources\\CTMcert.jks", "controlm");
		req.auth().preemptive().oauth2(Token);
		 header.put("Content-Type", "application/json");
			header.put("Accept", "application/json");
			queryMap.put("jobname", Jobname);
			req.queryParams(queryMap);
			//System.out.println(queryMap);
			 Response response=req.get("/run/jobs/status");
			  //String returnvalue=getcountofData(Jobname, Token);
			 /*if(Integer.parseInt(returnvalue)>0) {
			System.out.println(((HashMap) response.getBody().jsonPath().getList("statuses").get(0)).get("endTime"));
			Reporter.log("Job Id of job is "+((HashMap) response.getBody().jsonPath().getList("statuses").get(0)).get("endTime")+"</br>");
			return ((HashMap) response.getBody().jsonPath().getList("statuses").get(0)).get("endTime").toString();
			 }
			 else {
				 return returnvalue;
			 }*/
			 //System.out.println(((HashMap) response.getBody().jsonPath().getList("statuses").get(0)).get("endTime"));
			 logg.info("End Time execution of job after its completed " +((HashMap) response.getBody().jsonPath().getList("statuses").get(0)).get("endTime"));
				Reporter.log("End Time of job is "+((HashMap) response.getBody().jsonPath().getList("statuses").get(0)).get("endTime")+"</br>");
				return ((HashMap) response.getBody().jsonPath().getList("statuses").get(0)).get("endTime").toString();
				
	}
	
}
