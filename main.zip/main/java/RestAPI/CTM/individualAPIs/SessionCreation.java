package RestAPI.CTM.individualAPIs;



import java.util.HashMap;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;
import org.testng.Reporter;

import com.fasterxml.jackson.databind.ObjectMapper;


import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class SessionCreation {
	
	 public static  Logger logg= LogManager.getLogger(SessionCreation.class);
private  static HashMap<String,String> obj= new HashMap<String, String>();
private  static HashMap<String,String> header= new HashMap<String, String>();
@Autowired
  RestTemplate resttemplate	;
public static  String BaseURL() {

	 RestAssured.baseURI="https://emgappprd14.us.dell.com:8446/automation-api";
	 return RestAssured.baseURI;
	
}
 
public static String TokenGeneration(String Username, String pwd) {
	SessionCreation.BaseURL();
RestAssured.useRelaxedHTTPSValidation();
	RequestSpecification request=RestAssured.given();
	//request.trustStore("src\\main\\resources\\dellcas2018.jks", "dell2018");
	//request.trustStore("src\\main\\resources\\CTMcert.jks", "controlm");
	header.put("Content-Type", "application/json");
	header.put("Accept", "application/json");
	request.headers(header);
	obj.put("username", Username);
	obj.put("password", pwd);
	request.body(obj);
	 Response  response=request.post("/session/login");
	 logg.info("Passed Data");
	 logg.info("Response Code of session :"+response.getStatusCode());
Reporter.log("Response Code of session :"+response.getStatusCode()+"</br>");
while(response.getStatusCode()!=200) {
	response=request.post("/session/login");
	logg.info("Response Code of session after retry:"+response.getStatusCode());
}
;
//System.out.println(response.getBody().jsonPath().get("token").toString());
	  return response.getBody().jsonPath().get("token").toString();
}
	  

		  
	  }



	

