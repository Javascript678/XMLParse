package RestAPI.CTM.individualAPIs;

import java.time.LocalDate;
import java.util.HashMap;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Reporter;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class OrderJob {
	private Logger logg= LogManager.getLogger(OrderJob.class);
	private  static HashMap<String,String> obj= new HashMap<String, String>();
	private  static HashMap<String,String> header= new HashMap<String, String>();
	
/*	{
		"ctm": "Quality_Assurance",
		"folder": "Q1_MBI_DDL_EBIDSCPROC_SS",
		"jobs": "Q1_MBI_PROCEPS_SDDLDSC_A5_DSC_PART_SITE_ATMNT_RT",
		"createDuplicate": true,
		"hold": true,
		"ignoreCriteria": true,
		"independentFlow": true,
		"orderDate": "20211013",
		"orderIntoFolder": "string",
		"waitForOrderDate": true,
		"variables": [
		{
		"arg": "string",
		"arg2": "string",
		"arg3": "string"
		}
		]
		}

*/
	
	public String getdate() {
		LocalDate dte= LocalDate.now();
		 return String.valueOf(dte).replaceAll("-", "");
		
	}

	public int orderJob(String JobName, String FolderName,String ctmserver,String Token) {
		SessionCreation.BaseURL();
		 RequestSpecification req= RestAssured.given();
		 req.trustStore("src\\main\\resources\\dellcas2018.jks", "dell2018");
		 req.trustStore("src\\main\\resources\\CTMcert.jks", "controlm");
		 req.auth().preemptive().oauth2(Token);
		 header.put("Content-Type", "application/json");
			header.put("Accept", "application/json");
			header.put("Annotation-Subject", null);
			header.put("Annotation-description", null);
			req.headers(header);
			obj.put("ctm", ctmserver);
			obj.put("folder", FolderName);
			obj.put("jobs", JobName);
			obj.put("createDuplicate", "true");
			obj.put("hold", "true");
			obj.put("ignoreCriteria", "true");
			obj.put("independentFlow", "true");
			obj.put("orderDate",new OrderJob().getdate());
			obj.put("waitForOrderDate", "true");
			req.body(obj);
			 Response  response=req.post("/run/order");
			 logg.info("Status code of Order job " +response.getStatusCode());
			 logg.info(" Order Job message "+ ((HashMap) response.getBody().jsonPath().getList("errors").get(0)).get("message"));
			 
		Reporter.log(" Order Job message "+ ((HashMap) response.getBody().jsonPath().getList("errors").get(0)).get("message")+"</br>");
		Reporter.log("Status code of Order job " +response.getStatusCode()+"</br>");
	 return	response.getStatusCode();
			
		
	}

}

