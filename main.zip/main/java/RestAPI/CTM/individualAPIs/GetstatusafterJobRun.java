package RestAPI.CTM.individualAPIs;

import java.util.HashMap;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Reporter;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.util.JSONPObject;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class GetstatusafterJobRun {
	private Logger logg= LogManager.getLogger(GetstatusafterJobRun.class);
	private  static HashMap<String,String> header= new HashMap<String, String>();
	//private  static HashMap<String,String> queryMap= new HashMap<String, String>();
	public static String getJobRunStatus=null;
	public String getstatus(String Jobid,String Token) {
		SessionCreation.BaseURL();
		
		RequestSpecification req=  RestAssured.given();
		req.trustStore("src\\main\\resources\\dellcas2018.jks", "dell2018");
		req.trustStore("src\\main\\resources\\CTMcert.jks", "controlm");
		req.relaxedHTTPSValidation();
		req.auth().preemptive().oauth2(Token);
		 header.put("Content-Type", "application/json");
			header.put("Accept", "application/json");
			//queryMap.put("jobname", Jobid);
			//req.queryParams(queryMap);
			//System.out.println(queryMap);
			 Response response=req.get("/run/job/"+Jobid+"/status");
			//System.out.println(response.getBody().jsonPath().get("status").toString());
			logg.info("Status of Job after completetion: "+ response.getBody().jsonPath().get("status").toString());
			getJobRunStatus=response.getBody().jsonPath().get("status").toString();
			if(response.getBody().jsonPath().get("status").toString().equalsIgnoreCase("Ended ok")) {
             Reporter.log("<div><b><style>div{color:green}</style>"+" status of job: "+response.getBody().jsonPath().get("status").toString()+"</b></div>"+"</br>");
             }
			else {
				Reporter.log(" status of job: "+response.getBody().jsonPath().get("status").toString()+"</br>");
				//Reporter.log("<div><b><style>div{color:red}</style>"+" status of job: "+response.getBody().jsonPath().get("status").toString()+"</b></div>"+"</br>");
			}
			return response.getBody().jsonPath().get("status").toString();
	}
	
	


}
