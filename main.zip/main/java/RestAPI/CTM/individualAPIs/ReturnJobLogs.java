package RestAPI.CTM.individualAPIs;

import java.util.HashMap;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Reporter;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class ReturnJobLogs {
	private Logger logg= LogManager.getLogger(ReturnJobLogs.class);
	private  static HashMap<String,String> obj= new HashMap<String, String>();
	private  static HashMap<String,String> header= new HashMap<String, String>();
	public static String logdata=null;
	
	public void getJobLog(String Token, String Jobid) throws ClassNotFoundException {
		SessionCreation.BaseURL();
		RequestSpecification req= RestAssured.given();
		req.trustStore("src\\main\\resources\\dellcas2018.jks", "dell2018");
		req.trustStore("src\\main\\resources\\CTMcert.jks", "controlm");
		 req.auth().preemptive().oauth2(Token);
		 header.put("Content-Type", "application/json");
			header.put("Accept", "application/json");
			header.put("Annotation-Subject", null);
			header.put("Annotation-description", null);
			req.headers(header);
			 Response  response=req.get("/run/job/"+Jobid+"/log");
			 logg.info("Logs of job after completion :"+response.getBody().asPrettyString());
			 Reporter.log("<p><b>Logs of Job</b></p>"+ "</br>");
		Reporter.log("Logs of job after completion : " +response.getBody().asPrettyString()+"</br>");
		logdata=response.getBody().asPrettyString();
}

}
