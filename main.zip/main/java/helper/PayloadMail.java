package helper;

public class PayloadMail {
	
	
	public static Object payload(String toEmail,String bodyText,String ccemail) {
		
		String payload ="{ \r\n" + 
				" 	\"maildata\": { \r\n" + 
				" 		\"bodyText\": \""+bodyText+"\", \r\n" + 
				" 		\"fromEmailId\": \"E2Eteam@dell.com\",\r\n" + 
				" 		\"subject\": \"Control-M Job Notification\",\r\n" + 
				" 		\"toEmailId\": \""+toEmail+"\",\r\n" + 
				"\"ccEmailIds\": \""+ccemail+"\"\r\n" +
				"} \r\n" + 
				"}";
		
		return payload;
		
		
	}

}
