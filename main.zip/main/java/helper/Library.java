package helper;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.TimeZone;
import java.util.TreeMap;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.asserts.SoftAssert;

import com.google.gson.Gson;

public class Library {

	final static Logger log = LogManager.getLogger(Library.class);
	SoftAssert softAssert = new SoftAssert();
	public static Properties prop = new Properties();

	//static String pattern = "yyyy-MM-dd hh:mm:ss";
	//static SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);

	public static String getVal(String key) {
		String value = prop.getProperty(key);
		return value;
	}

	public static void LoadConfig(String FileName) {
		//String path = System.getProperty("user.d");
		//String fpath = path + "\\Configuration\\" + FileName;
		try {
			FileInputStream inStream = new FileInputStream(FileName);
			prop.load(inStream);
			inStream.close();
		} catch (NullPointerException e) {
			log.error("Can't load null, Check Path. Cause : ", e);
		} catch (FileNotFoundException e) {
			log.error("Not Able to Load File, Check Path. Cause : ", e);
		} catch (IOException e) {
			log.error("IOException, Check Path. Cause : ", e);
		} catch (Exception e) {
			log.error("Exception raised, Check Path. Cause : ", e);

		}

	}

	public static Map<String,String> readConfigtoHashMap(InputStream inStream) {

		Properties property = new Properties();
		Map<String,String> mapData = new HashMap<>();
		try {
			//FileInputStream inStream = new FileInputStream(FileName);
			property.load(inStream);
			inStream.close();


			for (String key : property.stringPropertyNames()) {

				mapData.put(key, property.getProperty(key));
				System.out.println(key+"---"+ property.getProperty(key));
			}



		} catch (NullPointerException e) {
			log.error("Can't load null, Check Path. Cause : ", e);
		} catch (FileNotFoundException e) {
			log.error("Not Able to Load File, Check Path. Cause : ", e);
		} catch (IOException e) {
			log.error("IOException, Check Path. Cause : ", e);
		} catch (Exception e) {
			log.error("Exception raised, Check Path. Cause : ", e);

		}

		return mapData;
	}

	public static Map<String,String> readConfigtoHashMap(String FileName) {

		Properties property = new Properties();
		Map<String,String> mapData = new HashMap<>();
		try {
			FileInputStream inStream = new FileInputStream(FileName);
			property.load(inStream);
			inStream.close();


			for (String key : property.stringPropertyNames()) {

				mapData.put(key, property.getProperty(key));
				System.out.println(key+"---"+ property.getProperty(key));
			}
			// TreeMap to store values of HashMap
	        TreeMap<String, String> sorted = new TreeMap<>();
	 
	        // Copy all data from hashMap into TreeMap
	        sorted.putAll(mapData);
	 
	        // Display the TreeMap which is naturally sorted 
	        for (Map.Entry<String, String> entry : sorted.entrySet()) {
	            System.out.println("Key : " + entry.getKey() 
					+ " Value : " + entry.getValue());
	        }

		} catch (NullPointerException e) {
			log.error("Can't load null, Check Path. Cause : ", e);
		} catch (FileNotFoundException e) {
			log.error("Not Able to Load File, Check Path. Cause : ", e);
		} catch (IOException e) {
			log.error("IOException, Check Path. Cause : ", e);
		} catch (Exception e) {
			log.error("Exception raised, Check Path. Cause : ", e);

		}

		return mapData;
	}


	public static String DateCompare(String date1, String date2 ) {

		String message="";

		try {
			// Create SimpleDateFormat object 
			SimpleDateFormat sdfo = new SimpleDateFormat("yyyy-MM-dd"); 

			// Get the two dates to be compared - required format for compareTo function
			Date currentDate = sdfo.parse(date1); 
			Date dw_ins_date = sdfo.parse(date2);

			// Print the dates 
			log.info("Current Date : " + sdfo.format(currentDate)); 
			log.info("dw_ins_date : " + sdfo.format(dw_ins_date)); 

			// Compare the dates using compareTo() 
			if (currentDate.compareTo(dw_ins_date) > 0) { 

				// When current_date d1 > dw_ins_dtsz d2 
				log.info("current_date: "+date1 +" is after dw_ins_dtsz:"+date2 +".   Need to check if Job refresh was done or not"); 

				message= "Need to check if Job refresh was done or not. | Current Date : "+date1 + " | dw_ins_date : "+date2;
			} 

			else if (currentDate.compareTo(dw_ins_date) < 0) { 

				// When current_date d1 < dw_ins_dtsz d2 
				message= date1 +" is before "+date2;

				//not to occur likely, as the dw_ins_dtsz will usually have the time stamp for the last inserted record
				//and our script will run after that, so current_date>dw_ins_dtsz or current_date=dw_ins_dtsz
			} 

			else if (currentDate.compareTo(dw_ins_date) == 0) { 

				// When current_date d1 = dw_ins_dtsz d2 
				log.info("current_date: "+date1 +" is equal to dw_ins_dtsz: "+date2); 
				message= "Job Refresh done. "+"| Current Date : "+date1 + "| dw_ins_date : "+date2;
			} 


		} catch (ParseException e) {

			e.printStackTrace();
		}
		return message; 
	}


	public static boolean isNumeric(String strNum) {
		if (strNum == null) {
			return false;
		}
		try {
			double d = Double.parseDouble(strNum);
		} catch (NumberFormatException nfe) {
			return false;
		}
		return true;
	}

	void copyProperty(String Filename) {

		File tempFile =null;

		try {
			InputStream input = Library.class.getClassLoader().getResourceAsStream(Filename);

			tempFile = File.createTempFile(String.valueOf(input.hashCode()), ".properties");

			OutputStream out = new FileOutputStream(tempFile);


			byte[] buffer = new byte[1024];
			int length = -1;
			while ((length = input.read(buffer)) != -1) {
				out.write(buffer, 0, length);

			}



		}	  catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


	}	



	public static String textFileToString(String fileName) {
		String content="";
		try {
			BufferedReader reader = new BufferedReader(new FileReader(fileName));

			StringBuilder stringBuilder = new StringBuilder();
			String line = null;
			String ls = System.getProperty("line.separator");
			while ((line = reader.readLine()) != null) {
				stringBuilder.append(line);
				stringBuilder.append(ls);
			}
			// delete the last new line separator
			stringBuilder.deleteCharAt(stringBuilder.length() - 1);
			reader.close();

			content = stringBuilder.toString();
		}catch(FileNotFoundException e) {
			System.out.println(e);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return content;

	}

	/**
	 * put the text(data in string format) and create html file
	 * @param text
	 * @param extention
	 */
	public static void writeToFile(String text, String extention) {
		try {

			//Date date = new Date() ;
			//SimpleDateFormat sdfo = new SimpleDateFormat("yyyy-MM-dd"); 
			//String fileName = "Report_"+sdfo.format(date)+"."+extention;

			String date = dateDefaultTimeZone("yyyy-MM-dd_HH-mm","GMT+5:30");
			String fileName = "Report_"+date+"."+extention;
			File myObj = new File(fileName);
			if (myObj.createNewFile()) {
				System.out.println("File created: " + myObj.getName());
			} else {
				System.out.println("File already exists.");
			}

			FileWriter myWriter = new FileWriter(fileName);
			myWriter.write(text);
			myWriter.close();



		} catch (IOException e) {
			System.out.println("An error occurred.");
			e.printStackTrace();
		}
	}

	/**
	 * @author Meghana_B
	 * @dateModified 6/15/2021
	 * @method returns the date in default timezone - corresponding to the time zone reported by the operating system
	 * yyyy-MM-dd HH:mm:ss - 24hrs format, yyyy-MM-dd hh:mm:ss - 12Hrs format
	 * memsql DB - EDT or America/New_York format - select now() or select CURRENT_TIMESTAMP works in MySQL
	 * EDT - Easter Daylight Time - UTC-4 - Summer, EST - Easter Standard Time - UTC-5 - winter
	 * greenplum DB - IST or GMT+5:30 format (dw_ins_dtsz) - select timeofday() works in GP/PostGreSQL
	 * Gitlab by default follows UTC timezone - SimpleDateFormat will be UTC and 12Hrs format if triggered from GitLab
	 * @return date and time stamp in String format
	 */
	public static String dateDefaultTimeZone(String format,String timezone) {
		TimeZone.setDefault(TimeZone.getTimeZone(timezone));
		Date date = new Date() ;
		SimpleDateFormat sdfo = new SimpleDateFormat(format); 
		return sdfo.format(date);

		//String todaysDate = simpleDateFormat.format(new Date());	
		//return todaysDate;
	}


	/**
	 * @author Meghana_B
	 * @dateModified 6/15/2021
	 * @method returns the System Time zone or the time zone reported by the operating system
	 * @return date and time stamp in String format
	 */
	public static void getDefaultTimeZone() {
		System.out.println(TimeZone.getDefault());
		//expected output -- sun.util.calendar.ZoneInfo[id="Asia/Calcutta",offset=19800000,dstSavings=0,useDaylight=false,transitions=7,lastRule=null]
	}

	
	/**
	 * @author Meghana_B
	 * @dateModified 7/29/2021
	 * @method find the difference between two time stamps in minutes -- Test it before use
	 * @param date1
	 * @param date2
	 * @return difference in minutes
	 */
	public static long getMinuteDiff(String date1,String date2) {
		long diffInMinutes;

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

		LocalDateTime jobDate= LocalDateTime.parse(date1, formatter);
		LocalDateTime currentTimeStamp= LocalDateTime.parse(date2, formatter);

		diffInMinutes = java.time.Duration.between(currentTimeStamp, jobDate).toMinutes();
		System.out.println("Time difference between two date/timestamps given:"+diffInMinutes);

		return diffInMinutes;
	}

	
	/*
	 * public static String getServiceAccountPassword(String nameSpace, String
	 * roleId, String secretId, String accountPath) throws Exception { String pass =
	 * ""; try { VaultPass vault = new VaultPass(); pass =
	 * vault.getVaultPass(nameSpace, roleId, secretId, accountPath);
	 * 
	 * String serAcc = accountPath.split("data/")[1]; pass = pass.split(serAcc +
	 * "=")[1]; pass = pass.substring(0, pass.length() - 1); } catch (Exception e) {
	 * 
	 * HTMLReport.updateErrorMessageintoHTMLReport("Cause : " + e,
	 * "Generic Exception Raised", "Kindly Check getServiceAccountPassword method");
	 * log.error("Generic Exception Raised, Check getServiceAccountPassword method",
	 * e); }
	 

		return pass;
	}


	public static Map<String, Object> getPasswd(String nameSpace, String roleId, 
			String secretId, String accountPath) {
		String data = "";
		Map<String,Object> map = null;
		try {
			VaultPass vault = new VaultPass();
			data = vault.getVaultPass(nameSpace, roleId, secretId, accountPath);

			log.info("Response from Vault : "+data);

			Gson gSon = new Gson();
			map = gSon.fromJson(data, Map.class);

			map.entrySet().stream()
			.forEach(e -> log.info("Key :"+e.getKey()+"--- Value :"+e.getValue()));


		} catch (Exception e) {


			log.error("Generic Exception Raised, Check getPasswordVault method", e);
		}

		return map;
	}*/
}
