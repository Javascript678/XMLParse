package helper;

import java.nio.file.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class CreateFile {
	public static List<File> outputfile(String str,List<String> jobname) throws IOException {
		List<File> filelst= new ArrayList<File>();
		File files=null;
		LocalDateTime dte= LocalDateTime.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
	String time=	dte.format(formatter);
		
		File file = new File(System.getProperty("user.dir")+"\\Output");
		if(file.exists()) {
			System.out.println("exists");
		}
		else {
			file.mkdirs();
		}
		
for(int i=0;i<jobname.size();i++) {		
		files = new File(file+"\\"+jobname.get(i)+"output_"+time+".txt");
			FileWriter writer= new FileWriter(files);
			writer.write(str);
			writer.flush();
			filelst.add(files);
}
			
		return filelst;
		
	}
	
	public static  List<File> logsfile(String str,List<String> jobname) throws IOException {
		List<File> filelst= new ArrayList<File>();
		File files=null;
		LocalDateTime dte= LocalDateTime.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
	String time=	dte.format(formatter);
		
		
		//File file = new File(System.getProperty("user.dir")+"\\LOG");
		File file = new File(System.getProperty("user.dir")+"//LOG");
		if(file.exists()) {
			System.out.println("exists");
			
		}
		else {
			file.mkdirs();
		}
		for(int i=0;i<jobname.size();i++) {
		 files = new File(file+"//"+jobname.get(i)+"logs_"+time+".txt");
			FileWriter writer= new FileWriter(files);
			writer.write(str);
			writer.flush();
			filelst.add(files);
		}
			
		return filelst;
	}

	
}
