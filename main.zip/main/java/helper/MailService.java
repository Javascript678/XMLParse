package helper;

import static io.restassured.RestAssured.given;

import java.io.File;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;


public class MailService {
	static final Logger log = LogManager.getLogger(MailService.class);

	public static void PushRequest(String toEmail, String bodyText, String ccemail,List<File> file,List<File> file2)    
	{   		
		try {
			//ReadFile.readdata("");
			RestAssured.baseURI = "https://mailservice.cfp.isus.emc.com";

			RequestSpecification req = RestAssured.given();
		
					req.headers("content-Type","multipart/form-data");
					req.relaxedHTTPSValidation();
					for(int i=0;i<file.size();i++) {
					req.multiPart("attachments", file.get(i));
					req.multiPart("attachments", file2.get(i));
					}
					req.multiPart("mailData", PayloadMail.payload(toEmail,bodyText,ccemail));
					 Response res=req.post("/infra/mail/emailAttachments");
					 res.getBody().asPrettyString();
					//res.log().all().assertThat().statusCode(200).extract().asString();

			//System.out.println(response);
		}
		
		catch(Exception e) {
		//	log.error("Generic Excpetion at MailerService PushRequest method: " ,e);
			System.out.println("Generic Excpetion at MailerService PushRequest method: ");
			e.printStackTrace();
			Assert.fail();
		}
	}
	
/*public static void main(String[] args) {
	new MailService().PushRequest("nanda_kishore_reddy@dellteam.com", "HI Hello please work", "anupam_chandan@dellteam.com", new File("C:\\Users\\nanda_kishore_reddy\\Downloads\\API\\API\\Output\\output_20211112144229.txt"));
	
}
*/
}