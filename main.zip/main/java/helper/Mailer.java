package helper;
import java.io.IOException;
import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;

import ControlMAPI.API.ParseJsondata;
import RestAPI.CTM.individualAPIs.GetstatusafterJobRun;
import Services.TestFlow;


public class Mailer {


	static Connection conn;
	/*static int row =12;
	static int col=8;
	static Object[][] data = new Object[row][col];*/
	
	static int row;
	static int col;
	static int decisionCol;
	static Object[][] data;
	
	static Map<String, String> tableThresholdDetails = new HashMap<>();
	static List<String> targetTableName_threshold = new ArrayList<>();
	static List<String> tableThreshold = new ArrayList<>();
	static String[] tableNamesInOrder;
	
	static Object[][] statusFromConfigTable;

	static Map<String, Object> credentialsMap= new HashMap<>();
	static String memSQLPass = null;

	/**
	 * @author Meghana_B
	 * @dateModified 9/30/2021
	 * @method
	 * initialize the variables declared
	 */
	public static void initialize() {
		Map<String, String> tableDetails = new HashMap<>();
		Map<String,String> userDetails = new HashMap<>();
		
		tableDetails=Library.readConfigtoHashMap(System.getProperty("user.dir")+"/src/main/resource/tableDetails.properties");
		row=tableDetails.size();
		userDetails=Library.readConfigtoHashMap(System.getProperty("user.dir")+"/src/main/resource/Config.properties");
		String[] allColumns = userDetails.get("Column_Names").split(",");
		
		col=allColumns.length;
		data = new Object[row][col];
		tableNamesInOrder = new String[row];
		
		
		for(int m=0;m<allColumns.length;m++) {
			if(allColumns[m].equals("Status")) {
				decisionCol=m;
				break;
			}
		}
		
	
		//read and store the threshold values
		tableThresholdDetails=Library.readConfigtoHashMap(System.getProperty("user.dir")+"/src/main/resource/tableThreshold.properties");
		for (String key : tableThresholdDetails.keySet()) {
			targetTableName_threshold.add(key);
			tableThreshold.add(tableThresholdDetails.get(key));
		}
	}
	
	
	/**
	 * @author Meghana_B
	 * @dateModified 9/30/2021
	 * @method
	 * read data from ddl_refresh_state along with count difference and decisions for each record
	 * store the results in 2DArray data
	 * replace CASE_STAEMENT with targetTableName and Threshold
	 */
	/*
	 * public static void dataLoad() {
	 * 
	 * Object[][] data_temp; Map<String, String> tableOrderDetails = new
	 * HashMap<>();
	 * 
	 * try {
	 * 
	 * //build the case statement based on different threshold values String
	 * CASE_STATEMENT = "CASE "; for(int i=0;i<tableThresholdDetails.size();i++) {
	 * CASE_STATEMENT = CASE_STATEMENT +
	 * " WHEN abs(source_count-target_count) > "+tableThreshold.get(i)
	 * +" and CAST (job_rundate as Date) != CURRENT_DATE()"
	 * +" and target_ddl_table='"+targetTableName_threshold.get(i)
	 * +"' THEN \'NOTOKAY\' "; } CASE_STATEMENT= CASE_STATEMENT+
	 * " ELSE \'OKAY\' END AS \"Decision(Based on Count)\"";
	 * 
	 * //final query String fetchData_memSQLTable =
	 * Library.getVal("RefreshQuery").replace("CASE_STATEMENT", CASE_STATEMENT);
	 * System.out.println("-------------------------------------------------");
	 * System.out.println(fetchData_memSQLTable);
	 * 
	 * //connect to DB if(Library.getVal("wr_Environment").equals("SIT")) {
	 * 
	 * //SIT credentialsMap = Library.getPasswd(Library.getVal("nameSpace"),
	 * Library.getVal("role_id"), Library.getVal("secret_id"),
	 * Library.getVal("accountPath_DDMemSqlSIT"));
	 * 
	 * memSQLPass = credentialsMap.get(Library.getVal("MemSQLUser_SIT")).toString();
	 * System.out.println("memSQLPass SIT:"+memSQLPass);
	 * 
	 * conn = DBUtils.MemSQLconnect(Library.getVal("MemSQLHost_SIT"),
	 * Library.getVal("MemSQLDB_SIT"), Library.getVal("MemSQLUser_SIT"),
	 * memSQLPass,Library.getVal("MemSQLPort_SIT"));
	 * 
	 * } else if(Library.getVal("wr_Environment").equals("PROD")) {
	 * 
	 * //PROD credentialsMap = Library.getPasswd(Library.getVal("nameSpace"),
	 * Library.getVal("role_id"), Library.getVal("secret_id"),
	 * Library.getVal("accountPath_DDMemSqlProd"));
	 * 
	 * memSQLPass =
	 * credentialsMap.get(Library.getVal("MemSQLUser_PROD")).toString();
	 * 
	 * conn = DBUtils.MemSQLconnect(Library.getVal("MemSQLHost_PROD"),
	 * Library.getVal("MemSQLDB_PROD"), Library.getVal("MemSQLUser_PROD"),
	 * memSQLPass,Library.getVal("MemSQLPort_PROD"));
	 * 
	 * }
	 * 
	 * //run the query data_temp = DBUtils.get2DArrayDB(conn, fetchData_memSQLTable,
	 * row, col);
	 * 
	 * //read and store the table names in required order
	 * tableOrderDetails=Library.readConfigtoHashMap(System.getProperty("user.dir")+
	 * "/src/main/resource/tableOrder.properties");
	 * System.out.println("-----------tableOrderDetails:\n"+tableOrderDetails); for
	 * (Entry<String, String> entry : tableOrderDetails.entrySet()) {
	 * tableNamesInOrder[Integer.parseInt(entry.getValue())-1]=entry.getKey(); }
	 * 
	 * 
	 * //sort the query output in the expected order of tables for(int i=0;i<
	 * row;i++) { for(int j=0;j<col;j++) { data[i][j]= data_temp[i][j]; } }
	 * 
	 * 
	 * } catch (Exception e) { e.printStackTrace(); }
	 * 
	 * }
	 * 
	 *//**
	 * @author Anurag_Deb
	 * @method
	 * read data from ddl_refresh_state along with count difference and decisions for each record
	 * store the results in 2DArray data
	 * replace threshold only in the query
	 */
	public static void dataLoadThresholdReplace() {

		try {		
			if(Library.getVal("wr_Environment").equals("SIT")) {

				//SIT
				/*
				 * credentialsMap = Library.getPasswd(Library.getVal("nameSpace"),
				 * Library.getVal("role_id"), Library.getVal("secret_id"),
				 * Library.getVal("accountPath_DDMemSqlSIT"));
				 * 
				 * memSQLPass = credentialsMap.get(Library.getVal("MemSQLUser_SIT")).toString();
				 * System.out.println("memSQLPass SIT:"+memSQLPass);
				 * 
				 * conn = DBUtils.MemSQLconnect(Library.getVal("MemSQLHost_SIT"),
				 * Library.getVal("MemSQLDB_SIT"), Library.getVal("MemSQLUser_SIT"),
				 * memSQLPass,Library.getVal("MemSQLPort_SIT"));
				 * 
				 * } else if(Library.getVal("wr_Environment").equals("PROD")) {
				 * 
				 * //PROD credentialsMap = Library.getPasswd(Library.getVal("nameSpace"),
				 * Library.getVal("role_id"), Library.getVal("secret_id"),
				 * Library.getVal("accountPath_DDMemSqlProd"));
				 * 
				 * memSQLPass =
				 * credentialsMap.get(Library.getVal("MemSQLUser_PROD")).toString();
				 * 
				 * conn = DBUtils.MemSQLconnect(Library.getVal("MemSQLHost_PROD"),
				 * Library.getVal("MemSQLDB_PROD"), Library.getVal("MemSQLUser_PROD"),
				 * memSQLPass,Library.getVal("MemSQLPort_PROD"));
				 */
			}


			System.out.println(Library.getVal("RefreshQuery")
					.replace("@DecisionThreshold",Library.getVal("DecisionThreshold"))
					.replace("@Decision_ThresholdMaster",Library.getVal("Decision_ThresholdMaster"))
					.replace("@Decision_ThresholdLotQuoteSku",Library.getVal("Decision_ThresholdLotQuoteSku"))
					.replace("@Decision_ThresholdLotItemDetails",Library.getVal("Decision_ThresholdLotItemDetails"))
					.replace("@Decision_ThresholdPartQuoteSupp",Library.getVal("Decision_ThresholdPartQuoteSupp")));	

			/*
			 * data = DBUtils.get2DArrayDB(conn, Library.getVal("RefreshQuery")
			 * .replace("@DecisionThreshold",Library.getVal("DecisionThreshold"))
			 * .replace("@Decision_ThresholdMaster",Library.getVal(
			 * "Decision_ThresholdMaster"))
			 * .replace("@Decision_ThresholdLotQuoteSku",Library.getVal(
			 * "Decision_ThresholdLotQuoteSku"))
			 * .replace("@Decision_ThresholdLotItemDetails",Library.getVal(
			 * "Decision_ThresholdLotItemDetails"))
			 * .replace("@Decision_ThresholdPartQuoteSupp",Library.getVal(
			 * "Decision_ThresholdPartQuoteSupp")) , row, col);
			 */
			/*	for(int i =0; i<row;i++) {
    			for(int j =0; j<col;j++) {
    			System.out.print(data[i][j]+"     ");
    		}
    		System.out.println("");
    		}
			 */
		} catch (Exception e) {
			e.printStackTrace();
		}

	}


	/**
	 * @author Meghana_B
	 * @dateModified 9/30/2021
	 * @method
	 * read previous status/finalDecision from ddlo_daily_autojob_config
	 */
	/*	public static Object[][] statusLoadFromConfigTable(Map<String, String>UserDetails) {
		
		try {

			if(UserDetails.get("wr_Environment").equals("SIT")) {

				
				 * //SIT credentialsMap =
				 * Library.getPasswd(UserDetails.get("nameSpace"),UserDetails.get("role_id"),
				 * UserDetails.get("secret_id"), UserDetails.get("accountPath_DDMemSqlSIT"));
				 * 
				 * memSQLPass =
				 * credentialsMap.get(UserDetails.get("MemSQLUser_SIT")).toString();
				 * 
				 * conn = DBUtils.MemSQLconnect(UserDetails.get("MemSQLHost_SIT"),
				 * UserDetails.get("MemSQLDB_SIT"), UserDetails.get("MemSQLUser_SIT"),
				 * memSQLPass,UserDetails.get("MemSQLPort_SIT"));
				 
			}
			else if(UserDetails.get("wr_Environment").equals("PROD")) {
/*
				//PROD
				credentialsMap = Library.getPasswd(UserDetails.get("nameSpace"), UserDetails.get("role_id"),
						UserDetails.get("secret_id"), UserDetails.get("accountPath_DDMemSqlProd"));

				memSQLPass = credentialsMap.get(UserDetails.get("MemSQLUser_PROD")).toString(); 

				conn = DBUtils.MemSQLconnect(UserDetails.get("MemSQLHost_PROD"), UserDetails.get("MemSQLDB_PROD"), 
						UserDetails.get("MemSQLUser_PROD"), memSQLPass,UserDetails.get("MemSQLPort_PROD"));

			}

			System.out.println(UserDetails.get("getFinalDecisionQuery"));	

			//status,job_date,currentTimeStamp,minuteDiff - columns
			statusFromConfigTable = DBUtils.get2DArrayDB(conn,UserDetails.get("getFinalDecisionQuery"), 1, 4);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return statusFromConfigTable;
		
	}*/

	

	
	/**
	 * @author Anurag_Deb
	 * @LastModofiedBy Meghana_B
	 * @dateModified 9/30/2021
	 * @method
	 * opening lines for mail with Decision and thresholds
	 * @return
	 * opening lines for mail as String
	 * @throws IOException 
	 * @throws JsonMappingException 
	 * @throws JsonParseException 
	 */
	public static String decisionHTMLFormat() throws JsonParseException, JsonMappingException, IOException {

		boolean decisionFlag=getFinalDecision();	

		if (decisionFlag)
			return "<b style=\"color:green;font-family: Arial, sans-serif;\">Job execution is done successfully</b></br></br>"
			+ "</p>";
		else
			return  "<p style=\"color:red;font-family: Arial, sans-serif;\"> Job didn't ran successfully, please check the logs to identify the root cause</br></p>";

	}
	
	/**
	 * @author Anurag_Deb
	 * @LastModofiedBy Meghana_B
	 * @dateModified 9/30/2021
	 * @method
	 * opening lines for mail with Decision and thresholds
	 * @return
	 * opening lines for mail as String
	 * @throws IOException 
	 * @throws JsonMappingException 
	 * @throws JsonParseException 
	 */
	public static String decisionHTMLFormatOld() throws JsonParseException, JsonMappingException, IOException {

		boolean decisionFlag=getFinalDecision();

		if (decisionFlag)
			return "<b style=\"color:green;font-family: Arial, sans-serif;\">Data Looks Good</b></br></br>"
			+ "<b>Note</b> : Decision Threshold is 0 for Master tables, "
			+Library.getVal("Decision_ThresholdLotQuoteSku")+" for dell_lot_quote_sku, "
			+Library.getVal("Decision_ThresholdLotItemDetails")+" for dell_lot_item_details, "
			+Library.getVal("Decision_ThresholdPartQuoteSupp")+" for dell_low_part_quote_supportlty and "
			+Library.getVal("DecisionThreshold")+" for other tables</p>";
		else
			return  "<p style=\"color:red;font-family: Arial, sans-serif;\">Data has some issues. Kindly check below records.</br> "
			+ "<b>Note</b> : Decision Threshold is 0 for Master tables, "
			+Library.getVal("Decision_ThresholdLotQuoteSku")+" for dell_lot_quote_sku, "
			+Library.getVal("Decision_ThresholdLotItemDetails")+" for dell_lot_item_details, "
			+Library.getVal("Decision_ThresholdPartQuoteSupp")+" for dell_low_part_quote_supportlty and "
			+Library.getVal("DecisionThreshold")+" for other tables</p>";


	}

	/**
	 * @author Anurag_Deb
	 * @LastModofiedBy Meghana_B
	 * @dateModified 9/30/2021
	 * @method
	 * get finalDecision as boolean value
	 * @return
	 * boolean value
	 * @throws IOException 
	 * @throws JsonMappingException 
	 * @throws JsonParseException 
	 */
	public static boolean getFinalDecision() throws JsonParseException, JsonMappingException, IOException {

		boolean decisionFlag=false;

		for(int i =0; i<new ParseJsondata().getjobsfromfile().size();i++) {

			if(new GetstatusafterJobRun().getJobRunStatus.equalsIgnoreCase("ENDED OK")) {
				decisionFlag=true;
				break;
			}	
		}	
		return decisionFlag;
	}


	/**
	 * @author Anurag_Deb
	 * @LastModofiedBy Meghana_B
	 * @dateModified 9/30/2021
	 * @method
	 * build the table in html
	 * @return
	 * the html table as String
	 */
	public static String getHtml()
	{
		try
		{
			String messageBody = "Hi All,</br></br>"+decisionHTMLFormat()+"</br> </br> <font>The following are the records: </font><br><br>";
			//if (row == 0) return messageBody;
			String htmlTableStart = "<table style=\"border-collapse:collapse; text-align:center;\" >";
			String htmlTableEnd = "</table> </br></br></br><b>Note</b> :This email was generated by Mailing API. Kindly do not reply to it.";
			String htmlHeaderRowStart = "<tr style=\"background-color:#6FA1D2; color:#ffffff;\">";
			String htmlHeaderRowEnd = "</tr>";
			String htmlTrStart = "<tr style=\"color:#555555; \">";
			String htmlTrEnd = "</tr>";
			String htmlTdStart = "<td style=\" border-color:#5c87b2; border-style:solid; border-width:thin; padding: 5px;\">";
			String htmlTdEnd = "</td>";
			//String anchoroutputlink="<a href="+CreateFile.outputfile(OutputData.output)+">output link</a></br>  <a href="+CreateFile.logsfile(ReturnJobLogs.logs)+">log link</a>";
			messageBody += htmlTableStart;
			//column names
			messageBody += htmlHeaderRowStart;
			//List<String> columnName = new  ArrayList<String>({"FolderName", ""});
			//List<String> columnName= Arrays.asList({"FolderName","JobName","Status"});
			List<String> columnName= Arrays.asList("FolderName","JobName","Status");
			List<Object> jobdetail= Arrays.asList(new ParseJsondata().getdatafromfile(),new ParseJsondata().getjobsfromfile(),TestFlow.statuses);
			for(int strIndex=0;strIndex<columnName.size();strIndex++) {
				messageBody += htmlTdStart + columnName.get(strIndex) + htmlTdEnd;
			}
			messageBody += htmlHeaderRowEnd;
			//Loop all the rows from grid view and added to html td  
		/*	for (int i = 0; i < new ParseJSON().getJobName().size() ; i++)
			{*/
				
				for(int i=0;i<new ParseJsondata().getdatafromfile().size();i++) {
					messageBody = messageBody + htmlTrStart;
				for(int j =0; j<columnName.size();j++) {
					messageBody = messageBody + htmlTdStart + ((List<String>)jobdetail.get(j)).get(i) + htmlTdEnd; //adding the cell values

				}
				}
				/*
				 * messageBody = messageBody + htmlTrEnd; }
				 */
			messageBody = messageBody + htmlTableEnd;
			return messageBody; // return HTML Table as String from this function  
		}
		
		catch (Exception ex)
		{
			return null;
		}
	}

	
	/**
	 * @author Meghana_B
	 * @dateModified 9/30/2021
	 * @method
	 * mail body in case of script failure
	 * @return
	 * mail body as String
	 */
	public static String getHtmlScriptFailed(String errorDescription,String methodName)
	{
		try
		{	

			String messageBody = "";
			String openingLine = "Hi All,</br></br>";
			String errorLine1 = "<p style=\"color:red;font-family: Arial, sans-serif;\">The LOW to DDL data validation script has failed with the exception mentioned below:</br></br>";
			String errorLine2 = errorDescription+"</br></br>";
			String errorLine3 = "";

			if(methodName.contains("NullPointerException")) {
				errorLine3 = "Kindly Check if any of the input parameters related to DB Connection is blank"+"</p></br>";
			}
			else if(methodName.contains("PSQLException")||methodName.contains("GPConnect")) {
				errorLine3 = "Kindly Check if there is any issue with PostGre DB connection - DDL </p></br>";
			}
			else if(methodName.contains("OracleConnect")){
				errorLine3 = "Kindly Check if there is any issue with Oracle DB connection - LOW </p></br>";
			}
			else if(methodName.contains("MemSQLConnect")){
				errorLine3 = "Kindly Check if there is any issue with MemSQL DB connection - DD </p></br>";
			}

			String endingLine = "</br><b>Note</b> :This email was generated by Mailing API. Kindly do not reply to it.";

			messageBody = openingLine+errorLine1+errorLine2+errorLine3+endingLine;
			return messageBody; // return HTML body as String from this function  
		}
		catch (Exception ex)
		{
			return null;
		}
	}
	
	
	public static void dataLoad(List<Data> list) {

		Object[][] data_temp= new Object[row][col];
		
		 SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");  
		    Date date = new Date(); 
		    String Date = formatter.format(date);
		    Calendar cal1 = Calendar.getInstance();
		    cal1.setTime(date);
		    cal1.add(Calendar.DAY_OF_YEAR, -1);
		    Date previousDate = cal1.getTime();
		    String PreviousDate = formatter.format(previousDate);
		    
		try {
			int i=0;
			//sort the query output in the expected order of tables
			for (Data data : list) {

				data_temp[i][0]=data.getMsg();
				data_temp[i][1]=data.getSourceTable();
				data_temp[i][2]=data.getSourceCount();
				data_temp[i][3]=data.getDdlTable();
				data_temp[i][4]=data.getTargetCount();
				
				int difference = Integer.parseInt(data_temp[i][2].toString()) - Integer.parseInt(data_temp[i][4].toString());
				data_temp[i][5]=difference;
				
				data_temp[i][6]=data.getkafkaLoadDate();
				String loadDate = data_temp[i][6].toString();
				Date date1 = formatter.parse(loadDate);
				String kafkaLoadDate = formatter.format(date1);
				
				if(difference>0||difference <0 || ( !kafkaLoadDate.contains(Date) && !kafkaLoadDate.contains(PreviousDate)) ) { 					
					data_temp[i][7]="NOTOKAY";
				}
				else {
					data_temp[i][7]="OKAY";
				}
				
				i++;
			}
			data = data_temp;

		} catch (Exception e) {
			e.printStackTrace();
		}

	}




}

