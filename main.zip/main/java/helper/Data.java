package helper;

import java.util.ArrayList;
import java.util.List;

public class Data {

	private String ddlTable;
	private String sourceTable;
	private String msg;
	private String TargetCount;
	private String sourceCount;
	private String kafkaLoadDate ;

	public Data() {
	}

	public Data(String ddlTable, String msg, String targetCount, String sourceTable, String sourceCount) {
		this.setDdlTable(ddlTable);
		this.setMsg(msg);
		this.setTargetCount(targetCount);
		this.setSourceTable(sourceTable);
		this.setSourceCount(sourceCount);

	}

	public Data(String ddlTable, String msg) {
		this.ddlTable = ddlTable;

		this.setMsg(msg);

	}

	public Data(String ddlTable, String msg, String targetCount, String sourceTable, String sourceCount, String kafkaLoadDate) {

		this.setDdlTable(ddlTable);
		this.setMsg(msg);
		this.setTargetCount(targetCount);
		this.setSourceTable(sourceTable);
		this.setSourceCount(sourceCount);
		this.setkafkaLoadDate(kafkaLoadDate);
	}

	public String getDdlTable() {
		return ddlTable;
	}

	public void setDdlTable(String ddlTable) {
		this.ddlTable = ddlTable;
	}

	public String getSourceTable() {
		return sourceTable;
	}

	public void setSourceTable(String sourceTable) {
		this.sourceTable = sourceTable;
	}

	public String getTargetCount() {
		return TargetCount;
	}

	public void setTargetCount(String TargetCount) {
		this.TargetCount = TargetCount;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public String getSourceCount() {
		return sourceCount;
	}

	public void setSourceCount(String sourceCount) {
		this.sourceCount = sourceCount;
	}

	public String getkafkaLoadDate() {
		return kafkaLoadDate;
	}

	public void setkafkaLoadDate(String kafkaLoadDate) {
		this.kafkaLoadDate = kafkaLoadDate;
	}
	
	public static List<Data> getListData(List<String> target, List<String> msgList) {

		int count = 0;
		List<Data> listData = new ArrayList<>();
		System.out.println(target.size());
		while (count < target.size()) {

			System.out.println(target.get(count) + "--" + msgList.get(count));
			Data dataobj = new Data(target.get(count), msgList.get(count));

			listData.add(dataobj);
			count++;
		}

		System.out.println("getListData method completed");

		return listData;
	}

	public static List<Data> getListData(List<String> target, List<String> msgList, List<String> targetCount,
			List<String> sourceTable, List<String> sourceCount) {

		int count = 0;
		List<Data> listData = new ArrayList<>();
		System.out.println(target.size());
		while (count < target.size()) {

			// ddlTable, String msg, String targetCount, String sourceTable, String
			// sourceCount

			System.out.println(target.get(count)+"--"+ msgList.get(count)+
					"--"+ targetCount.get(count)+"--"+ sourceTable.get(count)+"--"+ sourceCount.get(count));
			
			Data dataobj = new Data(target.get(count), msgList.get(count), targetCount.get(count),
					sourceTable.get(count), sourceCount.get(count));
			System.out.println(dataobj);
			listData.add(dataobj);
			count++;
		}

		System.out.println("getListData method completed");

		return listData;
	}
	
	public static List<Data> getListData(List<String> target, List<String> msgList, List<String> targetCount,
			List<String> sourceTable, List<String> sourceCount , List <String>kafkaLoadDate) {

		int count = 0;
		List<Data> listData = new ArrayList<>();
		System.out.println(target.size());
		while (count < target.size()) {

			// ddlTable, String msg, String targetCount, String sourceTable, String
			// sourceCount

			System.out.println(target.get(count)+"--"+ msgList.get(count)+
					"--"+ targetCount.get(count)+"--"+ sourceTable.get(count)+"--"+ sourceCount.get(count)+"--"+kafkaLoadDate.get(count));
			
			Data dataobj = new Data(target.get(count), msgList.get(count), targetCount.get(count),
					sourceTable.get(count), sourceCount.get(count) ,kafkaLoadDate.get(count));
			System.out.println(dataobj);
			listData.add(dataobj);
			count++;
		}

		System.out.println("getListData method completed");

		return listData;
	}

	public static List<Data> getListData(List<Object> data) {

		int count = 1;
		List<Data> listData = new ArrayList<>();
		System.out.println(data.size());
		while (count < data.size()) {

			String splitData[] = data.get(count).toString().split(" - ");

			Data dataobj = new Data(splitData[0], splitData[1]);

			listData.add(dataobj);
			count++;
		}

		System.out.println("getListData method completed");

		return listData;
	}

	public String toString() {
		return String.format("%s - %s", ddlTable, sourceTable);
	}

}
