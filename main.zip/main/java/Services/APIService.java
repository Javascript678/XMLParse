package Services;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import ControlMAPI.API.ParseJsondata;

@Service
public class APIService {
public HashMap<String,String> callserviceTotriggerAPI(MultipartFile file) throws IOException, ClassNotFoundException, InterruptedException {
	ParseJsondata parse= new ParseJsondata();
	TestFlow tests= new TestFlow();
	HashMap<String,String> hm= new HashMap<String,String>();
	byte[] data= file.getBytes();
	//String username=parse.getvaluewithkey("Username");
	//String uploadpath="C:\\Users\\"+username+"\\Documents\\JSONdata\\";
	String uploadpath="C:\\Users\\Public\\JSONdata\\";
	if(new File(uploadpath).exists()) {
		System.out.println("exists");
	}
	else {
		new File(uploadpath).mkdir();
		System.out.println("created");
	}
	System.out.println(file.getResource().getFilename());
	 String filename=file.getOriginalFilename();
Path path=	 Paths.get(uploadpath+filename);
Files.write(path, data);
System.out.println(path);
	 //System.out.println(file.getInputStream().read());
	 System.out.println(file.getResource().isReadable());
	 //System.out.println(new CotrolmRestController().mapdata(new File(filename), Root.class));
	// new File(filename).delete();
	 ParseJsondata.file=path.toFile();
	hm=tests.jobsflowtillend();
	System.out.println("deleted"+ParseJsondata.file.delete());	
	return hm;
}

public HashMap<String, String> callserviceTotriggerAPIforRerun(MultipartFile file) throws IOException, ClassNotFoundException, InterruptedException {
	ParseJsondata parse= new ParseJsondata();
	TestFlow tests= new TestFlow();
	byte[] data= file.getBytes();
	//String username=parse.getvaluewithkey("Username");
	HashMap<String,String>hm= new HashMap<String,String>();
	//String uploadpath="C:\\Users\\"+username+"\\Documents\\JSONdata\\";
	String uploadpath="C:\\Users\\Public\\JSONdata\\";
	if(new File(uploadpath).exists()) {
		System.out.println("exists");
	}
	else {
		new File(uploadpath).mkdir();
		System.out.println("created");
	}
	System.out.println(file.getResource().getFilename());
	 String filename=file.getOriginalFilename();
Path path=	 Paths.get(uploadpath+filename);
Files.write(path, data);
System.out.println(path);
	 //System.out.println(file.getInputStream().read());
	 System.out.println(file.getResource().isReadable());
	 //System.out.println(new CotrolmRestController().mapdata(new File(filename), Root.class));
	// new File(filename).delete();
	 ParseJsondata.file=path.toFile();
hm=	tests.jobtoRerun();
	System.out.println("deleted"+ParseJsondata.file.delete());	
	return hm ;
}




}
