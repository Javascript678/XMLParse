package Services;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import ControlMAPI.API.ParseJsondata;
import RestAPI.CTM.individualAPIs.Fetchstatus;
import RestAPI.CTM.individualAPIs.GetstatusafterJobRun;
import RestAPI.CTM.individualAPIs.OrderJob;
import RestAPI.CTM.individualAPIs.OutputData;
import RestAPI.CTM.individualAPIs.Rerunjob;
import RestAPI.CTM.individualAPIs.ReturnJobLogs;
import RestAPI.CTM.individualAPIs.RunJob;
import RestAPI.CTM.individualAPIs.ScheduleJobsfromUI;
import RestAPI.CTM.individualAPIs.SessionCreation;
import RestAPI.CTM.individualAPIs.SetFree;
import helper.CreateFile;
import helper.MailService;
import helper.Mailer;

public class TestFlow {
	private ParseJsondata jsonparse;
	private OrderJob order;
	private static Logger logg= LogManager.getLogger(TestFlow.class);
	String token;
	public static List<String> statuses= new ArrayList<String>();
	
	public HashMap<String, String> jobtoRerun() throws ClassNotFoundException, FileNotFoundException, IOException, InterruptedException {
		jsonparse= new ParseJsondata();
		GetstatusafterJobRun getstatusafterjobrun= new GetstatusafterJobRun();
		String initialcount=null;
		String latercount=null;
		String oldjobid=null;
		//String jobid=null;
		String beforererunstatus=null;
		String afterrerunstatus=null;
		String finalstatus=null;
		HashMap<String,String> hmp= new HashMap<String,String>();
		OrderJob  order= new OrderJob();
		Fetchstatus fetchstatus= new Fetchstatus();
		ScheduleJobsfromUI schedulejobs= new ScheduleJobsfromUI();
		SetFree setfree = new SetFree();
		Rerunjob rerunjob= new Rerunjob();
		RunJob runjob= new RunJob();
		OutputData outputdata= new OutputData();
		ReturnJobLogs returnjoblogs= new ReturnJobLogs();
		for(String jobtopass:jsonparse.getjobsfromfile()) {
			logg.info("start of "+jobtopass+" "+ "job:");
		logg.info("Calling Session API for getting Token by passing user Credentials");
		token=SessionCreation.TokenGeneration(jsonparse.getvaluewithkey("Username").toLowerCase(),jsonparse.getvaluewithkey("password"));
		//checking status of job before ordering the job
		logg.info("Fetching old Jobid if jobname already exists");
		oldjobid=fetchstatus.getstatus(jobtopass, token);
		//oldjobid=fetchstatus.getstatus(readfile.readdata("JobName"), token);
		Thread.sleep(3000);
		//run the job after freeing
	logg.info("ReRunning the job now by calling ReRun API ");
	logg.info("checking status before rerunning the job");
	beforererunstatus=getstatusafterjobrun.getstatus(oldjobid, token);
	if(beforererunstatus.equalsIgnoreCase("Executing") ) {
		statuses.add(beforererunstatus);
		hmp.put(jobtopass, beforererunstatus);
		
	}
	else {
	if( beforererunstatus.equalsIgnoreCase("Ended ok") ) {
		logg.info("rerunning the job after checking the status");
		rerunjob.postjobtoreRun(token, oldjobid);
	}
	afterrerunstatus=getstatusafterjobrun.getstatus(oldjobid, token);
	logg.info("status of job before running the job after rerun: "+afterrerunstatus);
	if(afterrerunstatus.equalsIgnoreCase("wait Condition")){
		logg.info("running the job as status is in wait condition");
		runjob.postjobtoRun(token, oldjobid);
	}
		int j=0;
		while( j<100) {
			logg.info("waiting for 40 seconds to obtain EndTime after job rerun completion" + " with counter :"+j);
			Thread.sleep(40000);
			//fetchstatus.getendtime(readfile.readdata("JobName"), token)
			if(!(fetchstatus.getendtime(jobtopass, token).isEmpty())) {
				logg.info("Calling getstatus for a particular job");
				finalstatus=getstatusafterjobrun.getstatus(oldjobid, token);
				statuses.add(finalstatus);
				hmp.put(jobtopass, finalstatus);
		//logg.info("Fetched status of job after job ran" + getstatusafterjobrun.getstatus(jobid, token));
		//System.out.println("got the status after run ");
		//get the output of job
		logg.info("Calling Output API after job rerun");
		outputdata.getOutputData(token, oldjobid);
		//get the job logs
		logg.info("Calling log API to fetch the logs after job reran");
		returnjoblogs.getJobLog(token, oldjobid);
		j=100;
		break;
		}
			j++;
		}
		}
	logg.info("End of "+jobtopass+" "+ "job:");
		}
		if(((OutputData.outputdata==null) && (ReturnJobLogs.logdata==null))){
		MailService.PushRequest(jsonparse.getvaluewithkey("toemail"), Mailer.getHtml().replace("\"", "\\\""),jsonparse.getvaluewithkey("ccemail"),
				new CreateFile().outputfile("Executing",jsonparse.getjobsfromfile()),new CreateFile().logsfile("Executing",jsonparse.getjobsfromfile()));
		}
		else {
			MailService.PushRequest(jsonparse.getvaluewithkey("toemail"), Mailer.getHtml().replace("\"", "\\\""),jsonparse.getvaluewithkey("ccemail"),
					new CreateFile().outputfile(OutputData.outputdata,jsonparse.getjobsfromfile()),new CreateFile().logsfile(ReturnJobLogs.logdata,jsonparse.getjobsfromfile()));
		
		}
		return hmp;
	}

	@SuppressWarnings("static-access")
	public HashMap<String, String> jobsflowtillend() throws FileNotFoundException, IOException, InterruptedException, ClassNotFoundException {
		jsonparse= new ParseJsondata();
		GetstatusafterJobRun getstatusafterjobrun= new GetstatusafterJobRun();
		int i=0;
		String initialcount=null;
		String jobname=null;
		String latercount=null;
		String oldjobid=null;
		String jobid=null;
		String finalstatus=null;
		SessionCreation sessioncreation= new SessionCreation();
		HashMap<String,String> hmp = new HashMap<String,String>();
		OrderJob  order= new OrderJob();
		Fetchstatus fetchstatus= new Fetchstatus();
		ScheduleJobsfromUI schedulejobs= new ScheduleJobsfromUI();
		SetFree setfree = new SetFree();
		RunJob runjob= new RunJob();
		OutputData outputdata= new OutputData();
		ReturnJobLogs returnjoblogs= new ReturnJobLogs();
		for(int k=0;k<jsonparse.getjobsfromfile().size();k++) {
			logg.info("Starting "+k+""+ "job: "+jsonparse.getjobsfromfile().get(k));
		logg.info("Calling Session API for getting Token by passing user Credentials");
		//token= sessioncreation.getSessiontoken(jsonparse.getvaluewithkey("Username"),jsonparse.getvaluewithkey("password"));
		
		token=SessionCreation.TokenGeneration(jsonparse.getvaluewithkey("Username").toLowerCase(),jsonparse.getvaluewithkey("password"));
		//checking status of job before ordering the job
		logg.info("Calling Get Status API before ordering the Job");
		logg.info("Fetching old Jobid if jobname already exists");
		oldjobid=fetchstatus.getstatus(jsonparse.getjobsfromfile().get(k), token);
		jobname=jsonparse.getjobsfromfile().get(k);
		//oldjobid=fetchstatus.getstatus(readfile.readdata("JobName"), token);
		logg.info("Fetching total count of Job till now its ran");
		initialcount= fetchstatus.getcountofData(jsonparse.getjobsfromfile().get(k), token);
		//initialcount= fetchstatus.getcountofData(readfile.readdata("JobName"), token);
		//ordering the job
		logg.info("Calling Order API to order the job "+jsonparse.getjobsfromfile().get(k));
		//logg.info("Calling Order API to order the job "+readfile.readdata("JobName"));
		int code=order.orderJob(jsonparse.getjobsfromfile().get(k), jsonparse.getdatafromfile().get(k), jsonparse.getvaluewithkey("ctmserver"), token);
		// int code=order.orderJob(readfile.readdata("JobName"), readfile.readdata("FolderName"), readfile.readdata("ctmserver"), token);
		 if(code==401) {
			 //schedulejobs.postJobs();
			 logg.info("Ordering the Jobs through Sharepoint as user has no access to order the job through Control -M");
			 schedulejobs.postmultiplejobsIncludingSingle(jsonparse.getdatafromfile().get(k), jsonparse.getjobsfromfile().get(k));
			 //schedulejobs.postmultiplejobsIncludingSingle(parsejson.getFolderName(), parsejson.getJobName());
		 }
		 else {
			 logg.info("Ordered the Jobs through Control -M successfully");
		 }
		//Thread.sleep(30000);
		//fetching status of job after scheduling job through Sharepoint
		while ( i<100 ||(!jobid.isEmpty())) {
			logg.info("Waiting for 40seconds to get response from get Status API");
			Thread.sleep(40000);
			logg.info("Calling get status API to get latest count after ordering the job");
			latercount=fetchstatus.getcountofData(jsonparse.getjobsfromfile().get(k), token);	
			//latercount=fetchstatus.getcountofData(readfile.readdata("JobName"), token);	
			//Thread.sleep(30000);
			if(Integer.parseInt(latercount)>Integer.parseInt(initialcount)) {
				jobid=fetchstatus.getstatus(jsonparse.getjobsfromfile().get(k), token);
				//jobid=fetchstatus.getstatus(readfile.readdata("JobName"), token);
				i=100;
				logg.info("Latest Job Id is fetched :" +jobid);
				break;
			}
		//	System.out.println(" value of i "+ i);
			//System.out.println("jobid " + jobid);
			i++;
			//System.out.println("exiting the while loop");
			//Thread.sleep(40000);
		}
		//System.out.println("outof loop of while");
		//free thejob before running
		logg.info("Calling set Free API before running the job");
		setfree.postjobtoFreeState(token, jobid);
		Thread.sleep(3000);
		//run the job after freeing
	logg.info("Running the job now by calling RunNow API ");
		runjob.postjobtoRun(token, jobid);
		
		int j=0;
		while( j<10000) {
			logg.info("waiting for 40 seconds to obtain EndTime after job completion" + " with counter :"+j);
			Thread.sleep(40000);
			//fetchstatus.getendtime(readfile.readdata("JobName"), token)
			if(!(fetchstatus.getendtime(jsonparse.getjobsfromfile().get(k), token).isEmpty())) {
				logg.info("Calling getstatus for a particular job");
				finalstatus=getstatusafterjobrun.getstatus(jobid, token);
				statuses.add(finalstatus);
				hmp.put(jsonparse.getjobsfromfile().get(k), statuses.get(k));
		//logg.info("Fetched status of job after job ran" + getstatusafterjobrun.getstatus(jobid, token));
		//System.out.println("got the status after run ");
		//get the output of job
		logg.info("Calling Output API after job run");
		 outputdata.getOutputData(token, jobid);
		//get the job logs
		logg.info("Calling log API to fetch the logs after job ran");
		returnjoblogs.getJobLog(token, jobid);
		j=10000;
		break;
		}
			j++;
		}
		logg.info("End of "+k+" "+ "job:"+jsonparse.getjobsfromfile().get(k));
	}
		MailService.PushRequest(jsonparse.getvaluewithkey("toemail"), Mailer.getHtml().replace("\"", "\\\""),jsonparse.getvaluewithkey("ccemail"),
				new CreateFile().outputfile(OutputData.outputdata,jsonparse.getjobsfromfile()),new CreateFile().logsfile(ReturnJobLogs.logdata,jsonparse.getjobsfromfile()));
		return hmp;
	}
	
	
	
}
