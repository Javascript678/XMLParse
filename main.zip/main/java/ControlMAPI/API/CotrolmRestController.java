package ControlMAPI.API;


import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import Services.APIService;



@Controller
public class CotrolmRestController {
	 APIService apiservice;
	 
		/*
		 * @GetMapping("/") public String mainPage() { return "upload"; }
		 */
	//private TestFlow tests;
@PostMapping("/triggercontrolm")

public ResponseEntity<?>  triggerAPIforControlM(@RequestPart(value="file") MultipartFile file) throws FileNotFoundException, ClassNotFoundException, IOException, InterruptedException {
	apiservice= new APIService();
	HashMap<String,String> response= new HashMap<String,String>();
	response=apiservice.callserviceTotriggerAPI(file);
	return new ResponseEntity<>(response, HttpStatus.OK);
}

@PostMapping("/triggercontrolm/rerun")
public ResponseEntity<?> triggerAPIforControlMrerun(@RequestPart(value="file") MultipartFile file) throws FileNotFoundException, ClassNotFoundException, IOException, InterruptedException {
	apiservice= new APIService();
	HashMap<String,String> response= new HashMap<String,String>();
	//System.out.println("Server output "+apiservice.callserviceTotriggerAPIforRerun(file));
	response= apiservice.callserviceTotriggerAPIforRerun(file);
	return new ResponseEntity<>(response, HttpStatus.OK);
}

@PostMapping("/trigger")
public String triggerAPI(@RequestPart(value="name") String name) throws FileNotFoundException, ClassNotFoundException, IOException, InterruptedException {
	return name;
}
	
	
	


}
