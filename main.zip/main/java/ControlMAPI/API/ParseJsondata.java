package ControlMAPI.API;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class ParseJsondata {
	public static File file;
	public String getvaluewithkey(Object key) throws JsonParseException, JsonMappingException, IOException {
		ObjectMapper mapper = new ObjectMapper();
		List<String> Folder = new ArrayList<String>();
		@SuppressWarnings("unchecked")
		HashMap<Object,Object> hmp=	mapper.readValue(file, HashMap.class);
	//HashMap<Object,Object> hmp=	mapper.readValue(new File("C:\\Users\\nanda_kishore_reddy\\OneDrive - Dell Technologies\\Documents\\JSONdata\\Details.json"), HashMap.class);
	return hmp.get(key).toString();
	}
	public List<String> getdatafromfile() throws JsonParseException, JsonMappingException, IOException {
		ObjectMapper mapper = new ObjectMapper();
		Object key=null;
		List<String> Folder = new ArrayList<String>();
		@SuppressWarnings("unchecked")
		HashMap<Object,Object> hmp=	mapper.readValue(file, HashMap.class);
	//HashMap<Object,Object> hmp=	mapper.readValue(new File("C:\\Users\\nanda_kishore_reddy\\OneDrive - Dell Technologies\\Documents\\JSONdata\\Details.json"), HashMap.class);
	//System.out.println(hmp.get("username"));
	//System.out.println(hmp.get("jobs"));
	@SuppressWarnings("unchecked")
	List<Object> lst=(List<Object>) hmp.get("jobs");
	//System.out.println(lst.get(1));
	for(Object o: lst) {
 Iterator it=((HashMap)o).keySet().iterator();
 while(it.hasNext()) {
	 key=it.next();
	   Folder.add(key.toString());
 }
	
	 }
	 return Folder;
	}
	
	
	public List<String> getjobsfromfile() throws JsonParseException, JsonMappingException, IOException {
		ObjectMapper mapper = new ObjectMapper();
		Object key=null;
		String jobname=null;
		List<String> Jobname = new ArrayList<String>();
		HashMap<Object,Object> hmp=	mapper.readValue(file, HashMap.class);
	//HashMap<Object,Object> hmp=	mapper.readValue(new File("C:\\Users\\nanda_kishore_reddy\\OneDrive - Dell Technologies\\Documents\\JSONdata\\Details.json"), HashMap.class);
	//System.out.println(hmp.get("username"));
	//System.out.println(hmp.get("jobs"));
	List<Object> lst=(List<Object>) hmp.get("jobs");
	//System.out.println(lst.get(1));
	for(Object o: lst) {
 Iterator it=((HashMap)o).keySet().iterator();
 while(it.hasNext()) {
	 key=it.next();
	jobname= ((HashMap)o).get(key).toString();
	 Jobname.add(jobname);
 }
	
	 }
	  return Jobname;
	}
	
	
	




}