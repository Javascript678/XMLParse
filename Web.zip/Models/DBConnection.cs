﻿using System;
using System.Data;
using System.Configuration;
using Oracle.ManagedDataAccess.Client;
using System.Collections.Generic;
using System.Linq;

namespace PDFValidate.Models
{
    public class DBConnection
    {
        public DataTable AllData(String ConStringNm, String Query)
        {
            DataTable dtAll = new DataTable();


            //SQL DB Connection and fetch all data from Query.
            string x = "";
            try
            {
                x = ConfigurationManager.ConnectionStrings[ConStringNm].ConnectionString;
                using (OracleConnection _connection = new OracleConnection(x))
                {
                    //  Logging.addLog("Oracle connection is established.");
                    OracleCommand cmd = new OracleCommand(Query, _connection);
                    using (OracleDataAdapter oda = new OracleDataAdapter(cmd))
                    {
                        //  Logging.addLog("Fetching data from Oracle Database.");
                        DataSet ds = new DataSet();
                        oda.Fill(ds);
                        if (ds.Tables[0].Rows.Count > 0)
                        {
                            dtAll = ds.Tables[0];
                        }
                        else
                        {
                            DataColumn dc = new DataColumn("Error", typeof(String));
                            dtAll.Columns.Add(dc);
                            dtAll.Rows.Add("No Data");
                        }

                    }
                }
            }


            catch (Exception e)
            {
                DataColumn dc = new DataColumn("Error", typeof(String));
                dtAll.Columns.Add(dc);
                dtAll.Rows.Add(ConStringNm + " Connection String not available in Config for connection");
            }

            return dtAll;

        }

         public List<Dictionary<string, string>> fetchDBData(string query)
         {
             DBConnection dbConnection = new DBConnection();
             DataTable dtAll = new DataTable();
             dtAll = dbConnection.AllData("OMEGAConnectionGE4", query);
             //dtAll= dbConnection.AllData("OMEGAConnectionGE4", new Queries().productDetailsQuery());
             List<Dictionary<string, string>> lst = dtAll.AsEnumerable().Select(row => dtAll.Columns.Cast<DataColumn>().ToDictionary(
             column => column.ColumnName,
             column => row[column].ToString()
              )).ToList();
             return lst;

         }

       
    }


}
    
            
     