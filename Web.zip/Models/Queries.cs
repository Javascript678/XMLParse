﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PDFValidate.Models
{
    public class Queries
    {
        public String getQuery (string orderNo, string sku)
        {
            String purchaseIDquery = "SELECT OH.ATTRIBUTE3 AS DPID,  OH.ATTRIBUTE18 AS QUOTE_NO, OH.ORDERED_DATE,OH.ORDER_NUMBER, OS.ESTIMATED_DELIVERY_DATE FROM ONT.OE_ORDER_HEADERS_ALL OH, ONT.OE_ORDER_LINES_ALL OL, XXEOM.XXEOM_ORDER_STATUSES OS WHERE 1=1 AND OH.HEADER_ID=OL.HEADER_ID AND OL.HEADER_ID= OS.HEADER_ID AND OS.LINE_ID <=0 AND OH.ORDER_NUMBER IN ('"+orderNo+ "') AND OL.ORDERED_ITEM LIKE '"+ sku + "'";
            return purchaseIDquery;
        }

        public String productDetailsQuery(string orderNo)
        {
            String productDetailsquery = "SELECT OS.DESCRIPTION, OL.ORDERED_ITEM, OL.ORDERED_QUANTITY FROM XXEOM.XXEOM_INV_ITEM_ML_DESC OS, ONT.OE_ORDER_HEADERS_ALL OH, ONT.OE_ORDER_LINES_ALL OL WHERE 1=1 AND OH.HEADER_ID= OL.HEADER_ID AND OL.INVENTORY_ITEM_ID= OS.INVENTORY_ITEM_ID AND OS.LANG_CODE= 'EN' AND OH.ORDER_NUMBER IN ('" + orderNo + "') ORDER BY OL.ORDERED_ITEM";
            return productDetailsquery;
        }
    }
}