﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PDFValidate.Models
{
    public class ResultSet
    {
        public string description { get; set; }
        public string validation { get; set; }
        public string status { get; set; }

        public ResultSet resultSetValidation(string description, string actual, string expected)
        {
            
            ResultSet resultSet = new ResultSet();
            resultSet.status = actual.Trim().Equals(expected.Trim()) ? "Pass" : "Fail";
            resultSet.description = description;
            resultSet.validation = $"Actual Value:{actual.Trim()}, Expected value:{expected.Trim()}";          
            return resultSet;
        }

        internal ResultSet resultSetValidation(string v1, object p, string v2)
        {
            throw new NotImplementedException();
        }
    }

   
}