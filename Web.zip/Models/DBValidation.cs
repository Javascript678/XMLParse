﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Collections;
using System.ComponentModel;
using Newtonsoft.Json.Linq;
using NUnit.Framework;
using System.Globalization;


namespace PDFValidate.Models
{
    public class DBValidation
    {
        DBConnection dbConnection = new DBConnection();
        ProductDetails pddetails = new ProductDetails();
        Pdflogic pdfData = new Pdflogic();
        Queries queries = new Queries();
        List<Dictionary<string, string>> orderDataDB = null;
        ProductDetail productDetails;


        public List<ResultSet> DataValidation(string path)

        {
            string orderNo = "";
            string phoneno = "";
            string estimatedArriveByPDF = "";
            Dictionary<string, Object> lst = new Dictionary<string, Object>();
            Dictionary<string, string> orderDetailsDataPDF = pddetails.getdata(path); //Order details data from PDF
            Dictionary<string, string> PurchaseDetailsDataPDF = pdfData.getdata(path);
            ResultSet resultSet = new ResultSet();
            List<ResultSet> resultSetList = new List<ResultSet>();
            
            try
            {
                 productDetails = new Dryrun().GetdryrunData(path);
            }
            catch(IndexOutOfRangeException e1)
            {
                Console.WriteLine("SKU's are not present");
            }
            if (bool.Parse(PurchaseDetailsDataPDF["Installflag"])) {
                orderNo = PurchaseDetailsDataPDF["Order Number:"].Trim();
            }
            else {
                orderNo = orderDetailsDataPDF["Order Number: "].Trim();
            }
            /*string sku = productDetails.Skus[0].Sku;
            string sku1 = productDetails.Skus[1].Sku;
            string sku2 = productDetails.Skus[2].Sku;
            int x = productDetails.Skus.Count;
*/            //productDetails.Skus[2].
            RestAPI api = new RestAPI();
            JsonDataparser.Root data = api.GetDatafromAPI(orderNo);
            string dbrecord = getDBdatawithouttimeZone(data.Source.OrderDate.ToString().Trim());
           // orderDataDB = dbConnection.fetchDBData(queries.getQuery(orderNo, productDetails.Skus[0].Sku)); //order details from DB

            // List<Dictionary<string, string>> orderDataDB1 = dbConnection.fetchDBData(queries.productDetailsQuery(orderNo)); //order details from DB
            //string dbval = orderDataDB1[0]["ORDERED_ITEM"]; //value from DB

            // string dbrecord = getDBdatawithtimeZone(orderDataDB[0]["ORDERED_DATE"].Trim());

            string pdfRecord = getPDFData(PurchaseDetailsDataPDF["Purchased On"].Trim());//ordered date from PDF
            string estimatedDeliveryDateDB = getDBdatawithouttimeZone(data.Source.EstimatedDeliveryDate.ToString().Trim());
            //string estimatedDeliveryDateDB = getDBdatawithouttimeZone(orderDataDB[0]["ESTIMATED_DELIVERY_DATE"].Trim());
            if (bool.Parse(PurchaseDetailsDataPDF["Installflag"]))
            {
                estimatedArriveByPDF = getPDFData(PurchaseDetailsDataPDF["Estimated to Arrive By:"].Trim());
                phoneno = PurchaseDetailsDataPDF["Telephone Number"];
            }
            else {
                phoneno = PurchaseDetailsDataPDF["Phone Number"];
                estimatedArriveByPDF = getPDFData(orderDetailsDataPDF[" Estimated to Arrive By:"].Trim());//ordered date from PDF
            }
            resultSetList.Add(resultSet.resultSetValidation("Dell Purchanse ID Validation", data.Source.IrnNumber.ToString(), PurchaseDetailsDataPDF["Dell Purchase ID"]));
            resultSetList.Add(resultSet.resultSetValidation("Dell Quote Number Validation", data.Source.OrderHeader.EquoteNumber.ToString(), PurchaseDetailsDataPDF["eQuote Number"]));
            resultSetList.Add(resultSet.resultSetValidation("Dell Order Number Validation", data.Source.OrderNumber.ToString(), orderNo));
            resultSetList.Add(resultSet.resultSetValidation("Dell Ordered Date Validation", dbrecord, pdfRecord));
            resultSetList.Add(resultSet.resultSetValidation("Dell Estimated Delivery Date Validation", estimatedDeliveryDateDB, estimatedArriveByPDF));
            resultSetList.Add(resultSet.resultSetValidation("Organization Name Validation", data.Source.OrderCustomer.Customer[0].CustomerStore.BaseCustomerAddress[0].Organizationname.ToString(), PurchaseDetailsDataPDF["Company Name"]));
            resultSetList.Add(resultSet.resultSetValidation("Customer Name Validation", $"{data.Source.OrderCustomer.Customer[0].CustomerStore.BaseContact[0].PersonFirstName} {data.Source.OrderCustomer.Customer[0].CustomerStore.BaseContact[0].PersonLastName}", PurchaseDetailsDataPDF["Customer Name"]));
            resultSetList.Add(resultSet.resultSetValidation("Sales Rep Validation", data.Source.OrderHeader.LeadSalesrep.ToString(), PurchaseDetailsDataPDF["Sales Representative"]));
            resultSetList.Add(resultSet.resultSetValidation("Email Validation", data.Source.OrderHeader.LeadSalesrepEmail.ToString(), PurchaseDetailsDataPDF["Email"]));
            resultSetList.Add(resultSet.resultSetValidation("Sales Rep Phone Number Validation", data.Source.OrderHeader.SalesrepPhone.ToString(), phoneno));
            resultSetList.Add(resultSet.resultSetValidation("Bill To Address Validation", GetAddressData(data.Source.OrderCustomer.Customer[1].CustomerStore.BillCustomerAddress.ToString(), orderNo), PurchaseDetailsDataPDF["Bill To:"]));
            resultSetList.Add(resultSet.resultSetValidation("Ship To Address Validation", GetAddressData(data.Source.OrderCustomer.Customer[2].CustomerStore.ShipCustomerAddress.ToString(), orderNo), PurchaseDetailsDataPDF["Ship To:"]));
             if (bool.Parse(PurchaseDetailsDataPDF["Installflag"]))
            {
                resultSetList.Add(resultSet.resultSetValidation("Install At Address Validation", GetAddressData(data.Source.OrderCustomer.Customer[5].CustomerStore.InstallAtAddress.ToString(), orderNo), PurchaseDetailsDataPDF["Install At:"]));
                resultSetList.Add(resultSet.resultSetValidation("Shipping Method Validation", data.Source.OrderHeader.PremierBtsCfoLabel.ToString(), PurchaseDetailsDataPDF["Shipping Method:"]));
                resultSetList.Add(resultSet.resultSetValidation("SolutionName Validation", data.Source.OrderHeader.SolutionName.ToString(), PurchaseDetailsDataPDF["Solution Name:"]));

            }
            else
            {
                resultSetList.Add(resultSet.resultSetValidation("Delivery Address Validation", GetAddressData(data.Source.OrderCustomer.Customer[3].CustomerStore.DeliveryCustomerAddress.ToString(), orderNo), PurchaseDetailsDataPDF["Delivery Address:"]));
                resultSetList.Add(resultSet.resultSetValidation("IncoTerms Validation", data.Source.OrderHeader.IncotermDestination.ToString(), PurchaseDetailsDataPDF["Inco Terms:"]));
                resultSetList.Add(resultSet.resultSetValidation("Shipping Handling Validation", $"${data.Source.OrderHeader.Shipping_Amount.ToString()}.00", orderDetailsDataPDF["Shipping &/or Handling"]));
                resultSetList.Add(resultSet.resultSetValidation("Sub Total Validation", $"${float.Parse(data.Source.OrderHeader.PaymentAmount.ToString()) - int.Parse(data.Source.OrderHeader.Shipping_Amount.ToString())}", orderDetailsDataPDF["Subtotal"]));
                resultSetList.Add(resultSet.resultSetValidation("Total Amount Validation", $"${data.Source.OrderHeader.TotalAmount.ToString()}", PurchaseDetailsDataPDF["Total (USD)"]));
                resultSetList.Add(resultSet.resultSetValidation("Esitmated Tax Validation", $"${data.Source.OrderHeader.TaxesAmount.ToString()}0", orderDetailsDataPDF["Estimated Tax"]));

            }





            try
            {
                if (productDetails.ProductQty != null && productDetails.SubTotal != null && productDetails.UnitPrice != null
                    && productDetails.Skus.Count > 0)
                {
                    string sku = productDetails.Skus[0].Sku;
                    string sku1 = productDetails.Skus[1].Sku;
                    string sku2 = productDetails.Skus[2].Sku;
                    int x = productDetails.Skus.Count;
                    int count = data.Source.OrderLines.Items[0].Items.ItemData.Count;
                    for (int i = 0; i < count; i++)
                    {
                        for (int j = 0; j < productDetails.Skus.Count; j++)
                        {
                            if (i == 1 || i == 2)
                            {
                                continue;
                            }
                            string apiproduct = data.Source.OrderLines.Items[0].Items.ItemData[i].SkuNumber.ToString().Trim();
                            string apidescription = data.Source.OrderLines.Items[0].Items.ItemData[i].SkuDescription.ToString().Trim();
                            string apiquantity = data.Source.OrderLines.Items[0].Items.ItemData[i].OrderedQuantity.ToString().Trim();
                            if (apiproduct.Equals(productDetails.Skus[j].Sku))
                            {
                                if (productDetails.Skus[j].Description.Trim().Equals(apidescription) && productDetails.Skus[j].Qty.Trim().Equals(apiquantity))
                                {
                                    string apiSKUData = $"{apiproduct}|{apidescription}|{apiquantity}";
                                    string pdfSKUData = $"{productDetails.Skus[j].Sku}|{productDetails.Skus[j].Description}|{productDetails.Skus[j].Qty}";
                                    resultSetList.Add(resultSet.resultSetValidation("SKU's Validation", apiSKUData, pdfSKUData));

                                }
                            }
                        }
                    }
                }
            }
            catch(NullReferenceException e2)
            {
                Console.WriteLine("No SKU's exists");
            }
            return resultSetList;
        }

        public string getDBdatawithtimeZone(string dellPurchaseIDDB)
        {
            DateTime localtime = TimeZoneInfo.ConvertTimeFromUtc(DateTime.Parse(dellPurchaseIDDB), TimeZoneInfo.FindSystemTimeZoneById("Pacific Standard Time"));                                                               //string dellPurchaseIDPDF = PurchaseDetailsDataPDF["eQuote Number"].Trim();
            var items = localtime.ToString().Split(' ');
            string a = items[0];
            return a;
        }
        public string getDBdatawithouttimeZone(string dellPurchaseIDDB)
        {
            DateTime localtime = DateTime.Parse(dellPurchaseIDDB);                                                               //string dellPurchaseIDPDF = PurchaseDetailsDataPDF["eQuote Number"].Trim();
            var items = localtime.ToString().Split(' ');
            string a = items[0];
            return a;
        }

        public string getPDFData(string purchaseDetailsDatapdf)
        {
            //string dateString = PurchaseDetailsDataPDF["Purchased On"].Trim();//ordered date from PDF
            List<char> charsToRemove = new List<char>() { ',', '.' };
            charsToRemove.ForEach(c => purchaseDetailsDatapdf = purchaseDetailsDatapdf.Replace(c.ToString(), String.Empty));
            string formattedDate = DateTime.ParseExact(purchaseDetailsDatapdf, "MMM dd yyyy", CultureInfo.InvariantCulture).ToString("M/d/yyyy");
            return formattedDate;
        }

        public string GetAddressData(string address_value, string order)
        {
            JsonDataparser.Root data = new RestAPI().GetDatafromAPI(order);
            string line1 = "";
            string line2 = "";
            string contact_main = "";
            string customer_name = "";
            string City_name = "";
            string State_Code = "";
            string postal_code = "";
            String final_Address = "";
            if (address_value.Equals(data.Source.OrderCustomer.Customer[1].CustomerStore.BillCustomerAddress.ToString())) {
                contact_main = data.Source.OrderCustomer.Customer[1].CustomerStore.BillContact[0].ContactMain.ToString();
                customer_name = data.Source.OrderCustomer.Customer[1].CustomerName.ToString();
                line1 = data.Source.OrderCustomer.Customer[1].CustomerStore.BillCustomerAddress[0].Lineone.ToString();
                try
                {
                    if (!string.IsNullOrEmpty(data.Source.OrderCustomer.Customer[1].CustomerStore.BillCustomerAddress[0].Linetwo.ToString()))
                    {
                        line2 = data.Source.OrderCustomer.Customer[1].CustomerStore.BillCustomerAddress[0].Linetwo.ToString();
                    }
                }
                catch (NullReferenceException e)
                {
                    line2 = null;
                }
                City_name = data.Source.OrderCustomer.Customer[1].CustomerStore.BillCustomerAddress[0].Cityname.ToString();
                State_Code = data.Source.OrderCustomer.Customer[1].CustomerStore.BillCustomerAddress[0].Statecode.ToString();
                postal_code = data.Source.OrderCustomer.Customer[1].CustomerStore.BillCustomerAddress[0].Postalcode.ToString();
                if (line2 != null && line2 != "")
                {
                    final_Address = $"{contact_main} {customer_name} {line1} {line2} {City_name}, {State_Code}. {postal_code}";
                }
                else
                {
                    final_Address = $"{contact_main} {customer_name} {line1} {City_name}, {State_Code}. {postal_code}";
                }
            }
            else if (address_value.Equals(data.Source.OrderCustomer.Customer[2].CustomerStore.ShipCustomerAddress.ToString()))
            {
                contact_main = data.Source.OrderCustomer.Customer[2].CustomerStore.ShipContact[0].ContactMain.ToString();
                customer_name = data.Source.OrderCustomer.Customer[2].CustomerName.ToString();
                line1 = data.Source.OrderCustomer.Customer[2].CustomerStore.ShipCustomerAddress[0].Lineone.ToString();
                try
                {
                    line2 = data.Source.OrderCustomer.Customer[2].CustomerStore.ShipCustomerAddress[0].Linetwo.ToString();
                }
                catch (NullReferenceException e)
                {
                    line2 = null;
                }
                City_name = data.Source.OrderCustomer.Customer[2].CustomerStore.ShipCustomerAddress[0].Cityname.ToString();
                State_Code = data.Source.OrderCustomer.Customer[2].CustomerStore.ShipCustomerAddress[0].Statecode.ToString();
                postal_code = data.Source.OrderCustomer.Customer[2].CustomerStore.ShipCustomerAddress[0].Postalcode.ToString();
                if (line2 != null && line2 != "")
                {
                    final_Address = $"{contact_main} {customer_name} {line1} {line2} {City_name}, {State_Code}. {postal_code}";
                }
                else
                {
                    final_Address = $"{contact_main} {customer_name} {line1} {City_name}, {State_Code}. {postal_code}";
                }
            }
            try {
             if (address_value.Equals(data.Source.OrderCustomer.Customer[3].CustomerStore.DeliveryCustomerAddress.ToString()))
                {
                    contact_main = data.Source.OrderCustomer.Customer[3].CustomerStore.DeliveryContact[0].ContactMain.ToString();
                    customer_name = data.Source.OrderCustomer.Customer[3].CustomerName.ToString();
                    line1 = data.Source.OrderCustomer.Customer[3].CustomerStore.DeliveryCustomerAddress[0].Lineone.ToString();
                    line2 = data.Source.OrderCustomer.Customer[3].CustomerStore.DeliveryCustomerAddress[0].Linetwo.ToString();
                    City_name = data.Source.OrderCustomer.Customer[3].CustomerStore.DeliveryCustomerAddress[0].Cityname.ToString();
                    State_Code = data.Source.OrderCustomer.Customer[3].CustomerStore.DeliveryCustomerAddress[0].Statecode.ToString();
                    postal_code = data.Source.OrderCustomer.Customer[3].CustomerStore.DeliveryCustomerAddress[0].Postalcode.ToString();
                    if (line2 != null && line2 != "")
                    {
                        final_Address = $"{contact_main} {customer_name} {line1} {line2} {City_name}, {State_Code}. {postal_code}";
                    }
                    else
                    {
                        final_Address = $"{contact_main} {customer_name} {line1} {City_name}, {State_Code}. {postal_code}";
                    }
                }
            }

            catch (NullReferenceException e)
            {
                Console.WriteLine("No Delivery Address exists");
            }
            try
            {
                if (address_value.Equals(data.Source.OrderCustomer.Customer[5].CustomerStore.InstallAtAddress.ToString()))
                {
                    contact_main = data.Source.OrderCustomer.Customer[5].CustomerStore.InstallAtContact[0].ContactMain.ToString();
                    customer_name = data.Source.OrderCustomer.Customer[5].CustomerName.ToString();
                    line1 = data.Source.OrderCustomer.Customer[5].CustomerStore.InstallAtAddress[0].Lineone.ToString();
                    line2 = data.Source.OrderCustomer.Customer[5].CustomerStore.InstallAtAddress[0].Linetwo.ToString();
                    City_name = data.Source.OrderCustomer.Customer[5].CustomerStore.InstallAtAddress[0].Cityname.ToString();
                    State_Code = data.Source.OrderCustomer.Customer[5].CustomerStore.InstallAtAddress[0].Statecode.ToString();
                    postal_code = data.Source.OrderCustomer.Customer[5].CustomerStore.InstallAtAddress[0].Postalcode.ToString();
                    if (line2 != null && line2 != "")
                    {
                        final_Address = $"{contact_main} {customer_name} {line1} {line2} {City_name}, {State_Code}. {postal_code}";
                    }
                    else
                    {
                        final_Address = $"{contact_main} {customer_name} {line1} {City_name}, {State_Code}. {postal_code}";
                    }
                }
            }
            catch(NullReferenceException e)
            {
                Console.WriteLine("Install At no exists");
            }
            catch(ArgumentOutOfRangeException e1)
            {
                Console.WriteLine("Size issue");
            }

            return final_Address.Trim();


        }

    }


}
           

        

      
    

    
         
    
    
        
    
    

    


    