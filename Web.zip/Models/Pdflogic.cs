﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using  static UglyToad.PdfPig.PdfDocument;
using System.Text.RegularExpressions;
using UglyToad.PdfPig.DocumentLayoutAnalysis.WordExtractor;
using UglyToad.PdfPig.DocumentLayoutAnalysis.TextExtractor;
using PDFValidate.Controllers;
namespace PDFValidate.Models

{
    public class Pdflogic
    {
        private IReadOnlyList<UglyToad.PdfPig.Content.Hyperlink> links;
        PDFValidationController pdfcontroller = new PDFValidationController();
        public Dictionary<string, string> getdata(string path)
        {

            var stream = File.OpenRead(@path);
            UglyToad.PdfPig.PdfDocument document = UglyToad.PdfPig.PdfDocument.Open(stream, UglyToad.PdfPig.ParsingOptions.LenientParsingOff);

            var pageno = document.GetPage(1);

            Dictionary<string, string> dt = new Dictionary<string, string>();
            //var pageText = page.Text;
            var pageText = ContentOrderTextExtractor.GetText(pageno, true);
            char[] delims = new[] { '\n', '\n', '\r' };
            string[] lst1 = pageText.Split(delims);
            List<String> lst = new List<String>(lst1.ToList());
            /*for(int i=0;i<lst.Count;i++)
            {
                if (lst[i].Equals(""))
                {
                    lst.Remove(lst[i]);
                }
            }*/
            if (!(lst.Contains("Install At:")))
            {
                foreach (var value in lst)
                {
                    if (value.Contains(":") && (!value.Equals("Bill To:")) && (!value.Equals("Ship To:")) && (!value.Equals("Payment Method:")) && (!value.Equals("Delivery Address:")) && (!value.Equals("Inco Terms:")))
                    {
                        char[] delim = new[] { ':' };
                        dt.Add(value.Split(delim)[0], value.Split(delim)[1]);
                    }
                    else if (value.Contains("Bill To:") || (value.Contains("Ship To:")))
                    {
                        if (value.Equals("Bill To:"))
                        {
                            var data = parseData(pageText, "Bill To:", "Payment Method:");
                            dt.Add(value, data.Trim());
                        }
                        else
                        {

                            var data = parseData(pageText, "Ship To:", "Delivery Address:");
                            dt.Add(value, data.Trim());

                        }
                    }
                    else if (value.Contains("Payment Method:") || value.Contains("Delivery Address:") || value.Contains("Inco Terms:"))
                    {
                        if (value.Equals("Payment Method:"))
                        {

                            var data = parseData(pageText, "Payment Method:", "Ship To:");
                            dt.Add(value, data.Trim());

                        }
                        else if (value.Equals("Delivery Address:"))
                        {
                            var data = parseData(pageText, "Delivery Address:", "Inco Terms:");
                            dt.Add(value, data.Trim());
                        }
                        else
                        {

                            dt.Add(value, lst[lst.Count - 1]);
                        }
                    }
                    
                }
                dt.Add("Installflag", "false");
            }

            else if (lst.Contains("Install At:"))
            {
                foreach (var value in lst)
                {
                    if (value.Contains(":") && (!value.Equals("Bill To:")) && (!value.Equals("Ship To:")) && (!value.Equals("Payment Method")) && (!value.Equals("Inco Terms:"))
                    && (!value.Equals("Install At:")) && (!value.Equals("Shipping Method:") && (!value.Equals("Solution Name:")) && (!value.Equals("Amount"))
                    &&(!value.Equals("Order Number:")) &&(!value.Equals("Estimated to Arrive By:"))))

                    {
                        char[] delim = new[] { ':' };
                        dt.Add(value.Split(delim)[0], value.Split(delim)[1]);
                    }
                    else if (value.Contains("Bill To:") || (value.Contains("Ship To:")))
                    {
                        if (value.Equals("Bill To:"))
                        {
                            var data = parseData(pageText, "Bill To:", "Shipping Method:");
                            dt.Add(value, data.Trim());
                        }
                        else
                        {

                            var data = parseData(pageText, "Ship To:", "Install At:");
                            dt.Add(value, data.Trim());

                        }
                    }
                    else if (value.Contains("Payment Method") || value.Contains("Install At:") ||
                        (value.Contains("Solution Name:")) ||(value.Contains("Amount")) ||
                        (value.Contains("Shipping Method:"))
                        )
                    {
                        if (value.Equals("Payment Method Amount"))
                        {

                            var data = parseData(pageText, "Payment Method Amount", "Order Number:");
                            dt.Add(value, data.Trim());

                        }

                        else if (value.Contains("Install At:"))
                            {
                            var data = parseData(pageText, "Install At:", "Bill To:");
                            dt.Add(value, data.Trim());

                        }

                        else if (value.Contains("Shipping Method:"))
                        {
                            var data = parseData(pageText, "Shipping Method:", "Solution Name:");
                            dt.Add(value, data.Trim());
                        }
                        else if(value.Equals("Solution Name:"))
                        {

                            var data = parseData(pageText, "Solution Name:", "Payment Method");
                            dt.Add(value, data.Trim());
                        }
                        else if (value.Equals("Amount"))
                        {
                            var data = parseData(pageText, "Amount", "Order Number:");
                            dt.Add(value, data);
                        }
                    }
                    else if (value.Contains("Order Number:") || (value.Contains("Estimated to Arrive By:")))
                    {
                        if (value.Contains("Order Number:"))
                            {
                            var data = parseData(pageText, "Order Number:", "Estimated to Arrive By:");
                            dt.Add(value, data);
                        }
                        else
                        {
                            var data = parseData(pageText, "Estimated to Arrive By:", "Qty Price Total");
                            dt.Add(value, data.Trim());
                        }
                    }

                }
                dt.Add("Installflag", "true");
            }




            return dt;
        }






        private string parseData(string actualText, string leftdata, string rightdata)
        {
            var data = actualText.Substring(actualText.IndexOf(leftdata), actualText.IndexOf(rightdata) - actualText.IndexOf(leftdata));
            data = data.Replace("\r\n", " ");
            data = data.Replace(leftdata, "");
            return data;
        }
/*
        public Dictionary<string, Object> getvalue()
        {
            Dictionary<string, Object> resultObject = new Dictionary<string, object>();
            Dryrun dryrun = new Dryrun();
            ProductDetail productdetail = new ProductDetail();
            productdetail = dryrun.GetdryrunData();
            ProductDetails pddetails = new ProductDetails();
            Dictionary<string, string> data = pddetails.getdata();
                      Pdflogic pdflogic = new Pdflogic();
            resultObject.Add("Product Estimation Details", data);
            resultObject.Add("Product Summary Details", productdetail);
            return resultObject;*/
        //}

    }
}








