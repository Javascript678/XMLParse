﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using RestSharp;
using RestSharp.Extensions;
using RestSharp.Authenticators;
using Newtonsoft;
using Newtonsoft.Json;

namespace PDFValidate.Models
{
    public class RestAPI
    {

        public JsonDataparser.Root  GetDatafromAPI(string Orderno)
        {
            RestClient rest = new RestClient("https://ordstr-ge4.orderstore.r1.pks.dell.com");
            RestRequest reque = new RestRequest("order/order_us/{pathid}");
            reque.AddHeader("Accept", "application/json");
            rest.Authenticator = new HttpBasicAuthenticator("rouser", "ronp#01");
            reque.AddUrlSegment("pathid", $"{Orderno}_{11}");
            reque.AddQueryParameter("routing", Orderno);
            RestResponse<JsonDataparser> response = rest.ExecuteGet<JsonDataparser>(reque);
            if (response.Content != null)
            {
                var data= response.Content;
                JsonDataparser.Root root =JsonConvert.DeserializeObject<JsonDataparser.Root>(data);
                return root;
            }
            else
            {
                return null;
            }
            
        }

        }
}