﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Newtonsoft.Json;

namespace PDFValidate.Models
{
    public class JsonDataparser
    {
        // Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(myJsonResponse);
        public class BaseContact
        {
            [JsonProperty("role_party_id")]
            public string RolePartyId { get; set; }

            [JsonProperty("person_last_name")]
            public string PersonLastName { get; set; }

            [JsonProperty("cfo_lang")]
            public string CfoLang { get; set; }

            [JsonProperty("contact_main_en")]
            public string ContactMainEn { get; set; }

            [JsonProperty("cust_account_role_id")]
            public string CustAccountRoleId { get; set; }

            [JsonProperty("contact_main")]
            public string ContactMain { get; set; }

            [JsonProperty("cam_location_id")]
            public string CamLocationId { get; set; }

            [JsonProperty("person_identifier")]
            public string PersonIdentifier { get; set; }

            [JsonProperty("src_identifiers")]
            public List<object> SrcIdentifiers { get; set; }

            [JsonProperty("contact_points")]
            public List<ContactPoint> ContactPoints { get; set; }

            [JsonProperty("contact_main_sl")]
            public string ContactMainSl { get; set; }

            [JsonProperty("contact_party_id")]
            public string ContactPartyId { get; set; }

            [JsonProperty("person_first_name")]
            public string PersonFirstName { get; set; }
        }

        public class BaseCustomerAddress
        {
            [JsonProperty("address_creation_date")]
            public DateTime AddressCreationDate { get; set; }

            [JsonProperty("description_category_code")]
            public string DescriptionCategoryCode { get; set; }

            [JsonProperty("customer_number")]
            public string CustomerNumber { get; set; }

            [JsonProperty("loc_orig_system_ref")]
            public string LocOrigSystemRef { get; set; }

            [JsonProperty("countrycode")]
            public string Countrycode { get; set; }

            [JsonProperty("customer_account_type")]
            public string CustomerAccountType { get; set; }

            [JsonProperty("geographic_country")]
            public string GeographicCountry { get; set; }

            [JsonProperty("statecode")]
            public string Statecode { get; set; }

            [JsonProperty("location_id")]
            public string LocationId { get; set; }

            [JsonProperty("party_number")]
            public string PartyNumber { get; set; }

            [JsonProperty("party_name")]
            public string PartyName { get; set; }

            [JsonProperty("cpf_flag")]
            public string CpfFlag { get; set; }

            [JsonProperty("postalcode")]
            public string Postalcode { get; set; }

            [JsonProperty("cust_account_id")]
            public string CustAccountId { get; set; }

            [JsonProperty("sub_channel")]
            public string SubChannel { get; set; }

            [JsonProperty("sales_channel_code")]
            public string SalesChannelCode { get; set; }

            [JsonProperty("customertype")]
            public string Customertype { get; set; }

            [JsonProperty("category_code")]
            public string CategoryCode { get; set; }

            [JsonProperty("origin_system_reference")]
            public string OriginSystemReference { get; set; }

            [JsonProperty("cityname")]
            public string Cityname { get; set; }

            [JsonProperty("countryname")]
            public string Countryname { get; set; }

            [JsonProperty("statename")]
            public string Statename { get; set; }

            [JsonProperty("sales_channel_method")]
            public string SalesChannelMethod { get; set; }

            [JsonProperty("sales_channel_description")]
            public string SalesChannelDescription { get; set; }

            [JsonProperty("channel_order_flag")]
            public string ChannelOrderFlag { get; set; }

            [JsonProperty("cust_account_role_id")]
            public string CustAccountRoleId { get; set; }

            [JsonProperty("cam_location_id")]
            public string CamLocationId { get; set; }

            [JsonProperty("organizationname")]
            public string Organizationname { get; set; }

            [JsonProperty("src_identifiers")]
            public List<object> SrcIdentifiers { get; set; }

            [JsonProperty("party_id")]
            public string PartyId { get; set; }

            [JsonProperty("lineone")]
            public string Lineone { get; set; }

            [JsonProperty("cust_acct_site_id")]
            public string CustAcctSiteId { get; set; }

            [JsonProperty("customer_creation_date")]
            public DateTime CustomerCreationDate { get; set; }
        }

        public class BillContact
        {
            [JsonProperty("role_party_id")]
            public string RolePartyId { get; set; }

            [JsonProperty("person_last_name")]
            public string PersonLastName { get; set; }

            [JsonProperty("cfo_lang")]
            public string CfoLang { get; set; }

            [JsonProperty("contact_main_en")]
            public string ContactMainEn { get; set; }

            [JsonProperty("cust_account_role_id")]
            public string CustAccountRoleId { get; set; }

            [JsonProperty("contact_main")]
            public string ContactMain { get; set; }

            [JsonProperty("cam_location_id")]
            public string CamLocationId { get; set; }

            [JsonProperty("person_identifier")]
            public string PersonIdentifier { get; set; }

            [JsonProperty("src_identifiers")]
            public List<object> SrcIdentifiers { get; set; }

            [JsonProperty("contact_points")]
            public List<ContactPoint> ContactPoints { get; set; }

            [JsonProperty("contact_main_sl")]
            public string ContactMainSl { get; set; }

            [JsonProperty("contact_party_id")]
            public string ContactPartyId { get; set; }

            [JsonProperty("person_first_name")]
            public string PersonFirstName { get; set; }
        }

        public class BillCustomerAddress
        {
            [JsonProperty("address_creation_date")]
            public DateTime AddressCreationDate { get; set; }

            [JsonProperty("description_category_code")]
            public string DescriptionCategoryCode { get; set; }

            [JsonProperty("site_use_id")]
            public string SiteUseId { get; set; }

            [JsonProperty("customer_number")]
            public string CustomerNumber { get; set; }

            [JsonProperty("loc_orig_system_ref")]
            public string LocOrigSystemRef { get; set; }

            [JsonProperty("countrycode")]
            public string Countrycode { get; set; }

            [JsonProperty("customer_account_type")]
            public string CustomerAccountType { get; set; }

            [JsonProperty("geographic_country")]
            public string GeographicCountry { get; set; }

            [JsonProperty("statecode")]
            public string Statecode { get; set; }

            [JsonProperty("location_id")]
            public string LocationId { get; set; }

            [JsonProperty("party_number")]
            public string PartyNumber { get; set; }

            [JsonProperty("party_name")]
            public string PartyName { get; set; }

            [JsonProperty("cpf_flag")]
            public string CpfFlag { get; set; }

            [JsonProperty("postalcode")]
            public string Postalcode { get; set; }

            [JsonProperty("cust_account_id")]
            public string CustAccountId { get; set; }

            [JsonProperty("sub_channel")]
            public string SubChannel { get; set; }

            [JsonProperty("sales_channel_code")]
            public string SalesChannelCode { get; set; }

            [JsonProperty("customertype")]
            public string Customertype { get; set; }

            [JsonProperty("category_code")]
            public string CategoryCode { get; set; }

            [JsonProperty("origin_system_reference")]
            public string OriginSystemReference { get; set; }

            [JsonProperty("cityname")]
            public string Cityname { get; set; }

            [JsonProperty("countryname")]
            public string Countryname { get; set; }

            [JsonProperty("statename")]
            public string Statename { get; set; }

            [JsonProperty("sales_channel_method")]
            public string SalesChannelMethod { get; set; }

            [JsonProperty("sales_channel_description")]
            public string SalesChannelDescription { get; set; }

            [JsonProperty("cam_location_id")]
            public string CamLocationId { get; set; }

            [JsonProperty("organizationname")]
            public string Organizationname { get; set; }

            [JsonProperty("src_identifiers")]
            public List<object> SrcIdentifiers { get; set; }

            [JsonProperty("party_id")]
            public string PartyId { get; set; }

            [JsonProperty("lineone")]
            public string Lineone { get; set; }

            [JsonProperty("linetwo")]
            public string Linetwo { get; set; }

            [JsonProperty("cust_acct_site_id")]
            public string CustAcctSiteId { get; set; }

            [JsonProperty("customer_creation_date")]
            public DateTime CustomerCreationDate { get; set; }

            [JsonProperty("status")]
            public string Status { get; set; }
        }

        public class ContactPoint
        {
            [JsonProperty("raw_phone_number")]
            public string RawPhoneNumber { get; set; }

            [JsonProperty("contact_point_id")]
            public string ContactPointId { get; set; }

            [JsonProperty("created_by_module")]
            public string CreatedByModule { get; set; }

            [JsonProperty("priorityranking")]
            public string Priorityranking { get; set; }

            [JsonProperty("primary_flag")]
            public string PrimaryFlag { get; set; }

            [JsonProperty("phone_number")]
            public string PhoneNumber { get; set; }

            [JsonProperty("phone_line_type")]
            public string PhoneLineType { get; set; }

            [JsonProperty("phone_area_code")]
            public string PhoneAreaCode { get; set; }

            [JsonProperty("contact_point_type")]
            public string ContactPointType { get; set; }

            [JsonProperty("status")]
            public string Status { get; set; }

            [JsonProperty("email_address")]
            public string EmailAddress { get; set; }
        }

        public class Customer
        {
            [JsonProperty("customer_sub_channel")]
            public string CustomerSubChannel { get; set; }

            [JsonProperty("contact_phone")]
            public List<string> ContactPhone { get; set; }

            [JsonProperty("customer_number")]
            public string CustomerNumber { get; set; }

            [JsonProperty("customer_first_name")]
            public string CustomerFirstName { get; set; }

            [JsonProperty("cust_address")]
            public List<string> CustAddress { get; set; }

            [JsonProperty("contact_postal_code")]
            public string ContactPostalCode { get; set; }

            [JsonProperty("customer_sales_channel_description")]
            public string CustomerSalesChannelDescription { get; set; }

            [JsonProperty("customer_last_name")]
            public string CustomerLastName { get; set; }

            [JsonProperty("customer_store")]
            public CustomerStore CustomerStore { get; set; }

            [JsonProperty("customer_sales_channel_method")]
            public string CustomerSalesChannelMethod { get; set; }

            [JsonProperty("customer_name")]
            public string CustomerName { get; set; }

            [JsonProperty("customer_address_type")]
            public string CustomerAddressType { get; set; }

            [JsonProperty("contact_mail")]
            public List<string> ContactMail { get; set; }
        }

        public class CustomerStore
        {
            [JsonProperty("base_customer_address")]
            public List<BaseCustomerAddress> BaseCustomerAddress { get; set; }

            [JsonProperty("base_contact")]
            public List<BaseContact> BaseContact { get; set; }

            [JsonProperty("bill_contact")]
            public List<BillContact> BillContact { get; set; }

            [JsonProperty("bill_customer_address")]
            public List<BillCustomerAddress> BillCustomerAddress { get; set; }

            [JsonProperty("ship_contact")]
            public List<ShipContact> ShipContact { get; set; }

            [JsonProperty("ship_customer_address")]
            public List<ShipCustomerAddress> ShipCustomerAddress { get; set; }

            [JsonProperty("direct_customer_address")]
            public List<DirectCustomerAddress> DirectCustomerAddress { get; set; }

            [JsonProperty("direct_contact")]
            public List<DirectContact> DirectContact { get; set; }

            [JsonProperty("reseller_address")]
            public List<ResellerAddress> ResellerAddress { get; set; }

            [JsonProperty("reseller_contact")]
            public List<ResellerContact> ResellerContact { get; set; }

            [JsonProperty("install_at_contact")]
            public List<InstallAtContact> InstallAtContact { get; set; }

            [JsonProperty("install_at_address")]
            public List<InstallAtAddress> InstallAtAddress { get; set; }

            [JsonProperty("delivery_customer_address")]
            public List<DeliveryCustomerAddress> DeliveryCustomerAddress;

            [JsonProperty("delivery_contact")]
            public List<DeliveryContact> DeliveryContact;
        }


        public class DeliveryContact
        {
            [JsonProperty("contact_main")]
            public string ContactMain;

            [JsonProperty("role_party_id")]
            public string RolePartyId;

            [JsonProperty("cam_location_id")]
            public string CamLocationId;

            [JsonProperty("person_last_name")]
            public string PersonLastName;

            [JsonProperty("person_identifier")]
            public string PersonIdentifier;

            [JsonProperty("cfo_lang")]
            public string CfoLang;

            [JsonProperty("contact_points")]
            public List<ContactPoint> ContactPoints;

            [JsonProperty("contact_main_en")]
            public string ContactMainEn;

            [JsonProperty("contact_main_sl")]
            public string ContactMainSl;

            [JsonProperty("contact_party_id")]
            public string ContactPartyId;

            [JsonProperty("person_first_name")]
            public string PersonFirstName;

            [JsonProperty("cust_account_role_id")]
            public string CustAccountRoleId;
        }

        public class DeliveryCustomerAddress
        {
            [JsonProperty("address_creation_date")]
            public DateTime AddressCreationDate;

            [JsonProperty("description_category_code")]
            public string DescriptionCategoryCode;

            [JsonProperty("site_use_id")]
            public string SiteUseId;

            [JsonProperty("customer_number")]
            public string CustomerNumber;

            [JsonProperty("loc_orig_system_ref")]
            public string LocOrigSystemRef;

            [JsonProperty("countrycode")]
            public string Countrycode;

            [JsonProperty("customer_account_type")]
            public string CustomerAccountType;

            [JsonProperty("geographic_country")]
            public string GeographicCountry;

            [JsonProperty("statecode")]
            public string Statecode;

            [JsonProperty("location_id")]
            public string LocationId;

            [JsonProperty("party_number")]
            public string PartyNumber;

            [JsonProperty("linetwo")]
            public string Linetwo;

            [JsonProperty("party_name")]
            public string PartyName;

            [JsonProperty("cpf_flag")]
            public string CpfFlag;

            [JsonProperty("postalcode")]
            public string Postalcode;

            [JsonProperty("cust_account_id")]
            public string CustAccountId;

            [JsonProperty("legal_name")]
            public string LegalName;

            [JsonProperty("sub_channel")]
            public string SubChannel;

            [JsonProperty("sales_channel_code")]
            public string SalesChannelCode;

            [JsonProperty("customertype")]
            public string Customertype;

            [JsonProperty("category_code")]
            public string CategoryCode;

            [JsonProperty("origin_system_reference")]
            public string OriginSystemReference;

            [JsonProperty("cityname")]
            public string Cityname;

            [JsonProperty("countryname")]
            public string Countryname;

            [JsonProperty("statename")]
            public string Statename;

            [JsonProperty("sales_channel_method")]
            public string SalesChannelMethod;

            [JsonProperty("sales_channel_description")]
            public string SalesChannelDescription;

            [JsonProperty("cam_location_id")]
            public string CamLocationId;

            [JsonProperty("organizationname")]
            public string Organizationname;

            [JsonProperty("party_id")]
            public string PartyId;

            [JsonProperty("lineone")]
            public string Lineone;

            [JsonProperty("cust_acct_site_id")]
            public string CustAcctSiteId;

            [JsonProperty("customer_creation_date")]
            public DateTime CustomerCreationDate;

            [JsonProperty("status")]
            public string Status;
        }





        public class DirectContact
        {
            [JsonProperty("role_party_id")]
            public string RolePartyId { get; set; }

            [JsonProperty("person_last_name")]
            public string PersonLastName { get; set; }

            [JsonProperty("cfo_lang")]
            public string CfoLang { get; set; }

            [JsonProperty("contact_main_en")]
            public string ContactMainEn { get; set; }

            [JsonProperty("cust_account_role_id")]
            public string CustAccountRoleId { get; set; }

            [JsonProperty("contact_main")]
            public string ContactMain { get; set; }

            [JsonProperty("cam_location_id")]
            public string CamLocationId { get; set; }

            [JsonProperty("person_identifier")]
            public string PersonIdentifier { get; set; }

            [JsonProperty("src_identifiers")]
            public List<object> SrcIdentifiers { get; set; }

            [JsonProperty("contact_points")]
            public List<ContactPoint> ContactPoints { get; set; }

            [JsonProperty("contact_main_sl")]
            public string ContactMainSl { get; set; }

            [JsonProperty("contact_party_id")]
            public string ContactPartyId { get; set; }

            [JsonProperty("person_first_name")]
            public string PersonFirstName { get; set; }
        }

        public class DirectCustomerAddress
        {
            [JsonProperty("address_creation_date")]
            public DateTime AddressCreationDate { get; set; }

            [JsonProperty("description_category_code")]
            public string DescriptionCategoryCode { get; set; }

            [JsonProperty("site_use_id")]
            public string SiteUseId { get; set; }

            [JsonProperty("customer_number")]
            public string CustomerNumber { get; set; }

            [JsonProperty("loc_orig_system_ref")]
            public string LocOrigSystemRef { get; set; }

            [JsonProperty("countrycode")]
            public string Countrycode { get; set; }

            [JsonProperty("customer_account_type")]
            public string CustomerAccountType { get; set; }

            [JsonProperty("geographic_country")]
            public string GeographicCountry { get; set; }

            [JsonProperty("statecode")]
            public string Statecode { get; set; }

            [JsonProperty("location_id")]
            public string LocationId { get; set; }

            [JsonProperty("party_number")]
            public string PartyNumber { get; set; }

            [JsonProperty("linetwo")]
            public string Linetwo { get; set; }

            [JsonProperty("party_name")]
            public string PartyName { get; set; }

            [JsonProperty("cpf_flag")]
            public string CpfFlag { get; set; }

            [JsonProperty("postalcode")]
            public string Postalcode { get; set; }

            [JsonProperty("cust_account_id")]
            public string CustAccountId { get; set; }

            [JsonProperty("sub_channel")]
            public string SubChannel { get; set; }

            [JsonProperty("sales_channel_code")]
            public string SalesChannelCode { get; set; }

            [JsonProperty("customertype")]
            public string Customertype { get; set; }

            [JsonProperty("category_code")]
            public string CategoryCode { get; set; }

            [JsonProperty("origin_system_reference")]
            public string OriginSystemReference { get; set; }

            [JsonProperty("cityname")]
            public string Cityname { get; set; }

            [JsonProperty("countryname")]
            public string Countryname { get; set; }

            [JsonProperty("statename")]
            public string Statename { get; set; }

            [JsonProperty("sales_channel_method")]
            public string SalesChannelMethod { get; set; }

            [JsonProperty("sales_channel_description")]
            public string SalesChannelDescription { get; set; }

            [JsonProperty("cam_location_id")]
            public string CamLocationId { get; set; }

            [JsonProperty("organizationname")]
            public string Organizationname { get; set; }

            [JsonProperty("src_identifiers")]
            public List<object> SrcIdentifiers { get; set; }

            [JsonProperty("party_id")]
            public string PartyId { get; set; }

            [JsonProperty("lineone")]
            public string Lineone { get; set; }

            [JsonProperty("cust_acct_site_id")]
            public string CustAcctSiteId { get; set; }

            [JsonProperty("customer_creation_date")]
            public DateTime CustomerCreationDate { get; set; }

            [JsonProperty("status")]
            public string Status { get; set; }
        }

        public class InstallAtAddress
        {
            [JsonProperty("address_creation_date")]
            public DateTime AddressCreationDate { get; set; }

            [JsonProperty("description_category_code")]
            public string DescriptionCategoryCode { get; set; }

            [JsonProperty("site_use_id")]
            public string SiteUseId { get; set; }

            [JsonProperty("customer_number")]
            public string CustomerNumber { get; set; }

            [JsonProperty("loc_orig_system_ref")]
            public string LocOrigSystemRef { get; set; }

            [JsonProperty("countrycode")]
            public string Countrycode { get; set; }

            [JsonProperty("customer_account_type")]
            public string CustomerAccountType { get; set; }

            [JsonProperty("geographic_country")]
            public string GeographicCountry { get; set; }

            [JsonProperty("statecode")]
            public string Statecode { get; set; }

            [JsonProperty("location_id")]
            public string LocationId { get; set; }

            [JsonProperty("party_number")]
            public string PartyNumber { get; set; }

            [JsonProperty("linetwo")]
            public string Linetwo { get; set; }

            [JsonProperty("party_name")]
            public string PartyName { get; set; }

            [JsonProperty("cpf_flag")]
            public string CpfFlag { get; set; }

            [JsonProperty("postalcode")]
            public string Postalcode { get; set; }

            [JsonProperty("cust_account_id")]
            public string CustAccountId { get; set; }

            [JsonProperty("sub_channel")]
            public string SubChannel { get; set; }

            [JsonProperty("sales_channel_code")]
            public string SalesChannelCode { get; set; }

            [JsonProperty("customertype")]
            public string Customertype { get; set; }

            [JsonProperty("category_code")]
            public string CategoryCode { get; set; }

            [JsonProperty("origin_system_reference")]
            public string OriginSystemReference { get; set; }

            [JsonProperty("cityname")]
            public string Cityname { get; set; }

            [JsonProperty("countryname")]
            public string Countryname { get; set; }

            [JsonProperty("statename")]
            public string Statename { get; set; }

            [JsonProperty("sales_channel_method")]
            public string SalesChannelMethod { get; set; }

            [JsonProperty("sales_channel_description")]
            public string SalesChannelDescription { get; set; }

            [JsonProperty("cam_location_id")]
            public string CamLocationId { get; set; }

            [JsonProperty("organizationname")]
            public string Organizationname { get; set; }

            [JsonProperty("src_identifiers")]
            public List<object> SrcIdentifiers { get; set; }

            [JsonProperty("party_id")]
            public string PartyId { get; set; }

            [JsonProperty("lineone")]
            public string Lineone { get; set; }

            [JsonProperty("cust_acct_site_id")]
            public string CustAcctSiteId { get; set; }

            [JsonProperty("customer_creation_date")]
            public DateTime CustomerCreationDate { get; set; }

            [JsonProperty("status")]
            public string Status { get; set; }
        }

        public class InstallAtContact
        {
            [JsonProperty("role_party_id")]
            public string RolePartyId { get; set; }

            [JsonProperty("person_last_name")]
            public string PersonLastName { get; set; }

            [JsonProperty("cfo_lang")]
            public string CfoLang { get; set; }

            [JsonProperty("contact_main_en")]
            public string ContactMainEn { get; set; }

            [JsonProperty("cust_account_role_id")]
            public string CustAccountRoleId { get; set; }

            [JsonProperty("contact_main")]
            public string ContactMain { get; set; }

            [JsonProperty("cam_location_id")]
            public string CamLocationId { get; set; }

            [JsonProperty("person_identifier")]
            public string PersonIdentifier { get; set; }

            [JsonProperty("src_identifiers")]
            public List<object> SrcIdentifiers { get; set; }

            [JsonProperty("contact_points")]
            public List<ContactPoint> ContactPoints { get; set; }

            [JsonProperty("contact_main_sl")]
            public string ContactMainSl { get; set; }

            [JsonProperty("contact_party_id")]
            public string ContactPartyId { get; set; }

            [JsonProperty("person_first_name")]
            public string PersonFirstName { get; set; }
        }

        public class Item
        {
            [JsonProperty("item")]
            public Item2 Items { get; set; }
        }

        public class Item2
        {
            [JsonProperty("product_desc_list")]
            public List<string> ProductDescList { get; set; }

            [JsonProperty("metadata")]
            public Metadata Metadata { get; set; }

            [JsonProperty("package")]
            public Package Package { get; set; }

            [JsonProperty("base_sku")]
            public string BaseSku { get; set; }

            [JsonProperty("actual_ship_date")]
            public string ActualShipDate { get; set; }

            [JsonProperty("sku_number_list")]
            public List<string> SkuNumberList { get; set; }

            [JsonProperty("tie_num")]
            public string TieNum { get; set; }

            [JsonProperty("sku_description")]
            public string SkuDescription { get; set; }

            [JsonProperty("tag_number_list")]
            public List<object> TagNumberList { get; set; }

            [JsonProperty("item_data")]
            public List<ItemDatum> ItemData { get; set; }
        }

        public class ItemDatum
        {
            [JsonProperty("xgacct_attrs")]
            public List<object> XgacctAttrs { get; set; }

            [JsonProperty("ordered_quantity")]
            public string OrderedQuantity { get; set; }

            [JsonProperty("sku_desc")]
            public string SkuDesc { get; set; }

            [JsonProperty("total_rounded_in_months")]
            public string TotalRoundedInMonths { get; set; }

            [JsonProperty("cost_currency_code")]
            public string CostCurrencyCode { get; set; }

            [JsonProperty("fulfilment_loc")]
            public string FulfilmentLoc { get; set; }

            [JsonProperty("aff_lob_code")]
            public string AffLobCode { get; set; }

            [JsonProperty("tax_group_sumary")]
            public List<TaxGroupSumary> TaxGroupSumary { get; set; }

            [JsonProperty("option_ids")]
            public string OptionIds { get; set; }

            [JsonProperty("shippable_flag")]
            public string ShippableFlag { get; set; }

            [JsonProperty("is_freight_sku")]
            public string IsFreightSku { get; set; }

            [JsonProperty("bst_flag")]
            public string BstFlag { get; set; }

            [JsonProperty("line_level_item_id")]
            public string LineLevelItemId { get; set; }

            [JsonProperty("service_tags")]
            public List<object> ServiceTags { get; set; }

            [JsonProperty("cfo_lang_sku_description")]
            public string CfoLangSkuDescription { get; set; }

            [JsonProperty("ip_owner")]
            public string IpOwner { get; set; }

            [JsonProperty("item_short_name")]
            public string ItemShortName { get; set; }

            [JsonProperty("original_fpc_cost_currency")]
            public string OriginalFpcCostCurrency { get; set; }

            [JsonProperty("margin")]
            public string Margin { get; set; }

            [JsonProperty("item_type_code_sku")]
            public string ItemTypeCodeSku { get; set; }

            [JsonProperty("option_number")]
            public string OptionNumber { get; set; }

            [JsonProperty("order_code")]
            public string OrderCode { get; set; }

            [JsonProperty("charges")]
            public List<object> Charges { get; set; }

            [JsonProperty("attribute5")]
            public string Attribute5 { get; set; }

            [JsonProperty("rollup_unit_price")]
            public string RollupUnitPrice { get; set; }

            [JsonProperty("attribute7")]
            public string Attribute7 { get; set; }

            [JsonProperty("sku_price")]
            public string SkuPrice { get; set; }

            [JsonProperty("attribute11")]
            public string Attribute11 { get; set; }

            [JsonProperty("mtc_code")]
            public string MtcCode { get; set; }

            [JsonProperty("fulfillmentlocid")]
            public string Fulfillmentlocid { get; set; }

            [JsonProperty("header_id")]
            public string HeaderId { get; set; }

            [JsonProperty("rollup_unit_list_price")]
            public string RollupUnitListPrice { get; set; }

            [JsonProperty("model_quantity")]
            public string ModelQuantity { get; set; }

            [JsonProperty("configmodeltype")]
            public string Configmodeltype { get; set; }

            [JsonProperty("inventory_item_id")]
            public string InventoryItemId { get; set; }

            [JsonProperty("renewal_sku_attrs")]
            public List<object> RenewalSkuAttrs { get; set; }

            [JsonProperty("unitdurandqtycostprice")]
            public string Unitdurandqtycostprice { get; set; }

            [JsonProperty("contract_value")]
            public string ContractValue { get; set; }

            [JsonProperty("top_model_line_id")]
            public string TopModelLineId { get; set; }

            [JsonProperty("option_class_description")]
            public string OptionClassDescription { get; set; }

            [JsonProperty("item_type_code")]
            public string ItemTypeCode { get; set; }

            [JsonProperty("sku_type")]
            public string SkuType { get; set; }

            [JsonProperty("serial_number")]
            public string SerialNumber { get; set; }

            [JsonProperty("item_name")]
            public string ItemName { get; set; }

            [JsonProperty("duration_in_months")]
            public string DurationInMonths { get; set; }

            [JsonProperty("transfer_price")]
            public string TransferPrice { get; set; }

            [JsonProperty("unitdurandqtysalesprice")]
            public string Unitdurandqtysalesprice { get; set; }

            [JsonProperty("cancelled_flag")]
            public string CancelledFlag { get; set; }

            [JsonProperty("unitdurandqtylistprice")]
            public string Unitdurandqtylistprice { get; set; }

            [JsonProperty("cancelled_quantity")]
            public string CancelledQuantity { get; set; }

            [JsonProperty("extendedwarrantyflag")]
            public string Extendedwarrantyflag { get; set; }

            [JsonProperty("price_adjustments")]
            public List<PriceAdjustment> PriceAdjustments { get; set; }

            [JsonProperty("xgaap_attrs")]
            public List<XgaapAttr> XgaapAttrs { get; set; }

            [JsonProperty("classificationcode")]
            public string Classificationcode { get; set; }

            [JsonProperty("item_type")]
            public string ItemType { get; set; }

            [JsonProperty("discount_amount")]
            public string DiscountAmount { get; set; }

            [JsonProperty("full_line_number")]
            public string FullLineNumber { get; set; }

            [JsonProperty("item_class_id")]
            public string ItemClassId { get; set; }

            [JsonProperty("wipsupply")]
            public string Wipsupply { get; set; }

            [JsonProperty("hsn_sac_code")]
            public string HsnSacCode { get; set; }

            [JsonProperty("unit_selling_price")]
            public string UnitSellingPrice { get; set; }

            [JsonProperty("order_quantity_uom")]
            public string OrderQuantityUom { get; set; }

            [JsonProperty("tax_row_summary")]
            public List<TaxRowSummary> TaxRowSummary { get; set; }

            [JsonProperty("mtc_prdtype")]
            public string MtcPrdtype { get; set; }

            [JsonProperty("lob_code")]
            public string LobCode { get; set; }

            [JsonProperty("original_fpc_cost")]
            public string OriginalFpcCost { get; set; }

            [JsonProperty("sku_description")]
            public string SkuDescription { get; set; }

            [JsonProperty("orig_sys_line_ref")]
            public string OrigSysLineRef { get; set; }

            [JsonProperty("dell_mfg_part_number")]
            public string DellMfgPartNumber { get; set; }

            [JsonProperty("cls_order")]
            public string ClsOrder { get; set; }

            [JsonProperty("commoditycode")]
            public string Commoditycode { get; set; }

            [JsonProperty("total_tax")]
            public string TotalTax { get; set; }

            [JsonProperty("vp_is_vpitem")]
            public string VpIsVpitem { get; set; }

            [JsonProperty("base_flag")]
            public string BaseFlag { get; set; }

            [JsonProperty("inst_sku")]
            public string InstSku { get; set; }

            [JsonProperty("unit_list_price")]
            public string UnitListPrice { get; set; }

            [JsonProperty("price_roll_up_flag")]
            public string PriceRollUpFlag { get; set; }

            [JsonProperty("is_flexi_sku")]
            public string IsFlexiSku { get; set; }

            [JsonProperty("org_id")]
            public string OrgId { get; set; }

            [JsonProperty("parts")]
            public List<object> Parts { get; set; }

            [JsonProperty("asn_item_id")]
            public string AsnItemId { get; set; }

            [JsonProperty("skucost")]
            public string Skucost { get; set; }

            [JsonProperty("rollup_extended_price")]
            public string RollupExtendedPrice { get; set; }

            [JsonProperty("line_id")]
            public string LineId { get; set; }

            [JsonProperty("duration_in_days")]
            public string DurationInDays { get; set; }

            [JsonProperty("cost_currency_rate_type")]
            public string CostCurrencyRateType { get; set; }

            [JsonProperty("model_description")]
            public string ModelDescription { get; set; }

            [JsonProperty("compensation_cost")]
            public string CompensationCost { get; set; }

            [JsonProperty("transactional_curr_code")]
            public string TransactionalCurrCode { get; set; }

            [JsonProperty("line_taxes")]
            public List<LineTaxis> LineTaxes { get; set; }

            [JsonProperty("sku_number")]
            public string SkuNumber { get; set; }

            [JsonProperty("discount_class_code")]
            public string DiscountClassCode { get; set; }

            [JsonProperty("personalizations")]
            public List<object> Personalizations { get; set; }

            [JsonProperty("link_to_line_id")]
            public string LinkToLineId { get; set; }

            [JsonProperty("tax_override_flag")]
            public string TaxOverrideFlag { get; set; }

            [JsonProperty("nbd_flag")]
            public string NbdFlag { get; set; }

            [JsonProperty("model_id")]
            public string ModelId { get; set; }

            [JsonProperty("serviceindicator")]
            public string Serviceindicator { get; set; }

            [JsonProperty("line_type_id")]
            public string LineTypeId { get; set; }

            [JsonProperty("ordered_date")]
            public DateTime OrderedDate { get; set; }

            [JsonProperty("lob_description")]
            public string LobDescription { get; set; }

            [JsonProperty("contract_labor_code")]
            public string ContractLaborCode { get; set; }

            [JsonProperty("service_provider_code")]
            public string ServiceProviderCode { get; set; }

            [JsonProperty("reverse_agency_flag")]
            public string ReverseAgencyFlag { get; set; }

            [JsonProperty("service_level_id")]
            public string ServiceLevelId { get; set; }

            [JsonProperty("roll_up")]
            public string RollUp { get; set; }
        }

        public class LineTaxis
        {
            [JsonProperty("code")]
            public string Code { get; set; }

            [JsonProperty("line_item_price_v")]
            public string LineItemPriceV { get; set; }

            [JsonProperty("description")]
            public string Description { get; set; }

            [JsonProperty("is_sabrix")]
            public string IsSabrix { get; set; }

            [JsonProperty("item_vat")]
            public string ItemVat { get; set; }

            [JsonProperty("taxable_country_name")]
            public string TaxableCountryName { get; set; }

            [JsonProperty("type")]
            public string Type { get; set; }

            [JsonProperty("line_net")]
            public string LineNet { get; set; }

            [JsonProperty("line_total")]
            public string LineTotal { get; set; }

            [JsonProperty("group_key")]
            public string GroupKey { get; set; }
        }

        public class LobDetails
        {
            [JsonProperty("skunum")]
            public string Skunum { get; set; }

            [JsonProperty("lob")]
            public string Lob { get; set; }
        }

        public class LocChannel
        {
            [JsonProperty("cc")]
            public string Cc { get; set; }

            [JsonProperty("bu")]
            public string Bu { get; set; }

            [JsonProperty("ff_location")]
            public string FfLocation { get; set; }

            [JsonProperty("le_user_conversion_type")]
            public string LeUserConversionType { get; set; }

            [JsonProperty("le")]
            public string Le { get; set; }

            [JsonProperty("legal_entity_name")]
            public string LegalEntityName { get; set; }
        }

        public class Metadata
        {
            [JsonProperty("merge_type")]
            public string MergeType { get; set; }

            [JsonProperty("order_udid")]
            public List<OrderUdid> OrderUdid { get; set; }

            [JsonProperty("workorder_history")]
            public List<WorkorderHistory> WorkorderHistory { get; set; }

            [JsonProperty("prodorder_list")]
            public List<ProdorderList> ProdorderList { get; set; }

            [JsonProperty("lob_details")]
            public LobDetails LobDetails { get; set; }
        }

        public class MultiPaymentTerm
        {
            [JsonProperty("amount")]
            public string Amount { get; set; }

            [JsonProperty("paycode")]
            public string Paycode { get; set; }

            [JsonProperty("payment_term_type")]
            public string PaymentTermType { get; set; }

            [JsonProperty("name")]
            public string Name { get; set; }

            [JsonProperty("payterm_group")]
            public string PaytermGroup { get; set; }
        }

        public class OrderBuildDetail
        {
            [JsonProperty("isparent")]
            public string Isparent { get; set; }

            [JsonProperty("chassis_id")]
            public string ChassisId { get; set; }

            [JsonProperty("build_no")]
            public string BuildNo { get; set; }
        }

        public class OrderCustomer
        {
            [JsonProperty("customer_snapshot_ref")]
            public string CustomerSnapshotRef { get; set; }

            [JsonProperty("customer")]
            public List<Customer> Customer { get; set; }
        }

        public class OrderHeader
        {
            [JsonProperty("sold_to_org_id")]
            public string SoldToOrgId { get; set; }

            [JsonProperty("premier_bts_cfo_label")]
            public string PremierBtsCfoLabel { get; set; }

            [JsonProperty("way_bill_numbers")]
            public List<object> WayBillNumbers { get; set; }

            [JsonProperty("direct_account_id")]
            public string DirectAccountId { get; set; }

            [JsonProperty("estimated_delivery_date")]
            public DateTime EstimatedDeliveryDate { get; set; }

            [JsonProperty("local_currency")]
            public string LocalCurrency { get; set; }

            [JsonProperty("hasfundingsrc")]
            public string Hasfundingsrc { get; set; }

            [JsonProperty("isasnenabled")]
            public string Isasnenabled { get; set; }

            [JsonProperty("ref_order_num")]
            public string RefOrderNum { get; set; }

            [JsonProperty("invoices")]
            public List<object> Invoices { get; set; }

            [JsonProperty("default_lang")]
            public string DefaultLang { get; set; }

            [JsonProperty("is_channel_service_card")]
            public string IsChannelServiceCard { get; set; }

            [JsonProperty("multipack_enabled")]
            public string MultipackEnabled { get; set; }

            [JsonProperty("lead_salesrep")]
            public string LeadSalesrep { get; set; }

            [JsonProperty("hide_bill_to")]
            public string HideBillTo { get; set; }

            [JsonProperty("islicencingproduct")]
            public string Islicencingproduct { get; set; }

            [JsonProperty("sub_channel")]
            public string SubChannel { get; set; }

            [JsonProperty("salesrep_fax")]
            public string SalesrepFax { get; set; }

            [JsonProperty("ack_delivery_method")]
            public string AckDeliveryMethod { get; set; }

            [JsonProperty("order_type_id")]
            public string OrderTypeId { get; set; }

            [JsonProperty("sales_channel")]
            public string SalesChannel { get; set; }

            [JsonProperty("payment_amount")]
            public string PaymentAmount { get; set; }

            [JsonProperty("sales_amount")]
            public string SalesAmount { get; set; }

            [JsonProperty("creation_date")]
            public DateTime CreationDate { get; set; }

            [JsonProperty("sales_channel_method")]
            public string SalesChannelMethod { get; set; }

            [JsonProperty("sales_channel_description")]
            public string SalesChannelDescription { get; set; }

            [JsonProperty("channelcode")]
            public string Channelcode { get; set; }

            [JsonProperty("salesrep_phone_ext")]
            public string SalesrepPhoneExt { get; set; }

            [JsonProperty("order_udid")]
            public List<OrderUdid> OrderUdid { get; set; }

            [JsonProperty("salesrep_phone")]
            public string SalesrepPhone { get; set; }

            [JsonProperty("cfo_format")]
            public string CfoFormat { get; set; }

            [JsonProperty("secondary_salesrep")]
            public List<SecondarySalesrep> SecondarySalesrep { get; set; }

            [JsonProperty("last_updated_datetime")]
            public DateTime LastUpdatedDatetime { get; set; }

            [JsonProperty("channel_id")]
            public string ChannelId { get; set; }

            [JsonProperty("emc_site_id")]
            public string EmcSiteId { get; set; }

            [JsonProperty("solution_version")]
            public string SolutionVersion { get; set; }

            [JsonProperty("ref_dpid")]
            public string RefDpid { get; set; }

            [JsonProperty("irn_number")]
            public string IrnNumber { get; set; }

            [JsonProperty("fd_auth")]
            public List<object> FdAuth { get; set; }

            [JsonProperty("header_id")]
            public string HeaderId { get; set; }

            [JsonProperty("user_conversion_type")]
            public string UserConversionType { get; set; }

            [JsonProperty("lead_time_details")]
            public string LeadTimeDetails { get; set; }

            [JsonProperty("brm_recurring_details")]
            public List<object> BrmRecurringDetails { get; set; }

            [JsonProperty("order_build_details")]
            public List<OrderBuildDetail> OrderBuildDetails { get; set; }

            [JsonProperty("exp_status_last_update_date")]
            public DateTime ExpStatusLastUpdateDate { get; set; }

            [JsonProperty("equote_number")]
            public string EquoteNumber { get; set; }

            [JsonProperty("geographic_country")]
            public string GeographicCountry { get; set; }

            [JsonProperty("mode_of_transport")]
            public string ModeOfTransport { get; set; }

            [JsonProperty("ship_method_meaning")]
            public string ShipMethodMeaning { get; set; }
            [JsonProperty("shipping_amount")]
            public string Shipping_Amount { get; set; }

            [JsonProperty("order_orig_system")]
            public string OrderOrigSystem { get; set; }

            [JsonProperty("consolidation_details")]
            public List<object> ConsolidationDetails { get; set; }

            [JsonProperty("aff_order_type")]
            public string AffOrderType { get; set; }

            [JsonProperty("booked_date")]
            public DateTime BookedDate { get; set; }

            [JsonProperty("paid_advance")]
            public string PaidAdvance { get; set; }

            [JsonProperty("tla_data")]
            public List<object> TlaData { get; set; }

            [JsonProperty("taxes_amount")]
            public string TaxesAmount { get; set; }

            [JsonProperty("full_partial_credit")]
            public string FullPartialCredit { get; set; }

            [JsonProperty("selling_entity")]
            public string SellingEntity { get; set; }

            [JsonProperty("usdtosellingcurrencyrate")]
            public string Usdtosellingcurrencyrate { get; set; }

            [JsonProperty("is_gop")]
            public string IsGop { get; set; }

            [JsonProperty("ship_to_contact_id")]
            public string ShipToContactId { get; set; }

            [JsonProperty("loc_channel")]
            public List<LocChannel> LocChannel { get; set; }

            [JsonProperty("freight_carrier_code")]
            public string FreightCarrierCode { get; set; }

            [JsonProperty("xxg_cfo_email_table_data")]
            public List<XxgCfoEmailTableDatum> XxgCfoEmailTableData { get; set; }

            [JsonProperty("order_date_time")]
            public DateTime OrderDateTime { get; set; }

            [JsonProperty("payment_term")]
            public string PaymentTerm { get; set; }

            [JsonProperty("lead_salesrep_badge")]
            public string LeadSalesrepBadge { get; set; }

            [JsonProperty("orderprocessingcode")]
            public string Orderprocessingcode { get; set; }

            [JsonProperty("shipping_method_description")]
            public string ShippingMethodDescription { get; set; }

            [JsonProperty("multisequenceindicator")]
            public string Multisequenceindicator { get; set; }

            [JsonProperty("orig_sys_document_ref")]
            public string OrigSysDocumentRef { get; set; }

            [JsonProperty("price_list_id")]
            public string PriceListId { get; set; }

            [JsonProperty("processor_salesrep")]
            public List<ProcessorSalesrep> ProcessorSalesrep { get; set; }

            [JsonProperty("customeracceptance")]
            public string Customeracceptance { get; set; }

            [JsonProperty("cust_trx_type_id")]
            public string CustTrxTypeId { get; set; }

            [JsonProperty("saved_by")]
            public string SavedBy { get; set; }

            [JsonProperty("vpn_flag")]
            public string VpnFlag { get; set; }

            [JsonProperty("ibu_id")]
            public string IbuId { get; set; }

            [JsonProperty("usdtolocalcurrencyrate")]
            public string Usdtolocalcurrencyrate { get; set; }

            [JsonProperty("orderclassificationcode")]
            public string Orderclassificationcode { get; set; }

            [JsonProperty("pp_details")]
            public List<object> PpDetails { get; set; }

            [JsonProperty("online_flag")]
            public string OnlineFlag { get; set; }

            [JsonProperty("invoice_to_org_id")]
            public string InvoiceToOrgId { get; set; }

            [JsonProperty("fulfillindicator")]
            public string Fulfillindicator { get; set; }

            [JsonProperty("multi_payment_terms")]
            public List<MultiPaymentTerm> MultiPaymentTerms { get; set; }

            [JsonProperty("salesrep_number")]
            public string SalesrepNumber { get; set; }

            [JsonProperty("classificationcode")]
            public string Classificationcode { get; set; }

            [JsonProperty("primary_payterm_group")]
            public string PrimaryPaytermGroup { get; set; }

            [JsonProperty("version_number")]
            public string VersionNumber { get; set; }

            [JsonProperty("payment_term_code")]
            public string PaymentTermCode { get; set; }

            [JsonProperty("solution_id")]
            public string SolutionId { get; set; }

            [JsonProperty("invoice_customization_flag")]
            public string InvoiceCustomizationFlag { get; set; }

            [JsonProperty("payment_term_id")]
            public string PaymentTermId { get; set; }

            [JsonProperty("ischannelasnenabled")]
            public string Ischannelasnenabled { get; set; }

            [JsonProperty("last_updated_by")]
            public string LastUpdatedBy { get; set; }

            [JsonProperty("exp_status")]
            public string ExpStatus { get; set; }

            [JsonProperty("order_type")]
            public string OrderType { get; set; }

            [JsonProperty("payment_method")]
            public string PaymentMethod { get; set; }

            [JsonProperty("incoterm_destination")]
            public string IncotermDestination { get; set; }

            [JsonProperty("sales_channel_code")]
            public string SalesChannelCode { get; set; }

            [JsonProperty("order_receipt_date")]
            public DateTime OrderReceiptDate { get; set; }

            [JsonProperty("pricelistdesc")]
            public string Pricelistdesc { get; set; }

            [JsonProperty("ship_to_org_id")]
            public string ShipToOrgId { get; set; }

            [JsonProperty("last_status_comment")]
            public string LastStatusComment { get; set; }

            [JsonProperty("le_type")]
            public string LeType { get; set; }

            [JsonProperty("created_by")]
            public string CreatedBy { get; set; }

            [JsonProperty("ispocenabled")]
            public string Ispocenabled { get; set; }

            [JsonProperty("ecommerceflag")]
            public string Ecommerceflag { get; set; }

            [JsonProperty("estimated_ship_date")]
            public DateTime EstimatedShipDate { get; set; }

            [JsonProperty("payment_term_cfo_description")]
            public string PaymentTermCfoDescription { get; set; }

            [JsonProperty("order_category_code")]
            public string OrderCategoryCode { get; set; }

            [JsonProperty("premier_bto_cfo_label")]
            public string PremierBtoCfoLabel { get; set; }

            [JsonProperty("total_amount")]
            public string TotalAmount { get; set; }

            [JsonProperty("lease_term")]
            public string LeaseTerm { get; set; }

            [JsonProperty("organization_id")]
            public string OrganizationId { get; set; }

            [JsonProperty("manufacturercode")]
            public string Manufacturercode { get; set; }

            [JsonProperty("region")]
            public string Region { get; set; }

            [JsonProperty("lead_salesrep_email")]
            public string LeadSalesrepEmail { get; set; }

            [JsonProperty("sales_rep_name")]
            public string SalesRepName { get; set; }

            [JsonProperty("last_status_date")]
            public DateTime LastStatusDate { get; set; }

            [JsonProperty("source_creator_id")]
            public string SourceCreatorId { get; set; }

            [JsonProperty("isupgrade")]
            public string Isupgrade { get; set; }

            [JsonProperty("channel_level_8")]
            public string ChannelLevel8 { get; set; }

            [JsonProperty("order_number")]
            public string OrderNumber { get; set; }

            [JsonProperty("solution_instance_id")]
            public string SolutionInstanceId { get; set; }

            [JsonProperty("bu_iso_code")]
            public string BuIsoCode { get; set; }

            [JsonProperty("invoiceable_flag")]
            public string InvoiceableFlag { get; set; }

            [JsonProperty("invoice_to_contact_id")]
            public string InvoiceToContactId { get; set; }

            [JsonProperty("solution_name")]
            public string SolutionName { get; set; }

            [JsonProperty("cons_status")]
            public string ConsStatus { get; set; }

            [JsonProperty("eco_fee")]
            public string EcoFee { get; set; }

            [JsonProperty("dpid_count")]
            public string DpidCount { get; set; }

            [JsonProperty("shippingcode")]
            public string Shippingcode { get; set; }

            [JsonProperty("transactional_curr_code")]
            public string TransactionalCurrCode { get; set; }

            [JsonProperty("miles_enrollment_flag")]
            public string MilesEnrollmentFlag { get; set; }

            [JsonProperty("secondary_lang")]
            public string SecondaryLang { get; set; }

            [JsonProperty("solution_group_id")]
            public string SolutionGroupId { get; set; }

            [JsonProperty("quote_num")]
            public string QuoteNum { get; set; }

            [JsonProperty("terms_description")]
            public string TermsDescription { get; set; }

            [JsonProperty("sold_to_contact_id")]
            public string SoldToContactId { get; set; }

            [JsonProperty("last_status")]
            public string LastStatus { get; set; }

            [JsonProperty("dell_org_id")]
            public string DellOrgId { get; set; }

            [JsonProperty("direct_role_id")]
            public string DirectRoleId { get; set; }

            [JsonProperty("cc_card")]
            public List<object> CcCard { get; set; }

            [JsonProperty("ar_clearing_acct")]
            public List<object> ArClearingAcct { get; set; }

            [JsonProperty("shipping_method_code")]
            public string ShippingMethodCode { get; set; }

            [JsonProperty("sec_currency_code")]
            public string SecCurrencyCode { get; set; }

            [JsonProperty("product_pricing_style")]
            public string ProductPricingStyle { get; set; }

            [JsonProperty("estimated_delivery_date_end")]
            public DateTime EstimatedDeliveryDateEnd { get; set; }

            [JsonProperty("salesrep_id")]
            public string SalesrepId { get; set; }

            [JsonProperty("order_source")]
            public string OrderSource { get; set; }

            [JsonProperty("request_date")]
            public DateTime RequestDate { get; set; }

            [JsonProperty("direct_site_use_id")]
            public string DirectSiteUseId { get; set; }

            [JsonProperty("used_flag")]
            public string UsedFlag { get; set; }

            [JsonProperty("ep_details")]
            public List<object> EpDetails { get; set; }

            [JsonProperty("freight_org_desc")]
            public string FreightOrgDesc { get; set; }

            [JsonProperty("salesrep_name")]
            public string SalesrepName { get; set; }
        }

        public class OrderLines
        {
            [JsonProperty("items")]
            public List<Item> Items { get; set; }

            [JsonProperty("lines_snapshot_ref")]
            public string LinesSnapshotRef { get; set; }
        }

        public class OrderStatus
        {
            [JsonProperty("status_code")]
            public string StatusCode { get; set; }

            [JsonProperty("status_snapshot_ref")]
            public string StatusSnapshotRef { get; set; }

            [JsonProperty("status_store")]
            public List<StatusStore> StatusStore { get; set; }

            [JsonProperty("status_code_bydate")]
            public string StatusCodeBydate { get; set; }
        }

        public class OrderUdid
        {
            [JsonProperty("new_udid")]
            public string NewUdid { get; set; }

            [JsonProperty("udid_update_date")]
            public DateTime UdidUpdateDate { get; set; }
        }

        public class Package
        {
            [JsonProperty("workorderid")]
            public string Workorderid { get; set; }

            [JsonProperty("workordershipto")]
            public string Workordershipto { get; set; }

            [JsonProperty("channelstatusdescription")]
            public string Channelstatusdescription { get; set; }

            [JsonProperty("workordertype")]
            public string Workordertype { get; set; }

            [JsonProperty("boxdetails")]
            public List<object> Boxdetails { get; set; }

            [JsonProperty("workorderstatus")]
            public string Workorderstatus { get; set; }

            [JsonProperty("channelstatus")]
            public string Channelstatus { get; set; }

            [JsonProperty("workorderstatusdescription")]
            public string Workorderstatusdescription { get; set; }
        }

        public class PriceAdjustment
        {
            [JsonProperty("tax_trans_amt")]
            public string TaxTransAmt { get; set; }

            [JsonProperty("tax_fee_description")]
            public string TaxFeeDescription { get; set; }

            [JsonProperty("erp_tax_code")]
            public string ErpTaxCode { get; set; }

            [JsonProperty("tax_authority_type")]
            public string TaxAuthorityType { get; set; }

            [JsonProperty("tax_rate")]
            public string TaxRate { get; set; }

            [JsonProperty("tax_type_code")]
            public string TaxTypeCode { get; set; }
        }

        public class ProcessorSalesrep
        {
            [JsonProperty("salesrep_phone")]
            public string SalesrepPhone { get; set; }

            [JsonProperty("salesrep_number")]
            public string SalesrepNumber { get; set; }

            [JsonProperty("salesrep_id")]
            public string SalesrepId { get; set; }

            [JsonProperty("salesrep_email")]
            public string SalesrepEmail { get; set; }

            [JsonProperty("sales_rep_full_name")]
            public string SalesRepFullName { get; set; }

            [JsonProperty("sales_rep_name")]
            public string SalesRepName { get; set; }

            [JsonProperty("salesrep_badge")]
            public string SalesrepBadge { get; set; }
        }

        public class ProdorderList
        {
            [JsonProperty("subchannel")]
            public string Subchannel { get; set; }

            [JsonProperty("hasfga")]
            public string Hasfga { get; set; }

            [JsonProperty("shiptofacility")]
            public string Shiptofacility { get; set; }

            [JsonProperty("buildtype")]
            public string Buildtype { get; set; }

            [JsonProperty("shipmode")]
            public string Shipmode { get; set; }

            [JsonProperty("kittingfacility")]
            public string Kittingfacility { get; set; }

            [JsonProperty("overpackfacility")]
            public string Overpackfacility { get; set; }

            [JsonProperty("channelcode")]
            public string Channelcode { get; set; }

            [JsonProperty("orderpriority")]
            public string Orderpriority { get; set; }

            [JsonProperty("statuscode")]
            public string Statuscode { get; set; }

            [JsonProperty("spamsfacility")]
            public string Spamsfacility { get; set; }

            [JsonProperty("isdirectship")]
            public string Isdirectship { get; set; }

            [JsonProperty("userprioritycode")]
            public string Userprioritycode { get; set; }

            [JsonProperty("isretail")]
            public string Isretail { get; set; }

            [JsonProperty("scheduledfacility")]
            public string Scheduledfacility { get; set; }

            [JsonProperty("prodordernum")]
            public string Prodordernum { get; set; }

            [JsonProperty("facility")]
            public string Facility { get; set; }
        }

        public class ResellerAddress
        {
            [JsonProperty("address_creation_date")]
            public DateTime AddressCreationDate { get; set; }

            [JsonProperty("description_category_code")]
            public string DescriptionCategoryCode { get; set; }

            [JsonProperty("site_use_id")]
            public string SiteUseId { get; set; }

            [JsonProperty("customer_number")]
            public string CustomerNumber { get; set; }

            [JsonProperty("loc_orig_system_ref")]
            public string LocOrigSystemRef { get; set; }

            [JsonProperty("countrycode")]
            public string Countrycode { get; set; }

            [JsonProperty("customer_account_type")]
            public string CustomerAccountType { get; set; }

            [JsonProperty("geographic_country")]
            public string GeographicCountry { get; set; }

            [JsonProperty("statecode")]
            public string Statecode { get; set; }

            [JsonProperty("location_id")]
            public string LocationId { get; set; }

            [JsonProperty("party_number")]
            public string PartyNumber { get; set; }

            [JsonProperty("party_name")]
            public string PartyName { get; set; }

            [JsonProperty("cpf_flag")]
            public string CpfFlag { get; set; }

            [JsonProperty("postalcode")]
            public string Postalcode { get; set; }

            [JsonProperty("cust_account_id")]
            public string CustAccountId { get; set; }

            [JsonProperty("sub_channel")]
            public string SubChannel { get; set; }

            [JsonProperty("sales_channel_code")]
            public string SalesChannelCode { get; set; }

            [JsonProperty("customertype")]
            public string Customertype { get; set; }

            [JsonProperty("category_code")]
            public string CategoryCode { get; set; }

            [JsonProperty("origin_system_reference")]
            public string OriginSystemReference { get; set; }

            [JsonProperty("cityname")]
            public string Cityname { get; set; }

            [JsonProperty("countryname")]
            public string Countryname { get; set; }

            [JsonProperty("statename")]
            public string Statename { get; set; }

            [JsonProperty("sales_channel_method")]
            public string SalesChannelMethod { get; set; }

            [JsonProperty("sales_channel_description")]
            public string SalesChannelDescription { get; set; }

            [JsonProperty("cam_location_id")]
            public string CamLocationId { get; set; }

            [JsonProperty("organizationname")]
            public string Organizationname { get; set; }

            [JsonProperty("src_identifiers")]
            public List<SrcIdentifier> SrcIdentifiers { get; set; }

            [JsonProperty("party_id")]
            public string PartyId { get; set; }

            [JsonProperty("lineone")]
            public string Lineone { get; set; }

            [JsonProperty("cust_acct_site_id")]
            public string CustAcctSiteId { get; set; }

            [JsonProperty("customer_creation_date")]
            public DateTime CustomerCreationDate { get; set; }

            [JsonProperty("status")]
            public string Status { get; set; }
        }

        public class ResellerContact
        {
            [JsonProperty("role_party_id")]
            public string RolePartyId { get; set; }

            [JsonProperty("person_last_name")]
            public string PersonLastName { get; set; }

            [JsonProperty("cfo_lang")]
            public string CfoLang { get; set; }

            [JsonProperty("contact_main_en")]
            public string ContactMainEn { get; set; }

            [JsonProperty("cust_account_role_id")]
            public string CustAccountRoleId { get; set; }

            [JsonProperty("contact_main")]
            public string ContactMain { get; set; }

            [JsonProperty("cam_location_id")]
            public string CamLocationId { get; set; }

            [JsonProperty("person_identifier")]
            public string PersonIdentifier { get; set; }

            [JsonProperty("src_identifiers")]
            public List<object> SrcIdentifiers { get; set; }

            [JsonProperty("contact_points")]
            public List<ContactPoint> ContactPoints { get; set; }

            [JsonProperty("contact_main_sl")]
            public string ContactMainSl { get; set; }

            [JsonProperty("contact_party_id")]
            public string ContactPartyId { get; set; }

            [JsonProperty("person_first_name")]
            public string PersonFirstName { get; set; }
        }

        public class Root
        {
            [JsonProperty("_index")]
            public string Index { get; set; }

            [JsonProperty("_type")]
            public string Type { get; set; }

            [JsonProperty("_id")]
            public string Id { get; set; }

            [JsonProperty("_version")]
            public int Version { get; set; }

            [JsonProperty("_seq_no")]
            public int SeqNo { get; set; }

            [JsonProperty("_primary_term")]
            public int PrimaryTerm { get; set; }

            [JsonProperty("_routing")]
            public string Routing { get; set; }

            [JsonProperty("found")]
            public bool Found { get; set; }

            [JsonProperty("_source")]
            public Source Source { get; set; }
        }

        public class SecondarySalesrep
        {
            [JsonProperty("salesrep_phone")]
            public string SalesrepPhone { get; set; }

            [JsonProperty("salesrep_number")]
            public string SalesrepNumber { get; set; }

            [JsonProperty("salesrep_id")]
            public string SalesrepId { get; set; }

            [JsonProperty("salesrep_email")]
            public string SalesrepEmail { get; set; }

            [JsonProperty("sales_rep_full_name")]
            public string SalesRepFullName { get; set; }

            [JsonProperty("sales_rep_name")]
            public string SalesRepName { get; set; }

            [JsonProperty("salesrep_badge")]
            public string SalesrepBadge { get; set; }
        }

        public class ShipContact
        {
            [JsonProperty("role_party_id")]
            public string RolePartyId { get; set; }

            [JsonProperty("person_last_name")]
            public string PersonLastName { get; set; }

            [JsonProperty("cfo_lang")]
            public string CfoLang { get; set; }

            [JsonProperty("contact_main_en")]
            public string ContactMainEn { get; set; }

            [JsonProperty("cust_account_role_id")]
            public string CustAccountRoleId { get; set; }

            [JsonProperty("contact_main")]
            public string ContactMain { get; set; }

            [JsonProperty("cam_location_id")]
            public string CamLocationId { get; set; }

            [JsonProperty("person_identifier")]
            public string PersonIdentifier { get; set; }

            [JsonProperty("src_identifiers")]
            public List<object> SrcIdentifiers { get; set; }

            [JsonProperty("contact_points")]
            public List<ContactPoint> ContactPoints { get; set; }

            [JsonProperty("contact_main_sl")]
            public string ContactMainSl { get; set; }

            [JsonProperty("contact_party_id")]
            public string ContactPartyId { get; set; }

            [JsonProperty("person_first_name")]
            public string PersonFirstName { get; set; }
        }

        public class ShipCustomerAddress
        {
            [JsonProperty("address_creation_date")]
            public DateTime AddressCreationDate { get; set; }

            [JsonProperty("description_category_code")]
            public string DescriptionCategoryCode { get; set; }

            [JsonProperty("site_use_id")]
            public string SiteUseId { get; set; }

            [JsonProperty("customer_number")]
            public string CustomerNumber { get; set; }

            [JsonProperty("loc_orig_system_ref")]
            public string LocOrigSystemRef { get; set; }

            [JsonProperty("countrycode")]
            public string Countrycode { get; set; }

            [JsonProperty("customer_account_type")]
            public string CustomerAccountType { get; set; }

            [JsonProperty("geographic_country")]
            public string GeographicCountry { get; set; }

            [JsonProperty("statecode")]
            public string Statecode { get; set; }

            [JsonProperty("location_id")]
            public string LocationId { get; set; }

            [JsonProperty("party_number")]
            public string PartyNumber { get; set; }

            [JsonProperty("party_name")]
            public string PartyName { get; set; }

            [JsonProperty("cpf_flag")]
            public string CpfFlag { get; set; }

            [JsonProperty("postalcode")]
            public string Postalcode { get; set; }

            [JsonProperty("cust_account_id")]
            public string CustAccountId { get; set; }

            [JsonProperty("sub_channel")]
            public string SubChannel { get; set; }

            [JsonProperty("sales_channel_code")]
            public string SalesChannelCode { get; set; }

            [JsonProperty("customertype")]
            public string Customertype { get; set; }

            [JsonProperty("category_code")]
            public string CategoryCode { get; set; }

            [JsonProperty("origin_system_reference")]
            public string OriginSystemReference { get; set; }

            [JsonProperty("cityname")]
            public string Cityname { get; set; }

            [JsonProperty("countryname")]
            public string Countryname { get; set; }

            [JsonProperty("statename")]
            public string Statename { get; set; }

            [JsonProperty("sales_channel_method")]
            public string SalesChannelMethod { get; set; }

            [JsonProperty("sales_channel_description")]
            public string SalesChannelDescription { get; set; }

            [JsonProperty("cam_location_id")]
            public string CamLocationId { get; set; }

            [JsonProperty("organizationname")]
            public string Organizationname { get; set; }

            [JsonProperty("src_identifiers")]
            public List<object> SrcIdentifiers { get; set; }

            [JsonProperty("party_id")]
            public string PartyId { get; set; }

            [JsonProperty("lineone")]
            public string Lineone { get; set; }

            [JsonProperty("linetwo")]
            public string Linetwo { get; set; }


            [JsonProperty("cust_acct_site_id")]
            public string CustAcctSiteId { get; set; }

            [JsonProperty("customer_creation_date")]
            public DateTime CustomerCreationDate { get; set; }

            [JsonProperty("status")]
            public string Status { get; set; }
        }

        public class Source
        {
            [JsonProperty("corr_id")]
            public string CorrId { get; set; }

            [JsonProperty("irn_number")]
            public string IrnNumber { get; set; }

            [JsonProperty("global_bu_id")]
            public string GlobalBuId { get; set; }

            [JsonProperty("metadata")]
            public Metadata Metadata { get; set; }

            [JsonProperty("order_number")]
            public string OrderNumber { get; set; }

            [JsonProperty("pay_code")]
            public string PayCode { get; set; }

            [JsonProperty("order_header")]
            public OrderHeader OrderHeader { get; set; }

            [JsonProperty("orig_sys_document_ref")]
            public string OrigSysDocumentRef { get; set; }

            [JsonProperty("payment_term_code")]
            public string PaymentTermCode { get; set; }

            [JsonProperty("estimated_delivery_date")]
            public DateTime EstimatedDeliveryDate { get; set; }

            [JsonProperty("sales_person_name")]
            public string SalesPersonName { get; set; }

            [JsonProperty("estimated_ship_date")]
            public DateTime EstimatedShipDate { get; set; }

            [JsonProperty("order_date")]
            public DateTime OrderDate { get; set; }

            [JsonProperty("country_code")]
            public string CountryCode { get; set; }

            [JsonProperty("order_status")]
            public OrderStatus OrderStatus { get; set; }

            [JsonProperty("order_customer")]
            public OrderCustomer OrderCustomer { get; set; }

            [JsonProperty("promised_delivery_date")]
            public DateTime PromisedDeliveryDate { get; set; }

            [JsonProperty("order_source")]
            public string OrderSource { get; set; }

            [JsonProperty("order_lines")]
            public OrderLines OrderLines { get; set; }

            [JsonProperty("payment_term_description")]
            public string PaymentTermDescription { get; set; }

            [JsonProperty("sales_person_number")]
            public string SalesPersonNumber { get; set; }

            [JsonProperty("header_snapshot_ref")]
            public string HeaderSnapshotRef { get; set; }

            [JsonProperty("estimated_delivery_date_max")]
            public DateTime EstimatedDeliveryDateMax { get; set; }
        }

        public class SrcIdentifier
        {
            [JsonProperty("account_number")]
            public string AccountNumber { get; set; }
        }

        public class StatusStore
        {
            [JsonProperty("status_description")]
            public string StatusDescription { get; set; }

            [JsonProperty("last_updated_by")]
            public string LastUpdatedBy { get; set; }

            [JsonProperty("status_code")]
            public string StatusCode { get; set; }

            [JsonProperty("status_datetime")]
            public DateTime StatusDatetime { get; set; }

            [JsonProperty("reason_description")]
            public string ReasonDescription { get; set; }

            [JsonProperty("reason_code")]
            public string ReasonCode { get; set; }
        }

        public class TaxGroupSumary
        {
            [JsonProperty("group_name")]
            public string GroupName { get; set; }

            [JsonProperty("group_tax_amount")]
            public string GroupTaxAmount { get; set; }

            [JsonProperty("group_key")]
            public string GroupKey { get; set; }
        }

        public class TaxRowSummary
        {
            [JsonProperty("tax_code")]
            public string TaxCode { get; set; }

            [JsonProperty("non_tax_amount")]
            public string NonTaxAmount { get; set; }

            [JsonProperty("erp_tax_code")]
            public string ErpTaxCode { get; set; }

            [JsonProperty("tax_authority_type")]
            public string TaxAuthorityType { get; set; }

            [JsonProperty("taxable_amount_alt")]
            public string TaxableAmountAlt { get; set; }
        }

        public class WorkorderHistory
        {
            [JsonProperty("workorderid")]
            public string Workorderid { get; set; }

            [JsonProperty("created_ts")]
            public string CreatedTs { get; set; }

            [JsonProperty("workordertype")]
            public string Workordertype { get; set; }

            [JsonProperty("wo_status_date_time")]
            public string WoStatusDateTime { get; set; }

            [JsonProperty("channelstatus")]
            public string Channelstatus { get; set; }
        }

        public class XgaapAttr
        {
            [JsonProperty("accntclassdesc")]
            public string Accntclassdesc { get; set; }

            [JsonProperty("accntclasscode")]
            public string Accntclasscode { get; set; }

            [JsonProperty("accnttype")]
            public string Accnttype { get; set; }

            [JsonProperty("servicetower")]
            public string Servicetower { get; set; }
        }

        public class XxgCfoEmailTableDatum
        {
            [JsonProperty("cfo_send")]
            public string CfoSend { get; set; }

            [JsonProperty("cfo_category")]
            public string CfoCategory { get; set; }

            [JsonProperty("cfo_format")]
            public string CfoFormat { get; set; }

            [JsonProperty("cfo_method")]
            public string CfoMethod { get; set; }

            [JsonProperty("cfo_language")]
            public string CfoLanguage { get; set; }

            [JsonProperty("to_recipients")]
            public string ToRecipients { get; set; }
        }


    }
}