﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using  static UglyToad.PdfPig.PdfDocument;
using System.Text.RegularExpressions;
using UglyToad.PdfPig.DocumentLayoutAnalysis.WordExtractor;
using UglyToad.PdfPig.DocumentLayoutAnalysis.TextExtractor;
using  PDFValidate.Controllers;
    namespace PDFValidate.Models

{
    public class ProductDetails
    {
        private IReadOnlyList<UglyToad.PdfPig.Content.Hyperlink> links;
        PDFValidationController pdfcontroller = new PDFValidationController();

        public Dictionary<string,string> getdata(string path)
        {

            Dictionary<string, string> dt = new Dictionary<string, string>();

            ; 

            // var stream = File.OpenRead(@"C:\Users\nanda_kishore_reddy\OneDrive - Dell Technologies\Desktop\Order Confirmation with English Lang.PDF");
            var stream = File.OpenRead(@path);
            UglyToad.PdfPig.PdfDocument document = UglyToad.PdfPig.PdfDocument.Open(stream, UglyToad.PdfPig.ParsingOptions.LenientParsingOff);

            var pageno = document.GetPage(2);

            //var pageText = pageno.Text;
            var pageText = ContentOrderTextExtractor.GetText(pageno, true);
            char[] delims = new[] { '\n', '\n', '\r' };
            string[] lst = pageText.Split(delims);

            foreach (var value in lst)
            {
                if(value.Contains(":")&& !value.Contains("Order Number:") &&!value.Equals("Ship To:")&&!value.Equals("Delivery Address:"))
                {
                    char[] delim = new[] { ':' };
                    dt.Add(value.Split(delim)[0], value.Split(delim)[1]);
                }
               else if(value.Contains("Order Number:"))
                {
                    
                    string[] splitdata=Regex.Split(value, "[0-9]{9}");
                    var data = parseData(value, "Order Number:", "Estimated to Arrive By:");
                    dt.Add(splitdata[0],data.Trim());
                    var da = parseData(pageText, "Estimated to Arrive By:", "Pricing Summary");
                    dt.Add(splitdata[1],da.Trim());
                }
                else if ((value.Equals("Ship To:")))
                {


                    var data = parseData(pageText, "Ship To:", "Delivery Address:");
                    dt.Add(value, data.Trim());
                }
                else if ((value.Equals("Delivery Address:")))
                {
                    {

                        var data = parseData(pageText, "Delivery Address:", "Inco Terms:");
                        dt.Add(value, data.Trim());

                    }
                }  
            }
            return dt;
        }
        private string parseData( string actualText,string leftdata,string rightdata)
        {
            var data = actualText.Substring(actualText.IndexOf(leftdata), actualText.IndexOf(rightdata) - actualText.IndexOf(leftdata));
            data = data.Replace("\r\n", " ");
            data = data.Replace(leftdata, "");
            return data;
        }
    }

    }








