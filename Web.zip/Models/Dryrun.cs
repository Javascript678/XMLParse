﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.IO;
using System.Text.RegularExpressions;
using PDFValidate.Controllers;
namespace PDFValidate.Models
{
    public class Dryrun
    {
        PDFValidationController pdfcontroller = new PDFValidationController();
        public ProductDetail GetdryrunData(string path)
        {
            ProductDetail productDetail = new ProductDetail();
            SkuDetail skuDetail = new SkuDetail();
            productDetail.Skus = new List<SkuDetail>();


            var stream = File.OpenRead(@path);

            UglyToad.PdfPig.PdfDocument document = UglyToad.PdfPig.PdfDocument.Open(stream, UglyToad.PdfPig.ParsingOptions.LenientParsingOff);

            var page = document.GetPage(1);
            int x = document.NumberOfPages;
            var productDetailsIndex = 0;
            var currentIndex = 0;



            for (int k = 2; k <= x; k++)
            {
                page = document.GetPage(k);
                var wordArr = UglyToad.PdfPig.DocumentLayoutAnalysis.WordExtractor.NearestNeighbourWordExtractor.Instance.GetWords(page.Letters).ToArray();
              //  if ((wordArr.Length > 1) && (Array.Exists(wordArr,ele=> ele.ToString().Equals("Product"))))
                //{
                    if (k == 2)
                    {
                    if (wordArr.Length > 5)
                    {
                        for (int i = 0; i < wordArr.Length; i++)
                        {

                            if (wordArr[i] + " " + wordArr[i + 2] == "Product Details")
                            {
                                productDetailsIndex = i;
                                break;
                            }

                        }
                        var productName = string.Empty;
                        currentIndex = productDetailsIndex + 8; //currentIndex=121
                        for (int i = currentIndex; i < wordArr.Length; i++)
                        {
                            if (wordArr[i + 1].ToString().StartsWith("$"))
                            {
                                currentIndex = i;//break at 127 , current value =126
                                break;
                            }

                            else
                            {
                                productName += wordArr[i];
                            }
                        }

                        productDetail.ProductName = productName;
                        productDetail.ProductQty = wordArr[currentIndex].ToString();
                        productDetail.UnitPrice = wordArr[currentIndex + 1].ToString();
                        productDetail.SubTotal = wordArr[currentIndex + 2].ToString();



                        currentIndex = currentIndex + 5; // Parts naming starts
                        int p = currentIndex;
                        SkuDetail skUDetail = new SkuDetail();
                        while (p <= wordArr.Length - 4)
                        {       //regex not equals full numeric string (^\d+$) like 0123 for qty and regex of sku having -           then its a description
                            if (!(Regex.IsMatch(wordArr[p + 1].ToString(), @"^\d+$") && Regex.IsMatch(wordArr[p].ToString(), @"[0-9]{3}-[a-zA-Z]{4}")))
                            {
                                skUDetail.Description += wordArr[p];
                                p++;
                                if (p > (wordArr.Length - 4))
                                {
                                    skUDetail.Description += wordArr[p];
                                    p++;
                                    skUDetail.Sku = wordArr[p].ToString();
                                    p++;
                                    skUDetail.Qty = wordArr[p].ToString();
                                    //j++;
                                    skUDetail.UnitPrice = null;
                                    //  j++;
                                    skUDetail.SubTotal = null;
                                    // j++;
                                    productDetail.Skus.Add(skUDetail);
                                    skUDetail = new SkuDetail();
                                }
                                continue;
                            }


                            else
                            {
                                skUDetail.Sku = wordArr[p].ToString();
                                p++;
                                skUDetail.Qty = wordArr[p].ToString();
                                p++;
                                if ((wordArr[p].ToString().StartsWith("$")))
                                {
                                    skUDetail.UnitPrice = wordArr[p].ToString();
                                    p++;
                                    skUDetail.SubTotal = wordArr[p].ToString();
                                    p++;
                                }

                                productDetail.Skus.Add(skUDetail);
                                skUDetail = new SkuDetail();
                            }

                        }
                    }
                    }

                    else if (k != 2 && k != x)
                    {
                        int l = 0;
                        SkuDetail skuDetail1 = new SkuDetail();
                        while (l <= wordArr.Length - 4)
                        {       //regex not equals full numeric string (^\d+$) like 0123 for qty and regex of sku having -           then its a description
                            if (!(Regex.IsMatch(wordArr[l + 1].ToString(), @"^\d+$") && Regex.IsMatch(wordArr[l].ToString(), @"[0-9]{3}-[a-zA-Z0-9]{4}")))
                            {
                                skuDetail1.Description += wordArr[l];
                                l++;
                                if (l > (wordArr.Length - 4))
                                {
                                    skuDetail1.Description += wordArr[l];
                                    l++;
                                    skuDetail1.Sku = wordArr[l].ToString();
                                    l++;
                                    skuDetail1.Qty = wordArr[l].ToString();
                                    //j++;
                                    skuDetail1.UnitPrice = null;
                                    //  j++;
                                    skuDetail1.SubTotal = null;
                                    // j++;
                                    productDetail.Skus.Add(skuDetail1);
                                    skuDetail1 = new SkuDetail();
                                }
                                continue;
                            }


                            else
                            {
                                skuDetail1.Sku = wordArr[l].ToString();
                                l++;
                                skuDetail1.Qty = wordArr[l].ToString();
                                l++;
                                if ((wordArr[l].ToString().StartsWith("$")))
                                {
                                    skuDetail1.UnitPrice = wordArr[l].ToString();
                                    l++;
                                    skuDetail1.SubTotal = wordArr[l].ToString();
                                    l++;
                                }

                                productDetail.Skus.Add(skuDetail1);
                                skuDetail1 = new SkuDetail();
                            }

                        }
                    }

                    else
                    {
                        int j = 0;
                        SkuDetail skuDetail2 = new SkuDetail();
                        while (j <= wordArr.Length - 4)

                        {
                            if (wordArr[j] + " " + wordArr[j + 2] == "Need Help?")
                            {
                                break;
                            }
                            else
                            {
                                //regex not equals full numeric string (^\d+$) like 0123 for qty and regex of sku having -           then its a description
                                if (!(Regex.IsMatch(wordArr[j + 1].ToString(), @"^\d+$") && Regex.IsMatch(wordArr[j].ToString(), @"[0-9]{3}-[a-zA-Z0-9]{4}")))
                                {
                                    skuDetail2.Description += wordArr[j];
                                    j++;
                                    if (j > (wordArr.Length - 4))
                                    {
                                        skuDetail2.Description += wordArr[j];
                                        j++;
                                        skuDetail2.Sku = wordArr[j].ToString();
                                        j++;
                                        skuDetail2.Qty = wordArr[j].ToString();
                                        //j++;
                                        skuDetail2.UnitPrice = null;
                                        //  j++;
                                        skuDetail2.SubTotal = null;
                                        // j++;
                                        productDetail.Skus.Add(skuDetail2);
                                        skuDetail2 = new SkuDetail();
                                    }
                                    continue;
                                }


                                else
                                {
                                    skuDetail2.Sku = wordArr[j].ToString();
                                    j++;
                                    skuDetail2.Qty = wordArr[j].ToString();
                                    j++;
                                    if ((wordArr[j].ToString().StartsWith("$")))
                                    {
                                        skuDetail2.UnitPrice = wordArr[j].ToString();
                                        j++;
                                        skuDetail2.SubTotal = wordArr[j].ToString();
                                        j++;
                                    }

                                    productDetail.Skus.Add(skuDetail2);
                                    skuDetail2 = new SkuDetail();
                                }
                            }

                        }
                    }
                //}
                Console.WriteLine($"{productDetail.ProductName} | {productDetail.ProductQty} | {productDetail.UnitPrice} | {productDetail.SubTotal}");
                Console.WriteLine();

                foreach (var sku in productDetail.Skus)
                {
                    Console.WriteLine($"{sku.Description} | {sku.Sku} | {sku.Qty} | {sku.UnitPrice} | {sku.SubTotal}");
                }
            }
                return productDetail;
            }

        }

    }



    public class ProductDetail
    {
        public string ProductName { get; set; }
        public string ProductQty { get; set; }
        public string UnitPrice { get; set; }
        public string SubTotal { get; set; }
        public List<SkuDetail> Skus { get; set; }


    }

    public class SkuDetail
    {
        public string Description { get; set; }
        public string Sku { get; set; }
        public string Qty { get; set; }
        public string UnitPrice { get; set; }
        public string SubTotal { get; set; }
    }

