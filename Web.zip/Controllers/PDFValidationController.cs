﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web;
using System.Web.Configuration;
using System.Web.Http;
using PDFValidate.Models;
using Newtonsoft.Json.Linq;

namespace PDFValidate.Controllers
{
    public class PDFValidationController : ApiController
    {
       /*
        [HttpGet]
        [Route("getproduct")]
        public List<ResultSet> getproduct()
        {
            DBValidation dbValidation = new DBValidation();
            List<ResultSet> lst = dbValidation.dbValidation();
            return lst;
        }
*/
        [HttpPost]
        [Route("getproductss")]
        public async Task<JObject> MediaUploadAsync()
        {
            JObject jobject = new JObject();
            // Check if the request contains multipart/form-data.  
            if (!Request.Content.IsMimeMultipartContent())
            {
                throw new HttpResponseException(HttpStatusCode.UnsupportedMediaType);
            }
            var provider = await Request.Content.ReadAsMultipartAsync<InMemoryMultipartFormDataStreamProvider>(new InMemoryMultipartFormDataStreamProvider());
            //access form data  
            NameValueCollection formData = provider.FormData;
            //access files  
            IList<HttpContent> files = provider.Files;
            HttpContent file1 = files[0];
            var thisFileName = file1.Headers.ContentDisposition.FileName.Trim('\"');
            var filePath = HttpContext.Current.Server.MapPath("~/" + thisFileName);
            var httpRequest = HttpContext.Current.Request;
            var postedFile = httpRequest.Files[0];
            var path = System.IO.Path.Combine("C:\\Users\\Public\\", thisFileName);
            
            postedFile.SaveAs(path);
            DBValidation dbValidation = new DBValidation();
            List<ResultSet> lst = dbValidation.DataValidation(path);
           Dictionary<string,int> statuscount= getdatacount(lst);
            jobject = JObject.FromObject(statuscount);
            jobject.Add("Validation", JToken.FromObject(lst));
            GC.Collect();
           
            File.Delete(path);
           
            return jobject;
            
        }

        public Dictionary<string, int> getdatacount(List<ResultSet> lst)
        {
            Dictionary<string, int> dictionary = new Dictionary<string, int>();
            var count = 0;
            var passcount = 0;
            foreach  (ResultSet result in lst)
            {
                if(result.status== "Fail") 
                {
                    count++;
                }
                else if (result.status == "Pass")
                {
                    passcount++;
                }

            }
            dictionary.Add("Fail", count);
            dictionary.Add("Pass", passcount);
            return dictionary;
        }
    }
}
